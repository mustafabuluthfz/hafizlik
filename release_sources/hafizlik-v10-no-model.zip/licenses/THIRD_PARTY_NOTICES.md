# Üçüncü taraf lisans ve kaynak bildirimleri

- Model: **Abdou/quran-asr-small**, Abdeladim Fadheli / Abdou, 2026.  
  Kaynak: https://huggingface.co/Abdou/quran-asr-small  
  Lisans: MIT. Tam bildirim: `Abdou-quran-asr-small-MIT.txt` ve uygulama içinde `assets/asr/LICENSE.txt`.
- Yerel ses tanıma çalışma zamanı: **sherpa-onnx**, k2-fsa topluluğu.  
  Kaynak: https://github.com/k2-fsa/sherpa-onnx  
  Lisans: Apache-2.0; lisans metni: `sherpa-onnx-Apache-2.0.txt`.
- Modeli eğitmek için kullanılan ses verileri modelin MIT lisansından farklı şartlara tabi olabilir. Model ağırlıklarıyla birlikte ham ses kayıtları dağıtılmamaktadır. Üçüncü taraf ses kayıtlarının yayınlanması ayrı izin gerektirebilir.

Bu belge hukuki görüş değildir; uygulamayı kamuya açık mağazada yayınlamadan önce kendi kullanım ve dağıtım koşullarınızı doğrulayın.
