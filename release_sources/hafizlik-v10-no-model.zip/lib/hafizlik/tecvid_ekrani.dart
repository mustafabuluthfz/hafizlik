import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../ortak/tema.dart';
import '../ortak/mushaf.dart';
import 'tecvid_sinavi_ekrani.dart';
import 'cezeri_ekrani.dart';
import 'tecvid_ilkeleri_ekrani.dart';

class TecvidKural {
  final String kategori;
  final String ad;
  final String tanim;
  final String ornek;
  final String ipucu;
  const TecvidKural(this.kategori, this.ad, this.tanim, this.ornek, this.ipucu);
}

/// Tecvid konularını konu başlıkları ve arama ile sunar.
/// Açıklamalar Hafs rivayeti için temel öğretim çerçevesindedir;
/// uygulama otomatik kıraat/tecvid tashihi yaptığı iddiasında bulunmaz.
class TecvidEkrani extends StatefulWidget {
  static const kurallar = <TecvidKural>[
    // Nûn-i sâkin ve tenvin
    TecvidKural('Nûn-i sâkin ve tenvin', 'İzhâr-ı halkî', 'Sâkin nûn veya tenvinden sonra ء ه ع ح غ خ harflerinden biri gelirse nûn/tenvin sesi açıkça okunur.', 'مِنْ هَادٍ', 'Nûn sesini gizlemeden, boğaz harfini belirgin çıkar.'),
    TecvidKural('Nûn-i sâkin ve tenvin', 'İdğâm mea’l-ğunne', 'Sâkin nûn veya tenvinden sonra ي ن م و gelirse iki hareke ğunne ile kaynaştırma yapılır.', 'مَنْ يَعْمَلْ', 'Yâ, nûn, mîm ve vâv harflerini “يَنْمُو” diye hatırla.'),
    TecvidKural('Nûn-i sâkin ve tenvin', 'İdğâm bilâ-ğunne', 'Sâkin nûn veya tenvinden sonra ل veya ر gelirse ğunnesiz kaynaştırma yapılır.', 'مِنْ رَبِّهِمْ', 'Lâm ve râ öncesinde nûn sesini ayrı tutma.'),
    TecvidKural('Nûn-i sâkin ve tenvin', 'İklâb', 'Sâkin nûn veya tenvinden sonra ب gelirse nûn sesi gizli mîm sesine çevrilir ve ğunne yapılır.', 'مِنْ بَعْدِ', 'Dudakları hafifçe kapat; iki hareke ğunne uygula.'),
    TecvidKural('Nûn-i sâkin ve tenvin', 'İhfâ-i hakîkî', 'Sâkin nûn veya tenvinden sonra izhâr, idğâm ve iklâb harfleri dışındaki 15 harften biri gelirse ses ihfâ edilir.', 'مِنْ قَبْلُ', 'Nûn mahrecini tam kapatmadan, sonraki harfin mahrecine hazırlık yap.'),

    // Mîm-i sâkin
    TecvidKural('Mîm-i sâkin', 'İhfâ-i şefevî', 'Sâkin mîmden sonra ب gelirse dudaklarda ihfâ ve ğunne yapılır.', 'تَرْمِيهِمْ بِحِجَارَةٍ', 'Dudakları sertçe bastırmadan kapat.'),
    TecvidKural('Mîm-i sâkin', 'İdğâm-ı misleyn / şefevî', 'Sâkin mîmden sonra başka bir mîm gelirse iki mîm ğunneyle birleştirilir.', 'لَهُمْ مَا', 'İki hareke ğunne ile oku.'),
    TecvidKural('Mîm-i sâkin', 'İzhâr-ı şefevî', 'Sâkin mîmden sonra ب ve م dışındaki harfler gelirse mîm açık okunur.', 'أَنْعَمْتَ', 'Özellikle ف ve و öncesinde mîm açıklığını koru.'),

    // İdğâm çeşitleri
    TecvidKural('İdğâm çeşitleri', 'İdğâm-ı misleyn', 'Mahreç ve sıfatları aynı iki harften ilki sâkin, ikincisi harekeli gelirse birleştirilir.', 'اضْرِبْ بِعَصَاكَ', 'Birinci harfin sesi ikinci harfe katılır.'),
    TecvidKural('İdğâm çeşitleri', 'İdğâm-ı mütecâniseyn', 'Mahreçleri aynı, sıfatları farklı iki harften ilki sâkin, ikincisi harekeli gelirse idğâm yapılır.', 'قَدْ تَبَيَّنَ', 'Dâl ve tâ gibi aynı mahreçli harfleri hocadan dinleyerek çalış.'),
    TecvidKural('İdğâm çeşitleri', 'İdğâm-ı mütekāribeyn', 'Mahreç veya sıfat bakımından birbirine yakın iki harfin belirli birleşmelerinde idğâm yapılır.', 'قُلْ رَبِّ', 'Lâm-râ ve benzeri örnekleri rivayet/usule göre öğren.'),
    TecvidKural('İdğâm çeşitleri', 'İdğâm-ı şemsî', 'ال takısından sonra şemsî harf gelirse lâm okunmaz, sonraki harfe katılır.', 'الشَّمْسُ', 'Şemsî harfler: ت ث د ذ ر ز س ش ص ض ط ظ ل ن.'),

    // Mîm ve nûn müşedded
    TecvidKural('Ğunne', 'Nûn-ı müşedded', 'Şeddeli nûn, vasıl ve vakıf hâllerinde ğunne ile iki hareke tutulur.', 'إِنَّ', 'Geniz sesini belirgin ama ölçülü ver.'),
    TecvidKural('Ğunne', 'Mîm-i müşedded', 'Şeddeli mîm iki hareke ğunne ile okunur.', 'ثُمَّ', 'Dudak kapanışı ve geniz sesini birlikte hisset.'),
    TecvidKural('Ğunne', 'Ğunnenin mertebeleri', 'Ğunne; idğâm, ihfâ, iklâb ve müşedded nûn/mîm gibi yerlerde farklı kuvvette duyulur.', 'إِنَّ · مِنْ بَعْدِ', 'Ğunne süresini ve kuvvetini tecvid hocasının okuyuşuyla pekiştir.'),

    // Medler
    TecvidKural('Medler', 'Medd-i tabîî / aslî', 'Med harfinden sonra hemze veya sükûn sebebi yoksa iki hareke uzatılır.', 'قَالَ', 'Elif, sakin vâv ve sakin yâ öncesindeki harekeye dikkat et.'),
    TecvidKural('Medler', 'Medd-i muttasıl', 'Med harfi ile sebeb-i med olan hemze aynı kelimede bulunur.', 'جَاءَ', 'Uzatma miktarı takip edilen tarik ve öğretim usulüne göre değişebilir.'),
    TecvidKural('Medler', 'Medd-i munfasıl', 'Med harfi kelime sonunda, hemze sonraki kelimenin başında bulunur.', 'بِمَا أُنْزِلَ', 'Vasıl hâlinde med yapılır; ölçüyü hocanın öğrettiği usule göre koru.'),
    TecvidKural('Medler', 'Medd-i lâzım kelimî müsakkal', 'Med harfinden sonra aynı kelimede şeddeli/asıllı lâzım sükûn gelirse altı hareke uzatılır.', 'الضَّالِّينَ', 'Lâzım medde altı hareke ölçüsünü koru.'),
    TecvidKural('Medler', 'Medd-i lâzım kelimî muhaffef', 'Aynı kelimede med harfinden sonra şeddesiz lâzım sükûn gelmesidir.', 'آلْآنَ', 'Kur’an’da sınırlı örneği vardır; hocayla meşk et.'),
    TecvidKural('Medler', 'Medd-i lâzım harfî müsakkal', 'Hurûf-ı mukattaa içinde medden sonra idğâm sebebiyle şeddeli hâle gelen harfî meddir.', 'الٓمٓ', 'Sure başlarındaki harflerin okunuşunu ayrı ayrı öğren.'),
    TecvidKural('Medler', 'Medd-i lâzım harfî muhaffef', 'Hurûf-ı mukattaa harflerinde medden sonra idğâm olmadan lâzım sükûn bulunur.', 'صٓ · قٓ', 'Harf adlarının hece yapısına dikkat et.'),
    TecvidKural('Medler', 'Medd-i ârız li’s-sükûn', 'Vakıf sebebiyle son harf sâkin olduğunda med harfinden önceki uzatma 2, 4 veya 6 hareke yapılabilir.', 'الْعَالَمِينَ', 'Aynı okuyuşta seçtiğin ölçüyü tutarlı uygula.'),
    TecvidKural('Medler', 'Medd-i lîn', 'Fetha sonrası sakin vâv veya yâ üzerinde vakıf yapılınca yumuşak uzatma meydana gelir.', 'خَوْفٍ · بَيْتٍ', 'Vakıfta 2, 4 veya 6 hareke seçenekleri öğretilir.'),
    TecvidKural('Medler', 'Medd-i bedel', 'Hemze med harfinden önce geldiğinde med harfi iki hareke okunur.', 'آمَنُوا', 'Hafs rivayetinde genellikle iki hareke ölçüsündedir.'),
    TecvidKural('Medler', 'Medd-i ıvaz', 'Fetha tenviniyle biten kelimede vakıf yapılınca tenvin elif gibi iki hareke uzatılır.', 'عَلِيمًا', 'ة ile biten kelimelerde bu şekilde uygulanmaz.'),
    TecvidKural('Medler', 'Medd-i sıla suğrâ', 'He zamiri iki harekeli harf arasında bulunur ve ardından hemze gelmezse vasılda kısa med yapılır.', 'إِنَّهُ كَانَ', 'He zamirinin harekesini ve önce-sonra harfleri kontrol et.'),
    TecvidKural('Medler', 'Medd-i sıla kübrâ', 'He zamirinden sonra hemze gelirse vasılda daha uzun sıla meddi yapılır.', 'مَالَهُ أَخْلَدَهُ', 'Hemze sebebini ayırt et; vakıfta sıla yapılmaz.'),
    TecvidKural('Medler', 'Medd-i temkîn', 'Yan yana gelen iki yâ harfinin karışmasını önlemek için gereken açıklık ve uzatmadır.', 'النَّبِيِّينَ', 'Yâların mahreç ve harekelerini birbirine karıştırma.'),
    TecvidKural('Medler', 'Medd-i fark', 'Soru hemzesini haber hemzesinden ayıran özel meddir.', 'ءَآللَّهُ', 'Özel örnekleri mushaf işaretleri ve hocanın talimiyle öğren.'),

    // Harf ve sıfatlar
    TecvidKural('Mahreçler ve sıfatlar', 'Kalkale suğrâ', 'ق ط ب ج د harflerinden biri kelime içinde sâkin olduğunda yankılı ses verilir.', 'يَجْعَلُونَ', 'Harekeli yeni bir ses eklemeden mahreçte yankı oluştur.'),
    TecvidKural('Mahreçler ve sıfatlar', 'Kalkale kübrâ', 'Kalkale harfi kelime sonunda vakıf sebebiyle sâkin olursa yankı daha belirgin duyulur.', 'الْفَلَقْ', 'Yankıyı abartıp harfe fetha/kesra ekleme.'),
    TecvidKural('Mahreçler ve sıfatlar', 'Tefhîm (kalın okuma)', 'İsti‘lâ harfleri خ ص ض غ ط ق ظ kalın okunur; râ ve Allah lafzının lâmı da bağlama göre kalınlaşabilir.', 'قَالَ · الصَّمَدُ', 'Dil kökünü yükselt; kalınlığı aşırılaştırma.'),
    TecvidKural('Mahreçler ve sıfatlar', 'Terkīk (ince okuma)', 'İstifâl harfleri esasen ince okunur; râ ve Allah lafzının lâmı belirli şartlarda ince okunur.', 'بِسْمِ اللَّهِ', 'İnce harfleri kalınlaştırma; lâm ve râ şartlarını ayrıca çalış.'),
    TecvidKural('Mahreçler ve sıfatlar', 'Râ harfinin kalın okunması', 'Râ fethalı veya dammeli olduğunda; ayrıca bazı sükûn durumlarında kalın okunur.', 'رَبِّ · رُزِقُوا', 'Râ sakin ise önceki hareke ve sonraki harfin durumunu incele.'),
    TecvidKural('Mahreçler ve sıfatlar', 'Râ harfinin ince okunması', 'Râ kesralı olduğunda ve bazı sükûn durumlarında ince okunur.', 'رِزْقًا', 'Râ sakin öncesindeki kesre ve isti‘lâ harfi şartlarını kontrol et.'),
    TecvidKural('Mahreçler ve sıfatlar', 'Lâm-ı celâle', 'Allah lafzının lâmı öncesi fetha/damme ise kalın, kesre ise ince okunur.', 'قَالَ اللَّهُ · بِاللَّهِ', 'Bir önceki kelimenin son harekesine dikkat et.'),
    TecvidKural('Mahreçler ve sıfatlar', 'Hemzetü’l-vasl', 'Kelime başında okunur; öncesine vasıl edilirse düşer. Başlangıç harekesi kelime yapısına göre belirlenir.', 'اهْدِنَا', 'İbtidâ ederken hemzeyi başlat; vasılda tekrar etme.'),
    TecvidKural('Mahreçler ve sıfatlar', 'Hemzetü’l-kat‘', 'Hemze her durumda, hem başlangıçta hem vasılda okunur.', 'أَنْعَمْتَ', 'Hemze sesini düşürme.'),
    TecvidKural('Mahreçler ve sıfatlar', 'Lâm-ı kameriyye', 'ال takısından sonra kamerî harf gelirse lâm açık okunur.', 'الْقَمَرُ', 'Kamerî harfleri “ابغ حجك وخف عقيمه” şeklinde ezberleyebilirsin.'),
    TecvidKural('Mahreçler ve sıfatlar', 'Sıfat-ı lâzime', 'Harflerden ayrılmayan kalıcı sıfatlardır; hems, cehr, şiddet, rihvet, isti‘lâ, istifâl gibi sıfatları kapsar.', 'هَمْس · جَهْر', 'Her harfin sıfatlarını mahreçle birlikte öğren.'),
    TecvidKural('Mahreçler ve sıfatlar', 'Sıfat-ı ârıza', 'Harfte okuyuş şartına göre ortaya çıkan veya kaybolan sıfatlardır; idğâm, ihfâ, tefhim ve terkik gibi.', 'مِنْ رَبِّهِمْ', 'Sıfatın hangi bağlamda ortaya çıktığını örnek üzerinde incele.'),
    TecvidKural('Mahreçler ve sıfatlar', 'Mahreçler: boğaz harfleri', 'Hemze ve hâ aksa’l-halktan; ayn ve hâ vasatü’l-halktan; ğayn ve hı edne’l-halktan çıkar.', 'ء ه ع ح غ خ', 'Boğazın üç bölgesini ayırt ederek sesleri hocadan dinle.'),
    TecvidKural('Mahreçler ve sıfatlar', 'Mahreçler: dil, dudak ve geniz', 'Harflerin çoğu dil bölgelerinden; bâ, mîm, vâv dudaklardan; ğunne geniz boşluğundan çıkar.', 'ب · م · و · ن', 'Mahreçleri sadece teorik değil, sesli meşk ile öğren.'),

    // Vakıf ve ibtida
    TecvidKural('Vakıf ve ibtidâ', 'Vakıf', 'Okuyuşu nefes almak veya anlamı tamamlamak için kesmektir; kelimenin sonu vakıf kurallarına göre sükûn/bedel alabilir.', 'الْعَالَمِينَ۝', 'Mana bütünlüğünü bozan yerde durmaktan kaçın.'),
    TecvidKural('Vakıf ve ibtidâ', 'İbtidâ', 'Vakfın ardından okumaya yeniden başlamaktır; anlam ve nahiv bütünlüğüne uygun yerden başlanır.', 'بِسْمِ اللَّهِ', 'Anlamı tamamlamayan bir kelimeden başlama.'),
    TecvidKural('Vakıf ve ibtidâ', 'Vakıf-ı tâm', 'Mana ve söz dizimi bakımından kendisinden sonrası ile bağı bulunmayan yerde duruştur.', 'Kıssa veya konu sonları', 'Mushaf işaretini ve anlamı birlikte değerlendir.'),
    TecvidKural('Vakıf ve ibtidâ', 'Vakıf-ı kâfî', 'Mana bakımından tamam olmakla birlikte sonraki bölümle konu/bağlantı ilişkisi bulunan yerde duruştur.', 'Bağlantılı ayet sonları', 'Sonraki ayetle mana bağını koru.'),
    TecvidKural('Vakıf ve ibtidâ', 'Vakıf-ı hasen', 'Mana anlaşılır olmakla birlikte lafız veya i‘rab bakımından sonraki kısma bağlılık bulunan yerde duruştur.', 'Ayet içi uygun durak', 'Başlangıcı uygun yerden yapmaya dikkat et.'),
    TecvidKural('Vakıf ve ibtidâ', 'Vakıf-ı kabîh', 'Mana tamamlanmadan veya anlamı bozacak biçimde yapılan duruştur.', 'Cümle ortasında uygunsuz kesme', 'Zaruret dışında böyle duruşlardan kaçın.'),
    TecvidKural('Vakıf ve ibtidâ', 'Lâ (لا) işareti', 'Bu işaret, ilgili yerde durulmamasını bildirir; zaruret hâlinde durulursa uygun yerden tekrar başlanır.', 'لا', 'Mushafın vakıf işaretlerini tanı.'),
    TecvidKural('Vakıf ve ibtidâ', 'Muânaka vakfı', 'Üç nokta işaretli iki yerden birinde durulur; ikisinde birden durulmaz.', 'ۛ ۛ', 'İki işaretten yalnızca birini vakıf yeri seç.'),
    TecvidKural('Vakıf ve ibtidâ', 'Mîm (م) vakıf işareti', 'Lâzım vakıf işaretidir; işaretin bulunduğu yerde durulması gerekir.', 'م', 'Mana bütünlüğü için bu işareti dikkate al.'),
    TecvidKural('Vakıf ve ibtidâ', 'Cîm (ج) vakıf işareti', 'Durmanın da geçmenin de caiz olduğunu gösterir.', 'ج', 'Nefes ve mana akışına göre tercih yap.'),
    TecvidKural('Vakıf ve ibtidâ', 'Kılâ (قلى) işareti', 'Durmanın geçmekten daha uygun olduğunu bildirir.', 'قلى', 'Durmak genellikle tercih edilir.'),
    TecvidKural('Vakıf ve ibtidâ', 'Sılâ (صلى) işareti', 'Geçmenin durmaktan daha uygun olduğunu bildirir.', 'صلى', 'Mana bağlantısını sürdürmek genellikle tercih edilir.'),
    TecvidKural('Vakıf ve ibtidâ', 'Tâ (ط) işareti', 'Vakf-ı mutlak olarak bilinir; durmanın uygun olduğu yeri gösterir.', 'ط', 'Ayet içi anlamın tamamlandığı noktaları takip et.'),
    TecvidKural('Vakıf ve ibtidâ', 'Sekte', 'Nefes almadan, kısa bir süre sesi keserek yapılan özel duruştur.', 'عِوَجًاۜ قَيِّمًا', 'Hafs rivayetindeki sekte yerlerini mushaf ve hocayla öğren.'),
  ];

  const TecvidEkrani({super.key});
  @override
  State<TecvidEkrani> createState() => _TecvidEkraniState();
}

// Var olan ders içeriklerini değiştirmeden altı konu kümesine ayıran öğrenme yolu.
class _TecvidKlasor {
  final String baslik;
  final String aciklama;
  final IconData ikon;
  final List<String> kategoriler;
  const _TecvidKlasor(this.baslik, this.aciklama, this.ikon, this.kategoriler);
}

const _klasorler = <_TecvidKlasor>[
  _TecvidKlasor('Nûn ve tenvin', 'İzhâr, ihfâ, iklâb ve idğâm', Icons.format_list_numbered_rounded,
      ['Nûn-i sâkin ve tenvin']),
  _TecvidKlasor('Mîm ve ğunne', 'Dudak hükümleri ve geniz sesi', Icons.graphic_eq_rounded,
      ['Mîm-i sâkin', 'Ğunne']),
  _TecvidKlasor('İdğâm çeşitleri', 'Harflerin birbirine katılması', Icons.merge_type_rounded,
      ['İdğâm çeşitleri']),
  _TecvidKlasor('Med ve uzatmalar', 'Uzatma türleri ve ölçüleri', Icons.waves_rounded,
      ['Medler']),
  _TecvidKlasor('Mahreç ve harfler', 'Harflerin çıkış yerleri ve sıfatları', Icons.record_voice_over_rounded,
      ['Mahreçler ve sıfatlar']),
  _TecvidKlasor('Vakıf ve ibtidâ', 'Durma, başlama ve Mushaf işaretleri', Icons.flag_rounded,
      ['Vakıf ve ibtidâ']),
];

class _TecvidEkraniState extends State<TecvidEkrani> {
  final TextEditingController _arama = TextEditingController();
  Set<String> _kaydedilenler = {};

  @override
  void initState() {
    super.initState();
    _kaydedilenleriYukle();
  }

  Future<void> _kaydedilenleriYukle() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() => _kaydedilenler =
          (prefs.getStringList('tecvid_kaydedilen_dersler') ?? []).toSet());
    }
  }

  @override
  void dispose() {
    _arama.dispose();
    super.dispose();
  }

  Future<void> _dersAc(TecvidKural ders) async {
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => _TecvidDersDetay(ders: ders),
    ));
    await _kaydedilenleriYukle();
  }

  void _klasorAc(_TecvidKlasor klasor) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => _TecvidKlasorSayfasi(klasor: klasor),
    )).then((_) => _kaydedilenleriYukle());
  }

  Widget _baslik(String metin, {String? aciklama}) => Padding(
    padding: const EdgeInsets.fromLTRB(2, 20, 2, 12),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(metin, style: Theme.of(context).textTheme.titleLarge),
      if (aciklama != null) ...[
        const SizedBox(height: 4),
        Text(aciklama, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
      ],
    ]),
  );

  @override
  Widget build(BuildContext context) {
    final aranan = _arama.text.trim().toLowerCase();
    final sonuc = TecvidEkrani.kurallar.where((k) =>
      '${k.ad} ${k.tanim} ${k.ornek} ${k.kategori}'
          .toLowerCase().contains(aranan)).toList();
    final kaydedilenDersler = TecvidEkrani.kurallar
        .where((k) => _kaydedilenler.contains(k.ad)).toList();
    final renk = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Tecvid Akademisi'),
        actions: [
          IconButton(
            tooltip: 'Tecvid sınavını aç',
            icon: const Icon(Icons.quiz_rounded),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => const TecvidSinaviEkrani(),
            )),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF0D463D), Color(0xFF238171)],
              ),
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Icon(Icons.auto_stories_rounded, color: Color(0xFFF1E6C4), size: 30),
              const SizedBox(height: 10),
              const Text('Konuları sırayla öğren', style: TextStyle(
                color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold,
              )),
              const SizedBox(height: 6),
              Text('${_klasorler.length} konu klasörü · ${TecvidEkrani.kurallar.length} ders',
                style: const TextStyle(color: Colors.white70)),
              const SizedBox(height: 8),
              const Text('Bir klasör seç, dersleri incele ve tekrar etmek istediklerini kaydet.',
                style: TextStyle(color: Colors.white, height: 1.4)),
            ]),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _arama,
            onChanged: (_) => setState(() {}),
            textInputAction: TextInputAction.search,
            decoration: InputDecoration(
              hintText: 'Ders veya kural ara',
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: aranan.isEmpty ? null : IconButton(
                tooltip: 'Aramayı temizle',
                onPressed: () => setState(_arama.clear),
                icon: const Icon(Icons.close_rounded),
              ),
            ),
          ),
          if (aranan.isNotEmpty) ...[
            _baslik('Arama sonuçları', aciklama: '${sonuc.length} ders bulundu'),
            if (sonuc.isEmpty)
              const Card(child: Padding(
                padding: EdgeInsets.all(18),
                child: Text('Bu aramayla eşleşen bir ders bulunamadı.'),
              )),
            for (final ders in sonuc)
              Padding(padding: const EdgeInsets.only(bottom: 8), child: Card(
                child: ListTile(
                  leading: const Icon(Icons.menu_book_outlined, color: kYesil),
                  title: Text(ders.ad),
                  subtitle: Text(ders.kategori, maxLines: 1),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () => _dersAc(ders),
                ),
              )),
          ] else ...[
            _baslik('Konu klasörleri', aciklama: 'İstediğin konudan çalışmaya başla.'),
            for (var i = 0; i < _klasorler.length; i++)
              Padding(padding: const EdgeInsets.only(bottom: 10), child: Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(20),
                  onTap: () => _klasorAc(_klasorler[i]),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    child: Row(children: [
                      Container(
                        width: 52, height: 52,
                        decoration: BoxDecoration(
                          color: renk.primaryContainer,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Icon(_klasorler[i].ikon, color: renk.onPrimaryContainer),
                      ),
                      const SizedBox(width: 14),
                      Expanded(child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_klasorler[i].baslik, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                          const SizedBox(height: 3),
                          Text(_klasorler[i].aciklama,
                            style: TextStyle(color: renk.onSurfaceVariant, fontSize: 12)),
                          const SizedBox(height: 4),
                          Text('${TecvidEkrani.kurallar.where((d) => _klasorler[i].kategoriler.contains(d.kategori)).length} ders',
                            style: TextStyle(color: renk.primary, fontWeight: FontWeight.w600, fontSize: 12)),
                        ],
                      )),
                      const Icon(Icons.chevron_right_rounded),
                    ]),
                  ),
                ),
              )),
            if (kaydedilenDersler.isNotEmpty) ...[
              _baslik('Kaydedilen dersler', aciklama: 'Tekrar etmek için işaretlediklerin'),
              for (final ders in kaydedilenDersler)
                Padding(padding: const EdgeInsets.only(bottom: 8), child: Card(
                  child: ListTile(
                    leading: const Icon(Icons.bookmark_rounded, color: kAltin),
                    title: Text(ders.ad),
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () => _dersAc(ders),
                  ),
                )),
            ],
            _baslik('Ek kaynaklar'),
            Card(child: ListTile(
              leading: const Icon(Icons.auto_stories_rounded, color: kAltin),
              title: const Text('Cezerî Mukaddime'),
              subtitle: const Text('Arapça metin ve Türkçe açıklama'),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const CezeriEkrani())),
            )),
            const SizedBox(height: 8),
            Card(child: ListTile(
              leading: const Icon(Icons.rule_rounded, color: kYesil),
              title: const Text('Tecvid İlkeleri'),
              subtitle: const Text('Arapça ifade ve Türkçe açıklama'),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const TecvidIlkeleriEkrani())),
            )),
          ],
          const SizedBox(height: 12),
          Text('Tecvid dersleri öğretim amaçlıdır. Telaffuz ve kıraat için hocanızla çalışın.',
            textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: renk.onSurfaceVariant)),
        ],
      ),
    );
  }
}

class _TecvidKlasorSayfasi extends StatelessWidget {
  final _TecvidKlasor klasor;
  const _TecvidKlasorSayfasi({required this.klasor});

  @override
  Widget build(BuildContext context) {
    final renk = Theme.of(context).colorScheme;
    final dersler = TecvidEkrani.kurallar.where((k) =>
        klasor.kategoriler.contains(k.kategori)).toList();
    return Scaffold(
      appBar: AppBar(title: Text(klasor.baslik)),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 28), children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: renk.primaryContainer,
            borderRadius: BorderRadius.circular(18)),
          child: Row(children: [
            Icon(klasor.ikon, size: 36, color: renk.onPrimaryContainer),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(klasor.baslik, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700,
                  color: renk.onPrimaryContainer)),
              const SizedBox(height: 4),
              Text('${dersler.length} ders · ${klasor.aciklama}',
                  style: TextStyle(color: renk.onPrimaryContainer)),
            ])),
          ]),
        ),
        const SizedBox(height: 18),
        for (var i = 0; i < dersler.length; i++) ...[
          if (i == 0 || dersler[i].kategori != dersler[i - 1].kategori)
            Padding(padding: const EdgeInsets.fromLTRB(4, 10, 4, 12),
              child: Text(dersler[i].kategori,
                style: Theme.of(context).textTheme.titleMedium)),
          Card(child: ListTile(
            leading: CircleAvatar(
              backgroundColor: renk.primaryContainer,
              child: Text('${i + 1}', style: TextStyle(color: renk.onPrimaryContainer)),
            ),
            title: Text(dersler[i].ad, style: const TextStyle(fontWeight: FontWeight.w600)),
            subtitle: const Text('Açıklama, Arapça örnek ve çalışma notu'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => _TecvidDersDetay(ders: dersler[i]),
            )),
          )),
          const SizedBox(height: 8),
        ],
      ]),
    );
  }
}

class _TecvidDersDetay extends StatefulWidget {
  final TecvidKural ders;
  const _TecvidDersDetay({required this.ders});

  @override
  State<_TecvidDersDetay> createState() => _TecvidDersDetayState();
}

class _TecvidDersDetayState extends State<_TecvidDersDetay> {
  bool _kaydedildi = false;
  @override
  void initState() {
    super.initState();
    _yukle();
  }

  Future<void> _yukle() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) setState(() => _kaydedildi =
        (prefs.getStringList('tecvid_kaydedilen_dersler') ?? []).contains(widget.ders.ad));
  }

  Future<void> _degistir() async {
    final prefs = await SharedPreferences.getInstance();
    final isimler = (prefs.getStringList('tecvid_kaydedilen_dersler') ?? []).toSet();
    if (!isimler.remove(widget.ders.ad)) isimler.add(widget.ders.ad);
    await prefs.setStringList('tecvid_kaydedilen_dersler', isimler.toList());
    if (mounted) setState(() => _kaydedildi = isimler.contains(widget.ders.ad));
  }

  @override
  Widget build(BuildContext context) {
    final ders = widget.ders;
    final renk = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Tecvid dersi'), actions: [
        IconButton(
          tooltip: _kaydedildi ? 'Kaydedilenlerden çıkar' : 'Dersi kaydet',
          icon: Icon(_kaydedildi ? Icons.bookmark_rounded : Icons.bookmark_border_rounded),
          onPressed: _degistir,
        ),
      ]),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Text(ders.kategori, style: TextStyle(color: renk.primary, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Text(ders.ad, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(color: kKagitRengi,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kAltin.withOpacity(.4))),
          child: Column(children: [
            const Text('ARAPÇA ÖRNEK', style: TextStyle(
              letterSpacing: 1, color: kYesil, fontWeight: FontWeight.w700, fontSize: 11)),
            const SizedBox(height: 12),
            SelectableText(ders.ornek, textDirection: TextDirection.rtl,
              textAlign: TextAlign.center, style: const TextStyle(
                fontFamily: kMushafFontu, fontSize: 30, color: kMetin, height: 1.8)),
          ]),
        ),
        const SizedBox(height: 20),
        Card(child: Padding(padding: const EdgeInsets.all(18), child:
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Kuralın açıklaması', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 10),
            SelectableText(ders.tanim, style: const TextStyle(fontSize: 16, height: 1.6)),
          ]))),
        const SizedBox(height: 12),
        Card(child: Padding(padding: const EdgeInsets.all(18), child:
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.lightbulb_outline_rounded, color: renk.primary),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Çalışma önerisi', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              Text(ders.ipucu, style: const TextStyle(height: 1.5)),
            ])),
          ]))),
        const SizedBox(height: 20),
        OutlinedButton.icon(
          onPressed: _degistir,
          icon: Icon(_kaydedildi ? Icons.bookmark_remove_rounded : Icons.bookmark_add_rounded),
          label: Text(_kaydedildi ? 'Kaydedilenlerden çıkar' : 'Tekrar için kaydet'),
        ),
      ]),
    );
  }
}
