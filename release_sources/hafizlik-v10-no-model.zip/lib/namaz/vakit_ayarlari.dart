import 'package:shared_preferences/shared_preferences.dart';

/// Yerel astronomik hesaplamayı resmî bir takvimle karşılaştırmak isteyenler
/// için her vakte özel dakika düzeltmesi. Varsayılan değerler sıfırdır.
class VakitAyarlari {
  static const vakitAdlari = <String>[
    'İmsak', 'Güneş', 'Öğle', 'İkindi', 'Akşam', 'Yatsı',
  ];

  static const _anahtar = 'vakit_duzeltmesi_';

  static Future<Map<String, int>> yukle() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      for (final ad in vakitAdlari)
        ad: (prefs.getInt('$_anahtar$ad') ?? 0).clamp(-30, 30).toInt(),
    };
  }

  static Future<void> kaydet(Map<String, int> duzeltmeler) async {
    final prefs = await SharedPreferences.getInstance();
    for (final ad in vakitAdlari) {
      await prefs.setInt('$_anahtar$ad', (duzeltmeler[ad] ?? 0).clamp(-30, 30).toInt());
    }
  }

  static Map<String, DateTime> uygula(
      Map<String, DateTime> vakitler, Map<String, int> duzeltmeler) {
    return {
      for (final e in vakitler.entries)
        e.key: e.value.add(Duration(minutes: duzeltmeler[e.key] ?? 0)),
    };
  }
}
