import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';
import 'vakit_ayarlari.dart';
import 'vakit_hesap.dart';

String _saat(DateTime t) =>
    '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

/// Ana ekran widget’ı için bugünkü vakitleri ve sıradaki vakti yazar.
/// Android tarafı bu anahtarları "FlutterSharedPreferences" dosyasından okur.
Future<void> vakitWidgetVerisiYaz(Map<String, DateTime> vakitler, {double? enlem, double? boylam, double? saatDilimi, Map<String, int> duzeltmeler = const {}}) async {
  if (vakitler.isEmpty) return;
  final prefs = await SharedPreferences.getInstance();
  final simdi = DateTime.now();

  String? sonrakiAd;
  DateTime? sonrakiZaman;
  for (final e in vakitler.entries) {
    if (e.value.isAfter(simdi)) {
      sonrakiAd = e.key;
      sonrakiZaman = e.value;
      break;
    }
  }
  if (sonrakiAd == null) {
    // Yatsıdan sonra: sıradaki vakit yarının imsakı.
    final ilk = vakitler.entries.first;
    sonrakiAd = ilk.key;
    sonrakiZaman = ilk.value.add(const Duration(days: 1));
  }

  final satirlar = vakitler.entries.map((e) => '${e.key} ${_saat(e.value)}').join('|');
  // Android widget provider bu zaman çizelgesini uygulama kapalıyken okur.
  // Gelecek 32 gün hesaplanır; telefonun ağ bağlantısı gerektirmez.
  if (enlem != null && boylam != null && saatDilimi != null) {
    final zamanlar = <String>[];
    final baslangic = DateTime(simdi.year, simdi.month, simdi.day);
    for (var gun = 0; gun < 32; gun++) {
      final v = VakitAyarlari.uygula(VakitHesap.gunVakitleri(
          DateTime(baslangic.year, baslangic.month, baslangic.day + gun),
          enlem, boylam, saatDilimi), duzeltmeler);
      for (final e in v.entries) {
        zamanlar.add('${e.value.millisecondsSinceEpoch},${e.key},${_saat(e.value)}');
      }
    }
    await prefs.setString('widget_zaman_cizelgesi', zamanlar.join('|'));
  }
  await prefs.setString('widget_satirlar', satirlar);
  await prefs.setString('widget_sonraki_ad', sonrakiAd);
  await prefs.setString('widget_sonraki_saat', _saat(sonrakiZaman!));
  // Açık uygulamadaki değişiklikler, widget'ın kendi alarmını beklemeden yansır.
  try {
    await const MethodChannel('hafizlik.app/widgets').invokeMethod<void>('refresh');
  } on MissingPluginException {
    // iOS veya henüz Android katmanı eklenmemiş geliştirme ortamı.
  } on PlatformException {
    // Widget işlemi başarısız olsa bile namaz vakitleri ekranı çalışmaya devam eder.
  }
}
