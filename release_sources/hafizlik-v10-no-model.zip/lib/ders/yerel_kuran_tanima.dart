import 'dart:async';
import 'dart:io';
import 'dart:isolate';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:sherpa_onnx/sherpa_onnx.dart' as sherpa;

/// Yalnızca cihazda çalışan Kur'an tilaveti tanıma sistemi.
///
/// - Ses PCM16, mono, 16 kHz olarak mikrofon üzerinden alınır.
/// - Kesinleşen parçalar, tek sefer yüklenen yerel ONNX modeliyle ayrı bir
///   isolate üzerinde çözümlenir; ses dosyaları ağa gönderilmez.
/// - Kısa duraklamalar ve sessizlik için parça sınırlarında tolerans kullanılır.
/// - Bu model hareke / mahreç / tecvid hükmü üretmez.
class YerelKuranTanima {
  YerelKuranTanima({required this.onText, required this.onError});

  final void Function(String) onText;
  final void Function(String) onError;
  final AudioRecorder _recorder = AudioRecorder();

  Isolate? _isolate;
  ReceivePort? _receivePort;
  SendPort? _sendPort;
  Completer<void>? _hazir;
  Completer<void>? _islerBitti;
  StreamSubscription<Uint8List>? _micSubscription;

  bool _dinliyor = false;
  bool _disposed = false;
  int _bekleyen = 0;
  int _istekNo = 0;
  final List<double> _samples = [];
  bool _soyluyor = false;
  int _sessizOrnekler = 0;
  double _gurultuEsigi = 0.004;

  static const _orneklemeHizi = 16000;
  static const _onBuffer = 4800; // 300 ms, kelime başını korur
  static const _enAzParca = 7200; // Kısa Arapça kelimeler için 0,45 saniye
  static const _enUzunParca = 16000 * 9; // Tek parçada en fazla 9 saniye
  static const _duraklama = 16000 * 0.72;

  bool get hazir => _sendPort != null;
  bool get dinliyor => _dinliyor;

  Future<void> hazirla() async {
    if (_disposed) throw StateError('Tanıma servisi kapatıldı.');
    if (_sendPort != null) return;
    if (_hazir != null) return _hazir!.future;
    _hazir = Completer<void>();
    try {
      final dir = await getApplicationSupportDirectory();
      final modelPath = await _assetKopyala(
        'assets/asr/model.int8.onnx', '${dir.path}/quran_asr_small/model.int8.onnx');
      final tokensPath = await _assetKopyala(
        'assets/asr/tokens.txt', '${dir.path}/quran_asr_small/tokens.txt');
      if (_disposed) throw StateError('Tanıma servisi kapatıldı.');
      _receivePort = ReceivePort();
      _receivePort!.listen(_workerMesaji);
      _isolate = await Isolate.spawn<List<Object>>(
        _modelWorker, [_receivePort!.sendPort, modelPath, tokensPath],
        debugName: 'yerel-kuran-asr',
      );
    } catch (e) {
      if (!(_hazir?.isCompleted ?? true)) _hazir!.completeError(e);
    }
    return _hazir!.future;
  }

  static Future<String> _assetKopyala(String asset, String target) async {
    final bytes = await rootBundle.load(asset);
    final file = File(target);
    if (await file.exists() && await file.length() == bytes.lengthInBytes) {
      return file.path;
    }
    await file.parent.create(recursive: true);
    // İlk kurulumdan sonraki açılışlarda 36 MB'lık model tekrar kopyalanmaz.
    await file.writeAsBytes(bytes.buffer.asUint8List(bytes.offsetInBytes, bytes.lengthInBytes), flush: true);
    return file.path;
  }

  void _workerMesaji(dynamic message) {
    if (_disposed || message is! List || message.isEmpty) return;
    switch (message.first) {
      case 'ready':
        _sendPort = message[1] as SendPort;
        if (!(_hazir?.isCompleted ?? true)) _hazir!.complete();
        break;
      case 'text':
        _bekleyen = math.max(0, _bekleyen - 1);
        final text = (message[2] as String).trim();
        if (text.isNotEmpty) onText(text);
        _bitisKontrol();
        break;
      case 'failure':
        final detail = message[1].toString();
        if (!(_hazir?.isCompleted ?? true)) _hazir!.completeError(StateError(detail));
        else {
          _bekleyen = math.max(0, _bekleyen - 1);
          onError('Çevrimdışı tanıma hatası: $detail');
          _bitisKontrol();
        }
        break;
    }
  }

  void _bitisKontrol() {
    if (_bekleyen == 0 && _islerBitti != null && !_islerBitti!.isCompleted) {
      _islerBitti!.complete();
    }
  }

  Future<void> baslat() async {
    if (_dinliyor) return;
    await hazirla();
    if (_disposed) return;
    if (!await _recorder.hasPermission()) {
      throw StateError('Mikrofon izni verilmedi.');
    }
    _samples.clear();
    _soyluyor = false;
    _sessizOrnekler = 0;
    _gurultuEsigi = 0.004;
    final stream = await _recorder.startStream(const RecordConfig(
      encoder: AudioEncoder.pcm16bits,
      sampleRate: _orneklemeHizi,
      numChannels: 1,
      autoGain: true,
      echoCancel: false,
      noiseSuppress: false,
    ));
    _dinliyor = true;
    _micSubscription = stream.listen(_sesPaketi, onError: (Object error) {
      _dinliyor = false;
      onError('Mikrofon okunamadı: $error');
    });
  }

  void _sesPaketi(Uint8List bytes) {
    if (!_dinliyor || bytes.length < 2) return;
    final sampleCount = bytes.length ~/ 2;
    final data = ByteData.sublistView(bytes);
    final frame = List<double>.filled(sampleCount, 0);
    var power = 0.0;
    for (var i = 0; i < sampleCount; i++) {
      final v = data.getInt16(i * 2, Endian.little) / 32768.0;
      frame[i] = v;
      power += v * v;
    }
    final rms = math.sqrt(power / sampleCount);
    final threshold = math.max(0.005, _gurultuEsigi * 2.1);
    final isVoice = rms > threshold;

    if (!_soyluyor) {
      // Sessiz ortamdaki taban gürültüsü eşik olarak izlenir.
      if (!isVoice) _gurultuEsigi = 0.96 * _gurultuEsigi + 0.04 * rms;
      _samples.addAll(frame);
      if (_samples.length > _onBuffer) {
        _samples.removeRange(0, _samples.length - _onBuffer);
      }
      if (isVoice) {
        _soyluyor = true;
        _sessizOrnekler = 0;
      }
      return;
    }

    _samples.addAll(frame);
    _sessizOrnekler = isVoice ? 0 : _sessizOrnekler + sampleCount;
    if ((_sessizOrnekler >= _duraklama && _samples.length >= _enAzParca) ||
        _samples.length >= _enUzunParca) {
      _gonder();
    }
  }

  void _gonder() {
    if (!_soyluyor || _samples.length < _enAzParca || _sendPort == null) {
      _samples.clear();
      _soyluyor = false;
      _sessizOrnekler = 0;
      return;
    }
    // Uzun sessizliklerde hayali kelime üretmesini önlemek için sessizliği
    // gereksiz uzatmıyoruz; sonraki kelimeyi kesmemek için kısa ön pay saklanır.
    final audio = Float32List.fromList(_samples);
    final previous = _samples.length > _onBuffer
        ? _samples.sublist(_samples.length - _onBuffer) : List<double>.from(_samples);
    _samples
      ..clear()
      ..addAll(previous);
    _soyluyor = false;
    _sessizOrnekler = 0;
    _bekleyen++;
    _sendPort!.send({'kind': 'decode', 'seq': _istekNo++, 'samples': audio});
  }

  Future<void> durdur() async {
    if (!_dinliyor && _bekleyen == 0) return;
    _dinliyor = false;
    await _recorder.stop();
    await _micSubscription?.cancel();
    _micSubscription = null;
    _gonder();
    if (_bekleyen > 0) {
      _islerBitti = Completer<void>();
      try {
        await _islerBitti!.future.timeout(const Duration(seconds: 60));
      } on TimeoutException {
        onError('Ses çözümleme zaman aşımına uğradı.');
      } finally {
        _islerBitti = null;
      }
    }
  }

  void sifirla() {
    _samples.clear();
    _soyluyor = false;
    _sessizOrnekler = 0;
  }

  Future<void> kapat() async {
    if (_disposed) return;
    _dinliyor = false;
    try { await _recorder.stop(); } catch (_) { /* mikrofon zaten kapalı */ }
    await _micSubscription?.cancel();
    _micSubscription = null;
    await _recorder.dispose();
    _sendPort?.send({'kind': 'close'});
    _receivePort?.close();
    // 'close' komutu model belleğini kendi isolate'inde serbest bırakır.
    _isolate = null;
    _disposed = true;
  }
}

/// Yerel model yalnızca bu isolate'de açılır; UI iş parçacığı bloke edilmez.
void _modelWorker(List<Object> arguments) {
  final main = arguments[0] as SendPort;
  final model = arguments[1] as String;
  final tokens = arguments[2] as String;
  final requests = ReceivePort();
  sherpa.OfflineRecognizer? recognizer;
  try {
    sherpa.initBindings();
    recognizer = sherpa.OfflineRecognizer(sherpa.OfflineRecognizerConfig(
      model: sherpa.OfflineModelConfig(
        zipformerCtc: sherpa.OfflineZipformerCtcModelConfig(model: model),
        tokens: tokens,
        numThreads: 2,
        debug: false,
      ),
    ));
    main.send(['ready', requests.sendPort]);
  } catch (e) {
    main.send(['failure', e.toString()]);
    requests.close();
    return;
  }

  requests.listen((dynamic request) {
    if (request is! Map) return;
    if (request['kind'] == 'close') {
      requests.close();
      recognizer?.free();
      return;
    }
    if (request['kind'] != 'decode') return;
    sherpa.OfflineStream? stream;
    try {
      stream = recognizer!.createStream();
      stream.acceptWaveform(
        samples: request['samples'] as Float32List,
        sampleRate: 16000,
      );
      recognizer!.decode(stream);
      final text = recognizer!.getResult(stream).text;
      main.send(['text', request['seq'], text]);
    } catch (e) {
      main.send(['failure', e.toString()]);
    } finally {
      stream?.free();
    }
  });
}
