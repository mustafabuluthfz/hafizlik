# V10 sürüm notları ve APK test planı

## Yapılanlar
- Açılış animasyon süresi yaklaşık iki saniyeye indirildi.
- Altı klasörlü Tecvid Akademisi, arama ve kaydedilen dersler eklendi.
- Namaz vakitleri paneli ve ±30 dk/vakit ayarları eklendi. Bu ayarlar ana ekran, widget ve bildirimlere uygulanır.
- Widget çizelgesi 32 gün olarak hazırlandı; Flutter/Android MethodChannel ile anında yenileme köprüsü oluşturuldu.
- Türkçe yerelleştirme, karanlık tema ve küçük kart tasarımları iyileştirildi.
- Yayınlanmamış Play Store bağlantısı kaldırıldı; uygulama içi açık kaynak lisansı sayfası açıldı.
- V9 yerel Kur’an ses tanıma modeli korundu.

## Test gerekir
1. GitHub Actions içinde `Flutter kodunu denetle` ve `APK derle` adımlarının başarılı olduğundan emin olun.
2. Uygulamayı ilk kez ve ikinci kez açın, açılış süresini kontrol edin.
3. Tecvid Akademisi'nde tüm klasörleri açın; ders araması ve kaydetme işlemini deneyin.
4. Namaz Vakitleri'nde konum izni verin, saatleri resmî takvimle karşılaştırın, dakika düzeltmesi yapın.
5. Ana ekran widget'ı ekleyip ayar güncellemesinden sonra saatin değiştiğini kontrol edin. Uygulama kapalıyken vakit geçişini gözleyin.
6. Ders Dinlet'i uçak modunda test edin. İlk model hazırlığı, mikrofon izni, kısa ve uzun okuma, duraklama ve sonuç ekranını kontrol edin.
7. Koyu tema, küçük ekran ve büyük yazı ayarlarında kartların taşmadığını kontrol edin.

## Sınırlar
- Astronomik yerel vakit tahminleri Diyanet'in resmî takvimi değildir.
- 32 gün sonunda widget çizelgesinin yenilenmesi için uygulamanın yeniden açılması gerekir.
- Çevrimdışı modelin tüm Kur’an kelimelerini doğru algıladığı henüz cihaz üzerinde doğrulanmamıştır.
- APK henüz bu ortamda üretilip telefon üzerinde test edilmemiştir.
