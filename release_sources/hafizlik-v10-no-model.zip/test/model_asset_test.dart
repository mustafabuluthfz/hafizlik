import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('Kur’an ses modeli ve token sözlüğü APK asset olarak eklenir', () async {
    final model = await rootBundle.load('assets/asr/model.int8.onnx');
    final tokens = await rootBundle.loadString('assets/asr/tokens.txt');
    final notice = await rootBundle.loadString('assets/asr/LICENSE.txt');
    expect(model.lengthInBytes, greaterThan(30000000));
    expect(tokens, contains('▁ 30'));
    expect(notice, contains('MIT License'));
  });
}
