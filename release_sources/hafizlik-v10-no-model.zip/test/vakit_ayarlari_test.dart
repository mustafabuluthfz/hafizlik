import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hafizlik_app/namaz/vakit_ayarlari.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() => SharedPreferences.setMockInitialValues({}));

  test('vakit düzeltmeleri cihaz tercihinde saklanır', () async {
    final ilk = await VakitAyarlari.yukle();
    expect(ilk.length, 6);
    expect(ilk.values.every((n) => n == 0), isTrue);

    await VakitAyarlari.kaydet({'İmsak': -5, 'Akşam': 7, 'Öğle': 49});
    final yeni = await VakitAyarlari.yukle();
    expect(yeni['İmsak'], -5);
    expect(yeni['Akşam'], 7);
    expect(yeni['Öğle'], 30); // ±30 dakika sınırı
    expect(yeni['Yatsı'], 0);
  });

  test('dakika düzeltmeleri mevcut hesaplamayı değiştirmeden uygulanır', () {
    final orijinal = {'Öğle': DateTime(2026, 11, 23, 12, 20)};
    final yeni = VakitAyarlari.uygula(orijinal, {'Öğle': -12});
    expect(orijinal['Öğle']!.minute, 20);
    expect(yeni['Öğle']!.hour, 12);
    expect(yeni['Öğle']!.minute, 8);
  });
}
