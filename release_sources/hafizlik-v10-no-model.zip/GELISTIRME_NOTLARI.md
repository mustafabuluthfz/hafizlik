# Arayüz ve Widget Güncellemesi

- Ana ekrana tek dokunuşla Ders Dinlet, Kur’an Oku, Tecvid, Kıble ve Ses Kütüphanesi kısayolları eklendi.
- Bölüm kartları dar ve geniş ekranlarda 2/3/4 sütuna uyarlanıyor.
- Namaz ekranındaki sıradaki vakit kartı koyu yeşil vurgulu tasarıma geçirildi.
- Android ana ekranında ayrı ayrı seçilebilen üç widget: kompakt, orta, geniş. Widget yerleşimleri yeniden boyutlandırılabilir.
- Widget’ların ilk verileri Namaz Vakitleri ekranı açıldığında oluşturulur. Gün değişiminde ve uygulama kapalıyken doğru vakit yenileme garantisi için Android arka plan zamanlayıcısı ve hesaplama senkronizasyonu ayrıca gereklidir.
- Flutter SDK / Android derlemesi bu ortamda çalıştırılmadı. Cihaz üzerinde derleme, widget ve erişilebilirlik testi yapılmalıdır.
