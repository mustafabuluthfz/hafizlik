# V9: Sunucusuz Kur’an Ses Tanıma

Bu sürümde **Ders Dinlet**, Android sisteminin Arapça tanıma hizmetini kullanmaz. Kullanıcının yüklediği `model.int8.onnx` ve `tokens.txt`, `assets/asr/` altından ilk açılışta uygulamanın özel dosya alanına kopyalanır. Flutter `sherpa_onnx` eklentisi modeli yerel olarak açar; mikrofondan alınan **16 kHz, mono PCM16** ses 0,45–9 saniyelik parçalar halinde ayrı bir isolate üzerinde çözülür. Ses veya metin hiçbir harici ASR sunucusuna gönderilmez.

İlk kez Ders Dinlet açıldığında model yüklenirken zaman gerekebilir; sonraki açılışlarda dosya tekrar kopyalanmaz. Yerel çıkarım, cihazın işlemcisi, belleği, mikrofonu ve ortam gürültüsüne bağlıdır. Kelime işaretleri ASR metin çıktısına dayanır; **hareke, mahreç ve tecvid hataları otomatik ve güvenilir biçimde ölçülmez**. Yanlış tanıma, doğru okunan bir kelimeyi de kırmızı gösterebilir.

Kurulum için Flutter SDK ile `flutter pub get` ve `flutter build apk --release` gerekir. Projede Android platformu yoksa GitHub Actions yapılandırması önce `flutter create --platforms=android --project-name hafizlik_app --org com.hafizlik.app .` komutunu çalıştırır.

Modelin lisansı MIT'dir; bildirim `assets/asr/LICENSE.txt` içinde APK'ya dahildir. Diğer telif bildirimleri `licenses/` klasöründedir.

**Doğrulama kapsamı:** Model dosyalarının hash'leri ve ZIP bütünlüğü kontrol edilmiştir; Flutter SDK ve gerçek Android cihaz olmadığı için bu ortamda APK derlemesi veya ses algılama başarı testi yapılamamıştır.
