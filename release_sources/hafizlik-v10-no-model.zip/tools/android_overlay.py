#!/usr/bin/env python3
"""Install three Android prayer widgets after flutter create."""
import re
import shutil
from pathlib import Path
ana = Path('android/app/src/main')
ov = Path('android_overlay')
activity = next(ana.rglob('MainActivity.kt'), None)
if activity is None:
    raise SystemExit('MainActivity.kt bulunamadı')
package = re.search(r'^package\s+([\w.]+)', activity.read_text(encoding='utf-8'), re.M).group(1)
code = (ov/'kotlin/VakitWidgetProvider.kt').read_text(encoding='utf-8').replace('__PACKAGE__', package)
(activity.parent/'VakitWidgetProvider.kt').write_text(code, encoding='utf-8')
# flutter create ile üretilen MainActivity içine Flutter -> Android yenileme köprüsü.
# Provider'ın yayın süresini beklemek yerine ayar değişince widget'lar güncellenir.
activity.write_text(f'''package {package}

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {{
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {{
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "hafizlik.app/widgets")
            .setMethodCallHandler {{ call, result ->
                when (call.method) {{
                    "refresh" -> {{
                        VakitWidgetProvider.refreshAll(applicationContext)
                        result.success(null)
                    }}
                    else -> result.notImplemented()
                }}
            }}
    }}
}}
''', encoding='utf-8')
for sub in ('layout', 'xml', 'drawable'):
    target = ana/'res'/sub
    target.mkdir(parents=True, exist_ok=True)
    for src in (ov/'res'/sub).glob('*.xml'):
        shutil.copy(src, target/src.name)
manifest = ana/'AndroidManifest.xml'
s = manifest.read_text(encoding='utf-8')
providers = [('VakitWidgetKompaktProvider', 'Kompakt Namaz Vakitleri', 'vakit_widget_kompakt_info'),
             ('VakitWidgetProvider', 'Namaz Vakitleri', 'vakit_widget_orta_info'),
             ('VakitWidgetGenisProvider', 'Geniş Namaz Vakitleri', 'vakit_widget_genis_info')]
for name, label, meta in providers:
    if f'android:name=".{name}"' in s:
        continue
    receiver = f"""        <receiver android:name=".{name}" android:exported="false" android:label="{label}">
            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE" /></intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/{meta}" />
        </receiver>
"""
    s = s.replace('</application>', receiver+'</application>', 1)
if 'VakitWidgetRefreshReceiver' not in s:
    s = s.replace('</application>', '        <receiver android:name=".VakitWidgetRefreshReceiver" android:exported="false" />\n</application>', 1)
manifest.write_text(s, encoding='utf-8')
print('3 Android widget installed:', package)
