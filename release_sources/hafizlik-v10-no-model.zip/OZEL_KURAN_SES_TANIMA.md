# Özel Kur’an ses tanıma entegrasyonu (V6)

Ders Dinlet ekranında **Özel Kur’an modeliyle dinlet** seçeneği eklendi. Bu bir **entegrasyon istemcisidir**, uygulama içine hazır eğitilmiş bir model eklenmemiştir. Çalışması için kullanıcının kontrol ettiği bir HTTPS sunucusunda Kur’an tilavetini tanıyabilen ASR modeli gereklidir.

## Sunucu sözleşmesi

- `POST https://sunucunuz.example/transcribe`
- `multipart/form-data`: `audio` (16 kHz mono WAV), `language=ar`, `reference_text` (sayfanın Arapça metni).
- Başarılı yanıt: HTTP 200 ve JSON `{"text": "بسم الله الرحمن الرحيم"}`.
- Sunucu modelini uygulama sağlamaz; bir model kurulmadıysa bu seçenek çalışmaz.
- **Gizlilik:** Kayıt sadece kullanıcının özel modu seçip kaydı bitirmesiyle girilen adrese yüklenir. Hassas ses verilerini üçüncü taraf sunuculara göndermeden önce güvenilirliği kontrol edin. Sunucuda saklama politikasını ayrıca belirleyin.
- Telefonun standart konuşma tanıması alternatif olarak çalışmaya devam eder.
- Hatalı tanınan kelimeler kesin okuma hatası değildir; öğretmen doğrulaması gerekir.

## Derleme

`flutter pub get` ve `flutter build apk --release`. Bu ortamda Flutter SDK olmadığından derleme doğrulanamadı.
