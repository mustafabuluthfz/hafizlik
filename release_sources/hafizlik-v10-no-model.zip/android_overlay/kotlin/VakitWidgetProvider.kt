package __PACKAGE__

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Build
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Widget reads 32 days of precomputed local prayer times. */
open class VakitWidgetProvider : AppWidgetProvider() {
    protected open val layoutId: Int get() = R.layout.vakit_widget
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == "__PACKAGE__.VAKIT_REFRESH" || intent.action == Intent.ACTION_TIME_CHANGED ||
            intent.action == Intent.ACTION_TIMEZONE_CHANGED || intent.action == Intent.ACTION_DATE_CHANGED) {
            refreshAll(context)
        }
    }
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
        scheduleNext(context)
    }
    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, id: Int, options: Bundle) {
        updateOne(context, manager, id)
    }
    protected open fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
        val prefs = context.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val rows = parseRows(context).filter { it.first >= now - 60000L }
        val next = rows.firstOrNull()
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(Date(now))
        val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT)
        val todayRows = parseRows(context).filter { formatter.format(Date(it.first)) == today }
        val fallback = prefs.getString("flutter.widget_satirlar", "") ?: ""
        val summary = if (todayRows.isNotEmpty()) todayRows.joinToString("    •    ") { "${it.second} ${it.third}" }
                      else if (rows.isEmpty()) "Vakitleri yenilemek için uygulamayı açın" else fallback.replace("|", "    •    ")
        val views = RemoteViews(context.packageName, layoutId)
        views.setTextViewText(R.id.sonraki_ad, if (next == null) "NAMAZ VAKİTLERİ" else "SIRADAKİ · ${next.second}")
        views.setTextViewText(R.id.sonraki_saat, next?.third ?: "--:--")
        views.setTextViewText(R.id.satirlar, summary)
        val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
        if (launch != null) {
            val pi = PendingIntent.getActivity(context, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.kok, pi)
        }
        manager.updateAppWidget(id, views)
    }
    companion object {
        private fun parseRows(context: Context): List<Triple<Long, String, String>> {
            val prefs = context.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
            return (prefs.getString("flutter.widget_zaman_cizelgesi", "") ?: "").split("|").mapNotNull {
                val fields = it.split(",", limit = 3)
                if (fields.size != 3) null else fields[0].toLongOrNull()?.let { time -> Triple(time, fields[1], fields[2]) }
            }.sortedBy { it.first }
        }
        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val providers = listOf(VakitWidgetProvider(), VakitWidgetKompaktProvider(), VakitWidgetGenisProvider())
            val classes = listOf(VakitWidgetProvider::class.java, VakitWidgetKompaktProvider::class.java, VakitWidgetGenisProvider::class.java)
            for (i in providers.indices) {
                val ids = manager.getAppWidgetIds(android.content.ComponentName(context, classes[i]))
                ids.forEach { providers[i].updateOne(context, manager, it) }
            }
            scheduleNext(context)
        }
        private fun scheduleNext(context: Context) {
            val now = System.currentTimeMillis()
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, VakitWidgetRefreshReceiver::class.java).setAction("__PACKAGE__.VAKIT_REFRESH")
            val pi = PendingIntent.getBroadcast(context, 2001, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val manager = AppWidgetManager.getInstance(context)
            val active = listOf(VakitWidgetProvider::class.java,
                VakitWidgetKompaktProvider::class.java, VakitWidgetGenisProvider::class.java)
                .any { manager.getAppWidgetIds(android.content.ComponentName(context, it)).isNotEmpty() }
            if (!active) {
                // Ana ekranda widget yokken gereksiz arka plan alarmı kurma.
                alarm.cancel(pi)
                return
            }
            val next = parseRows(context).firstOrNull { it.first > now + 5000L }?.first
            // Pil dostu; exact alarm izni gerektirmez. Android alarmı geciktirebilir.
            val target = minOf(next ?: now + 30 * 60000L, now + 30 * 60000L)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target, pi)
            } else {
                alarm.set(AlarmManager.RTC_WAKEUP, target, pi)
            }
        }
    }
}
class VakitWidgetKompaktProvider : VakitWidgetProvider() { override val layoutId get() = R.layout.vakit_widget_kompakt }
class VakitWidgetGenisProvider : VakitWidgetProvider() { override val layoutId get() = R.layout.vakit_widget_genis }
class VakitWidgetRefreshReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) { VakitWidgetProvider.refreshAll(context) }
}
