# Mushaf Yoldaşım V17

- Telefonlarda Kur’an / Hafızlık / Araçlar katalogları büyük kare kutular yerine tek sütunlu yatay, 75 piksel yüksekliğinde kartlarla gösterilir. Tabletlerde iki sütun kullanılır.
- Ana ekran hızlı işlemleri 66 piksel yüksekliğine düşürüldü; kare arka plan yerine ince çerçeveli dairesel renkli ikonlar kullanıldı.
- Alt menü ikonları daha küçük ve bölüm bazında renkli hale getirildi.
- Tecvit klasörleri ve karşılama ikonları küçültüldü.
- Sayfa çevirme: tam ekran 3B eksende dönme yerine, hedef sayfanın üzerinde kavisli yaprak kenarı, kıvrılan sayfanın arkası ve doğal gölge animasyonu.
- Mevcut sayfa, cüz, sûre, ayet seçimi; tam sayfa ve tek ayet dinleme; sayfa sesi ve Ders Dinlet korunur.
- Version 2.8.0+21.
