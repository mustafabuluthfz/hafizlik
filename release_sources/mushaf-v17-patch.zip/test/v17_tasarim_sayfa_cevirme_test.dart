import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hafizlik_app/kuran/kitap_sayfa_cevirici.dart';

void main() {
  test('Büyük kare bölüm kartları mobilde kaldırıldı', () {
    final kaynak = File('lib/main.dart').readAsStringSync();
    expect(kaynak, contains('final sutun = genislik >= 650 ? 2 : 1'));
    expect(kaynak, contains('mainAxisExtent: 75'));
    expect(kaynak, contains('shape: BoxShape.circle'));
    expect(kaynak, contains('class _KucukRenkliIkon'));
  });

  testWidgets('Kitap yaprağı dönerken alttaki yeni sayfa görünür', (tester) async {
    var sayfa = 1;
    await tester.pumpWidget(MaterialApp(home: Scaffold(
      body: StatefulBuilder(builder: (context, yenile) =>
        SizedBox(width: 320, height: 500, child: KitapSayfaCevirici(
          sayfa: sayfa,
          toplam: 604,
          sayfaOlustur: (no) => ColoredBox(
            color: const Color(0xFFFFFAEB),
            child: Center(child: Text('Sayfa $no')),
          ),
          onSayfaIste: (no) => yenile(() => sayfa = no),
        )),
      ),
    )));
    await tester.drag(find.text('Sayfa 1'), const Offset(170, 0));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 260));
    expect(find.text('Sayfa 2'), findsOneWidget);
    expect(find.byType(ClipPath), findsWidgets);
    await tester.pumpAndSettle();
    expect(find.text('Sayfa 1'), findsNothing);
    expect(find.text('Sayfa 2'), findsOneWidget);
  });
}
