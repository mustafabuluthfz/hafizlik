import 'dart:async';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../bildirim/bildirim_servisi.dart';
import '../konum/konum_servisi.dart';
import '../ortak/ikonlar.dart';
import '../ortak/tema.dart';
import 'vakit_ayarlari.dart';
import 'vakit_hesap.dart';
import 'vakit_widget_veri.dart';

class NamazEkrani extends StatefulWidget {
  const NamazEkrani({super.key});

  @override
  State<NamazEkrani> createState() => _NamazEkraniState();
}

class _NamazEkraniState extends State<NamazEkrani>
    with WidgetsBindingObserver {
  bool _yukleniyor = true;
  String? _hata;
  KonumBilgisi? _konum;
  Map<String, DateTime> _vakitler = {};
  Map<String, int> _duzeltmeler = {};
  DateTime? _hesaplananGun;

  bool _namazBildirim = false;
  bool _hatirlatmaAcik = false;
  TimeOfDay _hatirlatmaSaati = const TimeOfDay(hour: 20, minute: 0);
  Timer? _sayac;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _baslat();
    _sayac = Timer.periodic(const Duration(seconds: 30), (_) {
      if (!mounted) return;
      final bugun = DateTime.now();
      final hesap = _hesaplananGun;
      if (hesap != null &&
          (hesap.day != bugun.day || hesap.month != bugun.month || hesap.year != bugun.year)) {
        _guncelle();
      } else {
        setState(() {}); // Sıradaki vakit için geri sayım.
      }
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && _konum != null) _guncelle();
  }

  @override
  void dispose() {
    _sayac?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> _baslat() async {
    final prefs = await SharedPreferences.getInstance();
    final duzeltmeler = await VakitAyarlari.yukle();
    if (!mounted) return;
    setState(() {
      _duzeltmeler = duzeltmeler;
      _namazBildirim = prefs.getBool('bildirim_namaz') ?? false;
      _hatirlatmaAcik = prefs.getBool('bildirim_hatirlatma') ?? false;
      _hatirlatmaSaati = TimeOfDay(
        hour: (prefs.getInt('hatirlatma_saat') ?? 20).clamp(0, 23).toInt(),
        minute: (prefs.getInt('hatirlatma_dakika') ?? 0).clamp(0, 59).toInt(),
      );
    });
    await _konumAl();
  }

  double get _saatDilimi => DateTime.now().timeZoneOffset.inMinutes / 60.0;

  Map<String, DateTime> _hesapla(DateTime gun) {
    final konum = _konum;
    if (konum == null) return {};
    return VakitAyarlari.uygula(
      VakitHesap.gunVakitleri(gun, konum.enlem, konum.boylam, _saatDilimi),
      _duzeltmeler,
    );
  }

  Future<void> _konumAl() async {
    if (!mounted) return;
    setState(() { _yukleniyor = true; _hata = null; });
    final konum = await KonumServisi.al();
    if (!mounted) return;
    if (konum == null) {
      setState(() {
        _hata = 'Konum alınamadı. Konum iznini kontrol edip tekrar deneyin.';
        _yukleniyor = false;
      });
      return;
    }
    _konum = konum;
    await _guncelle();
  }

  Future<void> _guncelle() async {
    if (!mounted || _konum == null) return;
    final simdi = DateTime.now();
    final vakitler = _hesapla(simdi);
    _hesaplananGun = DateTime(simdi.year, simdi.month, simdi.day);
    if (mounted) {
      setState(() {
        _vakitler = vakitler;
        _hata = vakitler.isEmpty ? 'Bu konumda vakitler hesaplanamadı.' : null;
        _yukleniyor = false;
      });
    }
    if (vakitler.isEmpty) return;
    final konum = _konum!;
    await vakitWidgetVerisiYaz(vakitler,
      enlem: konum.enlem, boylam: konum.boylam,
      saatDilimi: _saatDilimi, duzeltmeler: _duzeltmeler);
    await _planla();
  }

  Future<void> _planla() async {
    final liste = <MapEntry<String, DateTime>>[];
    if (_konum != null && _namazBildirim) {
      final bugun = DateTime.now();
      for (var gun = 0; gun < 7; gun++) {
        final tarih = DateTime(bugun.year, bugun.month, bugun.day + gun);
        liste.addAll(_hesapla(tarih).entries);
      }
    }
    await BildirimServisi.planla(
      namazVakitleri: liste,
      hatirlatma: _hatirlatmaAcik ? _hatirlatmaSaati : null,
    );
  }

  Future<void> _namazBildirimDegistir(bool acik) async {
    if (acik) await BildirimServisi.izinIste();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('bildirim_namaz', acik);
    if (!mounted) return;
    setState(() => _namazBildirim = acik);
    await _planla();
  }

  Future<void> _hatirlatmaDegistir(bool acik) async {
    if (acik) await BildirimServisi.izinIste();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('bildirim_hatirlatma', acik);
    if (!mounted) return;
    setState(() => _hatirlatmaAcik = acik);
    await _planla();
  }

  Future<void> _saatSec() async {
    final secim = await showTimePicker(
        context: context, initialTime: _hatirlatmaSaati);
    if (secim == null) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('hatirlatma_saat', secim.hour);
    await prefs.setInt('hatirlatma_dakika', secim.minute);
    if (!mounted) return;
    setState(() => _hatirlatmaSaati = secim);
    await _planla();
  }

  Future<void> _dakikaDuzelt() async {
    final secimler = Map<String, int>.from(_duzeltmeler);
    final yeni = await showModalBottomSheet<Map<String, int>>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (sheetContext, guncelle) => SafeArea(
          top: false,
          child: Padding(
            padding: EdgeInsets.fromLTRB(20, 4, 20,
                MediaQuery.of(sheetContext).viewInsets.bottom + 20),
            child: ConstrainedBox(
              constraints: BoxConstraints(maxHeight:
                  MediaQuery.of(sheetContext).size.height * 0.76),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Text('Vakitleri ayarla', style: Theme.of(sheetContext).textTheme.titleLarge),
                const SizedBox(height: 8),
                const Text('Düzeltmeler yalnızca bu cihazda saklanır. Resmî takvimle '
                    'karşılaştırarak her vakti ±30 dakika ayarlayabilirsiniz.'),
                const SizedBox(height: 12),
                Flexible(child: ListView(shrinkWrap: true, children: [
                  for (final ad in VakitAyarlari.vakitAdlari)
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(ad),
                      subtitle: Text((secimler[ad] ?? 0) == 0 ? 'Düzeltme yok' :
                        '${(secimler[ad] ?? 0) > 0 ? '+' : ''}${secimler[ad]} dakika'),
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                        IconButton(
                          tooltip: '$ad vaktini 1 dakika erkene al',
                          onPressed: (secimler[ad] ?? 0) <= -30 ? null :
                              () => guncelle(() => secimler[ad] = (secimler[ad] ?? 0) - 1),
                          icon: const Icon(Icons.remove_circle_outline),
                        ),
                        SizedBox(width: 34, child: Text('${secimler[ad] ?? 0}',
                            textAlign: TextAlign.center)),
                        IconButton(
                          tooltip: '$ad vaktini 1 dakika ileri al',
                          onPressed: (secimler[ad] ?? 0) >= 30 ? null :
                              () => guncelle(() => secimler[ad] = (secimler[ad] ?? 0) + 1),
                          icon: const Icon(Icons.add_circle_outline),
                        ),
                      ]),
                    ),
                ])),
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(child: OutlinedButton(
                    onPressed: () => guncelle(() {
                      for (final ad in VakitAyarlari.vakitAdlari) secimler[ad] = 0;
                    }),
                    child: const Text('Sıfırla'),
                  )),
                  const SizedBox(width: 12),
                  Expanded(child: FilledButton(
                    onPressed: () => Navigator.pop(sheetContext, secimler),
                    child: const Text('Kaydet'),
                  )),
                ]),
              ]),
            ),
          ),
        ),
      ),
    );
    if (yeni == null) return;
    await VakitAyarlari.kaydet(yeni);
    if (!mounted) return;
    setState(() => _duzeltmeler = yeni);
    await _guncelle();
  }

  String _saat(DateTime tarih) =>
      '${tarih.hour.toString().padLeft(2, '0')}:${tarih.minute.toString().padLeft(2, '0')}';

  (String, DateTime)? _sonraki() {
    final simdi = DateTime.now();
    for (final e in _vakitler.entries) {
      if (e.value.isAfter(simdi)) return (e.key, e.value);
    }
    final yarin = _hesapla(DateTime(simdi.year, simdi.month, simdi.day + 1));
    if (yarin.isEmpty) return null;
    final ilk = yarin.entries.first;
    return (ilk.key, ilk.value);
  }

  String _kalanYazi(Duration fark) {
    final toplam = fark.inMinutes < 0 ? 0 : fark.inMinutes;
    return '${toplam ~/ 60} saat ${toplam % 60} dakika';
  }

  IconData _vakitIkonu(String ad) {
    switch (ad) {
      case 'İmsak': return Icons.dark_mode_outlined;
      case 'Güneş': return Icons.wb_twilight_rounded;
      case 'Öğle': return Icons.wb_sunny_outlined;
      case 'İkindi': return Icons.wb_cloudy_outlined;
      case 'Akşam': return Icons.nights_stay_outlined;
      default: return Icons.bedtime_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Namaz Vakitleri'), actions: [
        IconButton(
          tooltip: 'Vakit düzeltme ayarları',
          icon: const Icon(Icons.tune_rounded), onPressed: _dakikaDuzelt,
        ),
        IconButton(
          tooltip: 'Konumu ve vakitleri yenile',
          icon: const Icon(AppIkonlari.konum), onPressed: _konumAl,
        ),
      ]),
      body: _yukleniyor
          ? const Center(child: CircularProgressIndicator())
          : _hata != null
              ? Center(child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.location_off_outlined, size: 27),
                    const SizedBox(height: 12),
                    Text(_hata!, textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      onPressed: _konumAl,
                      icon: const Icon(Icons.refresh_rounded),
                      label: const Text('Tekrar dene'),
                    ),
                  ]),
                ))
              : RefreshIndicator(onRefresh: _konumAl, child: _icerik()),
    );
  }

  Widget _icerik() {
    final renk = Theme.of(context).colorScheme;
    final simdi = DateTime.now();
    final sonraki = _sonraki();
    final kalan = sonraki == null ? null : sonraki.$2.difference(simdi);
    final duzeltilen = _duzeltmeler.values.any((d) => d != 0);
    return ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 32), children: [
      Container(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF0B3936), Color(0xFF16816E)],
          ),
          borderRadius: BorderRadius.circular(26),
          boxShadow: [BoxShadow(color: kYesil.withOpacity(.18),
              blurRadius: 24, offset: const Offset(0, 9))],
        ),
        child: Stack(children: [
          Positioned(top: -42, right: -44, child: Container(
            width: 170, height: 170,
            decoration: BoxDecoration(shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(.11), width: 23)),
          )),
          Padding(padding: const EdgeInsets.all(22), child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                const Icon(Icons.location_on_outlined, size: 16, color: Color(0xFFE4D6A9)),
                const SizedBox(width: 6),
                Expanded(child: Text(_konum == null ? 'Konum bulunamadı' :
                  '${_konum!.enlem.toStringAsFixed(2)}°, ${_konum!.boylam.toStringAsFixed(2)}°',
                  style: const TextStyle(color: Color(0xFFE4D6A9), fontWeight: FontWeight.w600))),
                const Icon(Icons.wifi_off_rounded, size: 16, color: Colors.white70),
                const SizedBox(width: 4),
                const Text('Çevrimdışı hesap',
                    style: TextStyle(color: Colors.white70, fontSize: 11)),
              ]),
              const SizedBox(height: 22),
              const Text('SIRADAKİ VAKİT', style: TextStyle(
                fontSize: 11, letterSpacing: 1.8, color: Colors.white70, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(sonraki?.$1 ?? '—', style: const TextStyle(
                color: Colors.white, fontSize: 35, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(sonraki == null ? '--:--' : _saat(sonraki.$2),
                  style: const TextStyle(fontSize: 33, color: Color(0xFFF1E6C4),
                    fontWeight: FontWeight.w700)),
                const SizedBox(width: 12),
                Expanded(child: Padding(padding: const EdgeInsets.only(bottom: 6),
                  child: Text(kalan == null ? '' : '${_kalanYazi(kalan)} kaldı',
                    style: const TextStyle(color: Colors.white, fontSize: 13),
                    textAlign: TextAlign.end))),
              ]),
            ],
          )),
        ]),
      ),
      const SizedBox(height: 24),
      Row(children: [
        Expanded(child: Text('Bugünün vakitleri', style: Theme.of(context).textTheme.titleLarge)),
        IconButton(tooltip: 'Vakitleri yenile', icon: const Icon(Icons.refresh_rounded),
            onPressed: _konumAl),
      ]),
      const SizedBox(height: 4),
      for (var i = 0; i < _vakitler.length; i++) ...[
        Builder(builder: (context) {
          final e = _vakitler.entries.elementAt(i);
          final aktif = sonraki?.$1 == e.key && sonraki!.$2.day == simdi.day;
          final gecmis = e.value.isBefore(simdi);
          return Padding(padding: const EdgeInsets.only(bottom: 9), child: Card(
            color: aktif ? renk.primaryContainer : null,
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: aktif ? renk.primary : renk.surfaceContainerHighest,
                child: Icon(_vakitIkonu(e.key),
                  color: aktif ? renk.onPrimary : renk.onSurfaceVariant),
              ),
              title: Text(e.key, style: TextStyle(fontWeight: aktif ? FontWeight.w800 : FontWeight.w600)),
              subtitle: Text(aktif ? 'Sıradaki vakit' : (gecmis ? 'Geçti' : 'Bekleniyor'),
                  style: TextStyle(fontSize: 12, color: renk.onSurfaceVariant)),
              trailing: Text(_saat(e.value), style: TextStyle(
                fontSize: 20, fontWeight: FontWeight.w800,
                color: aktif ? renk.primary : renk.onSurface)),
            ),
          ));
        }),
      ],
      const SizedBox(height: 8),
      Card(child: ListTile(
        leading: const Icon(Icons.tune_rounded, color: kYesil),
        title: const Text('Vakit ayarları', style: TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(duzeltilen
            ? 'Dakika düzeltmeleri etkin · düzenlemek için dokun'
            : 'İhtiyaç halinde vakitleri dakika bazında ayarla'),
        trailing: const Icon(Icons.chevron_right_rounded),
        onTap: _dakikaDuzelt,
      )),
      const SizedBox(height: 16),
      Text('Hatırlatmalar', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 10),
      Card(child: Column(children: [
        SwitchListTile.adaptive(
          secondary: const Icon(Icons.notifications_active_outlined, color: kYesil),
          title: const Text('Namaz vakti bildirimi'),
          subtitle: const Text('Her vakit için hatırlatma'),
          value: _namazBildirim,
          onChanged: _namazBildirimDegistir,
        ),
        const Divider(height: 1),
        SwitchListTile.adaptive(
          secondary: const Icon(Icons.menu_book_outlined, color: kYesil),
          title: const Text('Günlük okuma hatırlatması'),
          subtitle: Text('Her gün ${_hatirlatmaSaati.format(context)}'),
          value: _hatirlatmaAcik,
          onChanged: _hatirlatmaDegistir,
        ),
        if (_hatirlatmaAcik) ...[
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.schedule_rounded, color: kYesil),
            title: const Text('Hatırlatma saati'),
            trailing: Text(_hatirlatmaSaati.format(context)),
            onTap: _saatSec,
          ),
        ],
      ])),
      const SizedBox(height: 16),
      Card(child: ListTile(
        leading: const Icon(Icons.widgets_outlined, color: kYesil),
        title: const Text('Ana ekran widget’ları'),
        subtitle: const Text('Kompakt, orta ve geniş seçenekler. Telefonun ana ekranında '
            'boş bir yere uzun basarak widget ekleyebilirsiniz.'),
        isThreeLine: true,
      )),
      const SizedBox(height: 14),
      Text('Vakitler konumunuza göre astronomik olarak hesaplanır; '
        'resmî Diyanet takviminden farklı olabilir. Güncel resmî vakitlerle '
        'karşılaştırmanız önerilir.',
        textAlign: TextAlign.center,
        style: TextStyle(color: renk.onSurfaceVariant, fontSize: 12, height: 1.5)),
    ]);
  }
}
