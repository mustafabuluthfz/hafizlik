import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Mushaf sayfasını düz bir ekran dönüşü yerine kavisli kâğıt yaprağı gibi çevirir.
/// Alt sayfa çevirme boyunca görünür; üst sayfanın kıvrımlı kenarı gölge düşürür.
/// Sure/ayet seçicilerinden yapılan uzak atlamalarda gereksiz 604 sayfa animasyonu yoktur.
class KitapSayfaCevirici extends StatefulWidget {
  final int sayfa;
  final int toplam;
  final Widget Function(int sayfa) sayfaOlustur;
  final ValueChanged<int> onSayfaIste;

  const KitapSayfaCevirici({
    super.key,
    required this.sayfa,
    required this.toplam,
    required this.sayfaOlustur,
    required this.onSayfaIste,
  });

  @override
  State<KitapSayfaCevirici> createState() => _KitapSayfaCeviriciState();
}

class _KitapSayfaCeviriciState extends State<KitapSayfaCevirici>
    with SingleTickerProviderStateMixin {
  late final AnimationController _cevirme;
  int? _eski;
  int _yon = 1;
  final Set<int> _dokunanlar = <int>{};
  Offset? _baslangic;
  Offset? _son;

  @override
  void initState() {
    super.initState();
    _cevirme = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 760),
    );
    _cevirme.addStatusListener((durum) {
      if (durum == AnimationStatus.completed && mounted) {
        setState(() => _eski = null);
      }
    });
  }

  @override
  void didUpdateWidget(covariant KitapSayfaCevirici eskiWidget) {
    super.didUpdateWidget(eskiWidget);
    if (widget.sayfa == eskiWidget.sayfa) return;
    final fark = widget.sayfa - eskiWidget.sayfa;
    if (fark.abs() != 1) {
      // Cüz, sûre veya ayet seçiminde uzak sayfaya doğrudan geçilir.
      _cevirme.stop();
      _cevirme.value = 0;
      _eski = null;
      return;
    }
    _eski = eskiWidget.sayfa;
    _yon = fark.sign;
    _cevirme.forward(from: 0);
  }

  @override
  void dispose() {
    _cevirme.dispose();
    super.dispose();
  }

  void _bitir(PointerUpEvent e) {
    _dokunanlar.remove(e.pointer);
    if (_dokunanlar.isNotEmpty || _baslangic == null || _son == null ||
        _cevirme.isAnimating) return;
    final fark = _son! - _baslangic!;
    _baslangic = null;
    _son = null;
    if (fark.dx.abs() < 65 || fark.dx.abs() < fark.dy.abs() * 1.35) return;
    // Mushaf sağdan sola okunur: sağa kaydırma sonraki yaprağı açar.
    final yeni = widget.sayfa + (fark.dx > 0 ? 1 : -1);
    if (yeni >= 1 && yeni <= widget.toplam) widget.onSayfaIste(yeni);
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: (e) {
        _dokunanlar.add(e.pointer);
        if (_dokunanlar.length == 1) {
          _baslangic = e.localPosition;
          _son = e.localPosition;
        } else {
          _baslangic = null;
          _son = null;
        }
      },
      onPointerMove: (e) {
        if (_dokunanlar.length == 1) _son = e.localPosition;
      },
      onPointerUp: _bitir,
      onPointerCancel: (e) {
        _dokunanlar.remove(e.pointer);
        _baslangic = null;
        _son = null;
      },
      child: ClipRect(
        child: AnimatedBuilder(
          animation: _cevirme,
          builder: (context, _) {
            if (_eski == null || !_cevirme.isAnimating) {
              return widget.sayfaOlustur(widget.sayfa);
            }
            final ilerleme = Curves.easeInOutCubic.transform(_cevirme.value);
            final soldan = _yon > 0;
            return LayoutBuilder(builder: (context, kisitlar) {
              final boyut = Size(kisitlar.maxWidth, kisitlar.maxHeight);
              return Stack(fit: StackFit.expand, children: [
                // Yeni sayfa, kıvrılan eski yaprağın altında sabittir.
                widget.sayfaOlustur(widget.sayfa),
                IgnorePointer(
                  child: ClipPath(
                    clipper: _KalanSayfaKirpici(ilerleme, soldan),
                    child: widget.sayfaOlustur(_eski!),
                  ),
                ),
                IgnorePointer(
                  child: CustomPaint(
                    size: boyut,
                    painter: _KivrimBoyacisi(ilerleme, soldan),
                  ),
                ),
              ]);
            });
          },
        ),
      ),
    );
  }
}

/// Yaprağın serbest kenarı yukarıda ve aşağıda farklı hızlarla ilerler;
/// bu da dümdüz kesilme yerine, kâğıdın kavisli kıvrılmasını sağlar.
class _YaprakGeometrisi {
  final double ust;
  final double alt;
  final double bukum;
  final double genislik;
  final double yukseklik;

  _YaprakGeometrisi(Size boyut, double ilerleme, bool soldan)
      : genislik = boyut.width,
        yukseklik = boyut.height,
        bukum = math.sin(math.pi * ilerleme) * boyut.width * .115,
        ust = _kenar(boyut.width, ilerleme, soldan, false),
        alt = _kenar(boyut.width, ilerleme, soldan, true);

  static double _kenar(double w, double t, bool soldan, bool alt) {
    final merkez = (-.06 + t * 1.12) * w;
    final sapma = math.sin(math.pi * t) * w * (alt ? .105 : -.085);
    final x = merkez + sapma;
    return soldan ? x : w - x;
  }

  Path kenarYolu() => Path()
    ..moveTo(ust, 0)
    ..cubicTo(ust + bukum * .16, yukseklik * .30,
      alt - bukum * .24, yukseklik * .72, alt, yukseklik);
}

class _KalanSayfaKirpici extends CustomClipper<Path> {
  final double ilerleme;
  final bool soldan;
  const _KalanSayfaKirpici(this.ilerleme, this.soldan);

  @override
  Path getClip(Size boyut) {
    final g = _YaprakGeometrisi(boyut, ilerleme, soldan);
    final p = Path()..moveTo(g.ust, 0);
    if (soldan) {
      p.lineTo(boyut.width, 0);
      p.lineTo(boyut.width, boyut.height);
    } else {
      p.lineTo(0, 0);
      p.lineTo(0, boyut.height);
    }
    p.lineTo(g.alt, boyut.height);
    p.cubicTo(g.alt - g.bukum * .24, g.yukseklik * .72,
      g.ust + g.bukum * .16, g.yukseklik * .30, g.ust, 0);
    return p..close();
  }

  @override
  bool shouldReclip(_KalanSayfaKirpici old) =>
      ilerleme != old.ilerleme || soldan != old.soldan;
}

/// Kıvrılan kâğıdın arka yüzü, çok katmanlı gölge ve parlak bir kâğıt çizgisi.
/// Resim değil; animasyonun her karesinde sayfaya göre çizilir.
class _KivrimBoyacisi extends CustomPainter {
  final double ilerleme;
  final bool soldan;
  const _KivrimBoyacisi(this.ilerleme, this.soldan);

  @override
  void paint(Canvas canvas, Size boyut) {
    if (ilerleme <= 0 || ilerleme >= 1) return;
    final g = _YaprakGeometrisi(boyut, ilerleme, soldan);
    final isaret = soldan ? -1.0 : 1.0;
    final genislik = (10 + 46 * math.sin(math.pi * ilerleme));
    final kirim = Path()
      ..moveTo(g.ust, 0)
      ..cubicTo(g.ust + g.bukum * .16, boyut.height * .30,
        g.alt - g.bukum * .24, boyut.height * .72, g.alt, boyut.height)
      ..lineTo(g.alt + isaret * genislik, boyut.height)
      ..cubicTo(g.alt + isaret * genislik - g.bukum * .24, boyut.height * .72,
        g.ust + isaret * genislik + g.bukum * .16, boyut.height * .30,
        g.ust + isaret * genislik, 0)
      ..close();

    canvas.drawShadow(kirim, const Color(0xFF47341C), 12, false);
    final minX = math.min(g.ust, g.alt) - genislik - 4;
    final maxX = math.max(g.ust, g.alt) + genislik + 4;
    final rect = Rect.fromLTRB(minX, 0, maxX, boyut.height);
    canvas.drawPath(kirim, Paint()..shader = LinearGradient(
      begin: soldan ? Alignment.centerRight : Alignment.centerLeft,
      end: soldan ? Alignment.centerLeft : Alignment.centerRight,
      colors: const [Color(0xFFBBAA8B), Color(0xFFFFF9EA), Color(0xFFE1D3B7)],
      stops: const [0, .48, 1],
    ).createShader(rect));
    canvas.drawPath(g.kenarYolu(), Paint()
      ..color = const Color(0xFFB8A17A)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3);
  }

  @override
  bool shouldRepaint(_KivrimBoyacisi old) =>
      ilerleme != old.ilerleme || soldan != old.soldan;
}
