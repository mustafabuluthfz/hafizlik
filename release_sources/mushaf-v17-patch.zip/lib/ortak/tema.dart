import 'package:flutter/material.dart';

/// Tasarım sistemi: renkler, boşluklar, köşe yuvarlaklıkları ve yazı stilleri.
/// Tüm ekranlar bu değerleri kullanır; tek yerden değiştirilebilir.

// Marka renkleri
const Color kYesil = Color(0xFF0E6B5C);
const Color kYesilAcik = Color(0xFF14A588);
const Color kAltin = Color(0xFFD1A757);
const Color kAltinAcik = Color(0xFFF6E5B7);
const Color kZemin = Color(0xFFF2EBDD);
const Color kMetin = Color(0xFF14201D);
const Color kIkincilMetin = Color(0xFF5D6C68);
const Color kKoyuZemin = Color(0xFF081412);
const Color kKoyuKart = Color(0xFF172B27);

// Boşluklar (8'in katları)
const double kBosluk4 = 4;
const double kBosluk8 = 8;
const double kBosluk12 = 12;
const double kBosluk16 = 16;
const double kBosluk20 = 20;
const double kBosluk24 = 24;
const double kBosluk32 = 32;

// Köşe yuvarlaklıkları
const double kYaricap12 = 12;
const double kYaricap16 = 16;
const double kYaricap20 = 20;

/// Kullanıcının seçtiği görünüm (açık, koyu, sistem). Uygulama açılışında yüklenir.
final ValueNotifier<ThemeMode> kTemaModu = ValueNotifier<ThemeMode>(ThemeMode.system);

/// Mushaf kâğıdı rengi ve Arapça yazı boyutu kullanıcı tercihleri.
final ValueNotifier<Color> kMushafKagitRengi = ValueNotifier<Color>(const Color(0xFFFBF6E9));
final ValueNotifier<double> kMushafYaziBoyutu = ValueNotifier<double>(26);

const List<Color> kKagitPaleti = [
  Color(0xFFFBF6E9), Color(0xFFF3E8D0), Color(0xFFF5F0DC), Color(0xFFE8F0E5),
  Color(0xFFE7EEF5), Color(0xFFF0E6E8), Color(0xFFFFFFFF), Color(0xFF202820),
];
const List<String> kKagitAdlari = ['Klasik', 'Sepya', 'Krem', 'Açık yeşil', 'Açık mavi', 'Gül', 'Beyaz', 'Koyu'];

ThemeData kTemaAcik() => _tema(Brightness.light);
ThemeData kTemaKoyu() => _tema(Brightness.dark);

ThemeData _tema(Brightness parlaklik) {
  final koyu = parlaklik == Brightness.dark;
  final zemin = koyu ? kKoyuZemin : kZemin;
  final kart = koyu ? kKoyuKart : const Color(0xFFFCF7ED);
  final semalar = ColorScheme.fromSeed(
    seedColor: kYesil,
    brightness: parlaklik,
    primary: koyu ? const Color(0xFF93E7D1) : kYesil,
    onPrimary: koyu ? kKoyuZemin : Colors.white,
    secondary: kAltin,
    tertiary: const Color(0xFF526F9D),
    primaryContainer: koyu ? const Color(0xFF174A41) : const Color(0xFFD8F0E6),
    secondaryContainer: koyu ? const Color(0xFF55452B) : const Color(0xFFF6E9CC),
    surface: kart,
  );

  final yazi = ThemeData(brightness: parlaklik).textTheme.apply(
        bodyColor: koyu ? const Color(0xFFE6EAE4) : kMetin,
        displayColor: koyu ? const Color(0xFFE6EAE4) : kMetin,
      );

  return ThemeData(
    useMaterial3: true,
    brightness: parlaklik,
    colorScheme: semalar,
    scaffoldBackgroundColor: zemin,
    textTheme: yazi.copyWith(
      headlineSmall: yazi.headlineSmall?.copyWith(fontWeight: FontWeight.w800, letterSpacing: -0.5),
      titleLarge: yazi.titleLarge?.copyWith(fontWeight: FontWeight.w800, letterSpacing: -0.2),
      titleMedium: yazi.titleMedium?.copyWith(fontWeight: FontWeight.w700),
      bodyMedium: yazi.bodyMedium?.copyWith(height: 1.45),
      labelLarge: yazi.labelLarge?.copyWith(fontWeight: FontWeight.w700, letterSpacing: 0.2),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: koyu ? kKoyuZemin : kZemin,
      foregroundColor: koyu ? const Color(0xFFE6EAE4) : kMetin,
      centerTitle: false,
      elevation: 0,
      scrolledUnderElevation: 0,
      titleTextStyle: TextStyle(
        fontSize: 19, fontWeight: FontWeight.w800, letterSpacing: -0.3,
        color: koyu ? const Color(0xFFE6EAE4) : kMetin,
      ),
    ),
    iconTheme: IconThemeData(size: 17, color: koyu ? const Color(0xFFA9DFC8) : kYesil),
    iconButtonTheme: IconButtonThemeData(style: IconButton.styleFrom(
      iconSize: 17, minimumSize: const Size(38, 38),
      foregroundColor: semalar.primary,
      backgroundColor: Colors.transparent,
      shape: const CircleBorder())),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: kart,
      indicatorColor: koyu ? kYesilAcik.withOpacity(.28) : const Color(0xFFE5E5D0),
      elevation: 0,
      height: 61,
      labelTextStyle: WidgetStateProperty.all(const TextStyle(fontWeight: FontWeight.w700)),
    ),
    cardTheme: CardThemeData(
      color: kart,
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(19),
        side: BorderSide(
          color: koyu ? const Color(0xFF37594C) : const Color(0xFFDDEAE5),
        ),
      ),
    ),
    listTileTheme: const ListTileThemeData(
      iconColor: kYesil,
      dense: true,
      minLeadingWidth: 30,
      minVerticalPadding: 7,
      contentPadding: EdgeInsets.symmetric(horizontal: kBosluk16, vertical: kBosluk4),
    ),
    dividerTheme: DividerThemeData(
      color: koyu ? Colors.white12 : const Color(0xFFE2D6BF),
      space: 1,
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size(0, 48),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(kYaricap12)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        minimumSize: const Size(0, 48),
        side: const BorderSide(color: kAltin),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(kYaricap12)),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: kart,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: BorderSide(color: kAltin.withOpacity(0.18)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: BorderSide(color: kAltin.withOpacity(0.18)),
      ),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: koyu ? const Color(0xFF1B3832) : const Color(0xFFE9E9D7),
      selectedColor: semalar.primaryContainer,
      side: BorderSide(color: kAltin.withOpacity(0.3)),
      labelStyle: TextStyle(color: semalar.onSurface, fontWeight: FontWeight.w600),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(kYaricap20)),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(kYaricap12)),
    ),
  );
}
