import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hafizlik_app/kuran/kitap_sayfa_cevirici.dart';

void main() {
  testWidgets('Kitap yaprağı sağa kaydırılınca sonraki sayfa istenir', (tester) async {
    int? secilen;
    await tester.pumpWidget(MaterialApp(home: Scaffold(body:
      KitapSayfaCevirici(sayfa: 1, toplam: 604,
        sayfaOlustur: (n) => Center(child: Text('Mushaf sayfası $n')),
        onSayfaIste: (n) => secilen = n,
      ),
    )));
    await tester.drag(find.text('Mushaf sayfası 1'), const Offset(160, 0));
    await tester.pumpAndSettle();
    expect(secilen, 2);
  });
}
