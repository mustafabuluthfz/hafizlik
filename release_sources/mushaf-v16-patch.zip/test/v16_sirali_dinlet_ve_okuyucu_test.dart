import 'package:flutter_test/flutter_test.dart';
import 'package:hafizlik_app/ders/karsilastirma.dart';
import 'package:hafizlik_app/ses/okuyucu.dart';

void main() {
  test('Başta okunan tekrar, sayfanın sonuna atlamaz', () {
    final sayfa = ['بسم', 'الله', 'الرحمن', 'الحمد', 'بسم', 'الله'];
    final sonuc = karsilastir(sayfa, 'بسم الله', tamamlandi: true);
    expect(sonuc[0].durum, KelimeDurumuTipi.dogru);
    expect(sonuc[1].durum, KelimeDurumuTipi.dogru);
    for (var k = 2; k < sayfa.length; k++) {
      expect(sonuc[k].durum, KelimeDurumuTipi.bekliyor);
    }
  });

  test('Sayfa sonundaki aynı kelimeye yanlışlıkla doğru işareti konmaz', () {
    final sonuc = karsilastir(['الحمد', 'لله', 'رب', 'الحمد'], 'الحمد');
    expect(sonuc[0].durum, KelimeDurumuTipi.dogru);
    expect(sonuc[3].durum, KelimeDurumuTipi.bekliyor);
  });

  test('Bir kelime atlandığında sonraki doğru kelimeye ilerler', () {
    final sonuc = karsilastir(['بسم', 'الله', 'الرحمن'], 'بسم الرحمن');
    expect(sonuc.map((e) => e.durum), [
      KelimeDurumuTipi.dogru,
      KelimeDurumuTipi.atlandi,
      KelimeDurumuTipi.dogru,
    ]);
  });

  test('Fazla kelimeler sayılır ve sayfa sonunda uydurma işaret oluşturmaz', () {
    final sayfa = ['بسم', 'الله', 'الرحمن', 'بسم'];
    final sonuc = karsilastir(sayfa, 'بسم الحمد الله');
    expect(sonuc.first.durum, KelimeDurumuTipi.dogru);
    expect(sonuc.last.durum, KelimeDurumuTipi.bekliyor);
    expect(fazlaKelimeSayisi(sayfa, 'بسم الحمد الله'), 1);
  });

  test('Kelimedeki hareke ve şedde işaretleri ayrıca açıklanır', () {
    final isaretler = harekeIsaretleri('رَبَّ');
    expect(isaretler, contains('Üstün'));
    expect(isaretler, contains('Şedde'));
    expect(tecvidNotu('رَبَّ'), contains('otomatik ölçülemez'));
  });

  test('Türk okuyucuların ses katalog kaydı bulunmaz', () {
    expect(okuyucular.length, 36);
    expect(okuyucular.any((o) => o.klasor.startsWith('TR_')), isFalse);
  });
}
