import 'package:flutter_test/flutter_test.dart';
import 'package:hafizlik_app/ses/okuyucu.dart';
import 'package:hafizlik_app/ortak/tema.dart';

void main() {
  test('Önceki okuyucu tercihleri korunur', () {
    expect(okuyucular.first.klasor, 'Alafasy_128kbps');
    expect(okuyucular[1].klasor, 'Husary_128kbps');
  });
  test('Türk hoca listesi uygulamadan kaldırıldı', () {
    expect(okuyucular.length, 36);
    expect(okuyucular.any((o) => o.klasor.startsWith('TR_')), isFalse);
    expect(okuyucular.every((o) => o.indirmeIzniVar), isTrue);
  });
  test('Tasarım marka renkleri tanımlı', () {
    expect(kYesil.value, isNot(0));
    expect(kAltin.value, isNot(0));
  });
}
