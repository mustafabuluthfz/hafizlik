# Mushaf Yoldaşım 2.7.0 (V16)

- Ders Dinlet kelimeleri yalnızca Mushaf sayfasının başından ilerleyen öneğe hizalanır. Sayfa sonunda tekrarlanan kelime ilk okunuşla eşleştirilmez, okunmamış son bölüm beklemede kalır.
- Hareke/şedde işaretleri her kelimenin ayrıntısında açıklanır; o kelimeye öğretmen/kullanıcı tarafından ayrı hata notu eklenebilir. ASR modeli hareke, mahreç ve tecvidi otomatik tespit edemez.
- Kur’an sayfalarında düz yatay kaydırma yerine 3B perspektifli fiziksel sayfa dönüşümü bulunur. Parmağı sağa sürüklemek (Mushaf yönünde) sonraki sayfayı, sola sürüklemek önceki sayfayı getirir. Ses kapatma seçeneği korunmuştur.
- Türk hafız okuyucu seçenekleri ve özel MP3 ekleme akışı tamamen kaldırılmıştır; eski okuyucu tercihi artık kataloğun uygun indeksine sınırlandırılır. Türkçe sesli meal özelliği ayrı hizmet olarak korunmuştur.
- Ana ekran katalog kartları, hızlı işlem simgeleri ve gezinti çubuğu daha küçük, zengin tonlu ve yuvarlak köşeli yapılmıştır.
- Uygulama adı Mushaf Yoldaşım, paket adı com.hafizlik.app.hafizlik_app korunmuştur.
- Sürüm: 2.7.0+20.
