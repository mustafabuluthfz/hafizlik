import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../ai/ai_hoca_ekrani.dart';

import '../hafizlik/bugunku_sayfa.dart';
import '../hafizlik/hafizlik_sira.dart';
import '../hafizlik/quran_veri.dart';
import '../ortak/mushaf.dart';
import 'karsilastirma.dart';
import 'yerel_kuran_tanima.dart';

/// Ders dinletme: Mikrofon sesini uygulamaya gömülü Kur'an ASR modeliyle
/// çevrimdışı tanır ve Mushaf kelimeleriyle karşılaştırır.
/// Harf sonuçları öğretim amaçlıdır, mahreç/tecvid değerlendirmesi değildir.
class DersEkrani extends StatefulWidget {
  const DersEkrani({super.key});

  @override
  State<DersEkrani> createState() => _DersEkraniState();
}

class _RenkAciklama extends StatelessWidget {
  final Color renk;
  final String yazi;
  const _RenkAciklama({required this.renk, required this.yazi});

  @override
  Widget build(BuildContext context) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Container(width: 9, height: 9, decoration: BoxDecoration(
        color: renk, shape: BoxShape.circle)),
      const SizedBox(width: 4),
      Text(yazi, style: const TextStyle(fontSize: 11)),
    ],
  );
}

class _DersEkraniState extends State<DersEkrani> {
  late final YerelKuranTanima _tanima = YerelKuranTanima(
    onText: _sonucGeldi,
    onError: _tanimaHatasi,
  );
  bool _yukleniyor = true;
  bool _sesHazir = false;
  bool _analizSuruyor = false;
  String? _hata;
  int? _sayfa;
  List<String> _kelimeler = [];
  bool _dinliyor = false;
  String _kesin = ''; // tanınıp kesinleşmiş metin
  String _anlik = ''; // henüz kesinleşmemiş (anlık) metin
  List<KelimeDurumu>? _sonuc;
  int _harekeHatalari = 0;
  int _tecvidHatalari = 0;
  final Set<int> _harekeNotlu = <int>{};

  /// Yazılı hareke işaretleri görüntülenir; otomatik telaffuz analizi değildir.
  void _kelimeAciklamaGoster(KelimeDurumu d, int kelimeIndeksi) {
    final isaretler = harekeIsaretleri(d.metin);
    final notlu = _harekeNotlu.contains(kelimeIndeksi);
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(child: Text(d.metin, textDirection: TextDirection.rtl,
                style: const TextStyle(fontFamily: kMushafFontu, fontSize: 37))),
              const SizedBox(height: 12),
              Text(kelimeAciklamasi(d), style: const TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 14),
              const Text('Mushaf’taki hareke işaretleri',
                style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 7),
              if (isaretler.isEmpty)
                const Text('Bu kelimede temel hareke işareti görünmüyor.')
              else
                Wrap(spacing: 7, runSpacing: 5,
                  children: [for (final ad in isaretler)
                    Chip(label: Text(ad, style: const TextStyle(fontSize: 12)))]),
              const SizedBox(height: 10),
              Text(tecvidNotu(d.metin),
                style: TextStyle(fontSize: 12, color: Theme.of(ctx).colorScheme.onSurfaceVariant)),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, child: FilledButton.tonalIcon(
                onPressed: () {
                  setState(() {
                    if (_harekeNotlu.contains(kelimeIndeksi)) {
                      _harekeNotlu.remove(kelimeIndeksi);
                      _harekeHatalari--;
                    } else {
                      _harekeNotlu.add(kelimeIndeksi);
                      _harekeHatalari++;
                    }
                  });
                  Navigator.pop(ctx);
                },
                icon: Icon(notlu ? Icons.check_circle_outline_rounded : Icons.edit_note_rounded,
                  size: 18),
                label: Text(notlu ? 'Bu kelimedeki hata notunu kaldır' :
                  'Bu kelimeye hareke hatası notu ekle'),
              )),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _baslat();
  }

  @override
  void dispose() {
    _tanima.kapat();
    super.dispose();
  }

  Future<void> _baslat() async {
    try {
      final sayfa = await bugunkuSayfaNo();
      final ayetler = await QuranVeri.sayfa(sayfa);
      _kelimeler = [
        for (final a in ayetler) ...a.metin.trim().split(RegExp(r'\s+')),
      ];
      _sayfa = sayfa;
    } catch (_) {
      _hata = 'Ders sayfası yüklenemedi.';
    }

    if (_sayfa != null) {
      try {
        await _tanima.hazirla();
        _sesHazir = true;
      } catch (e) {
        _hata = 'Yerel Kur’an ses modeli açılamadı: $e. '
            'Telefonun Android sürümünü ve kullanılabilir belleğini kontrol edin.';
      }
    }
    if (!mounted) return;
    setState(() => _yukleniyor = false);
  }

  void _tanimaHatasi(String mesaj) {
    if (!mounted) return;
    setState(() => _hata = mesaj);
  }

  Future<void> _dinlemeyiBaslat() async {
    if (!_sesHazir || _dinliyor || _analizSuruyor) return;
    setState(() {
      _hata = null;
      _dinliyor = true;
      _kesin = '';
      _anlik = '';
      _sonuc = null;
      _harekeHatalari = 0;
      _harekeNotlu.clear();
      _tecvidHatalari = 0;
    });
    try {
      await _tanima.baslat();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _dinliyor = false;
        _hata = 'Dinleme başlatılamadı: $e';
      });
    }
  }

  // Yerel ASR birbirinden bağımsız ses parçaları döndürür. Kuran'da aynı
  // kelime/ayet birden fazla kez okunabileceği için bunları "mükerrer" sanıp
  // silmek doğru olmaz. Her bağımsız ses parçasını sırasıyla ekliyoruz.
  String _birlesikMetin(String onceki, String yeni) =>
      [onceki.trim(), yeni.trim()].where((text) => text.isNotEmpty).join(' ');

  void _sonucGeldi(String metin) {
    if (!mounted || metin.trim().isEmpty) return;
    setState(() {
      _kesin = _birlesikMetin(_kesin, metin);
      _sonuc = karsilastir(_kelimeler, _kesin);
    });
  }

  Future<void> _dinlemeyiDurdur() async {
    if (!_dinliyor || _analizSuruyor) return;
    setState(() {
      _dinliyor = false;
      _analizSuruyor = true;
    });
    try {
      // Bekleyen ses parçaları tamamlanana kadar sonuçları açık tut.
      await _tanima.durdur();
    } catch (e) {
      if (mounted) setState(() => _hata = 'Dinleme durdurulamadı: $e');
    }
    if (!mounted) return;
    setState(() {
      _analizSuruyor = false;
      _anlik = '';
      _sonuc = karsilastir(_kelimeler, _kesin, tamamlandi: true);
    });
  }

  void _sifirla() {
    _tanima.sifirla();
    setState(() {
      _kesin = '';
      _anlik = '';
      _sonuc = null;
      _harekeHatalari = 0;
      _harekeNotlu.clear();
      _tecvidHatalari = 0;
      _hata = null;
    });
  }


  Future<void> _hataEkle(String tur) async {
    final aciklama = tur == 'hareke'
        ? 'Okuyuşta fark ettiğiniz hareke hatasını bu oturuma not etmek ister misiniz? Model bunu otomatik ölçmez.'
        : 'Kendinizin veya öğretmeninizin fark ettiği tecvid hatasını bu oturuma not etmek ister misiniz?';
    final onay = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tur == 'hareke' ? 'Hareke hatası' : 'Tecvid hatası'),
        content: Text(aciklama),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hata olarak say')),
        ],
      ),
    );
    if (onay != true || !mounted) return;
    setState(() {
      if (tur == 'hareke') { _harekeHatalari++; } else { _tecvidHatalari++; }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_sayfa == null ? 'Ders Dinlet' : 'Ders · Sayfa $_sayfa'),
      ),
      body: _govde(),
    );
  }

  Widget _govde() {
    if (_yukleniyor) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_sayfa == null) {
      return Center(child: Text(_hata ?? 'Bir hata oluştu.'));
    }

    final durumlar = _sonuc ??
        [for (final k in _kelimeler) KelimeDurumu(k, KelimeDurumuTipi.bekliyor)];
    final dogruSayisi = durumlar.where((d) => d.durum == KelimeDurumuTipi.dogru).length;
    final yanlisSayisi = durumlar.where((d) => d.durum == KelimeDurumuTipi.yanlis).length;
    final atlananSayisi = durumlar.where((d) => d.durum == KelimeDurumuTipi.atlandi).length;
    final fazlaSayisi = _sonuc == null ? 0 : fazlaKelimeSayisi(_kelimeler, '$_kesin $_anlik');

    return Column(
      children: [
        Card(
          margin: const EdgeInsets.all(12),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Cüz ${HafizlikSira.cuzOf(_sayfa!)}',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                Flexible(
                  child: Text(_sonuc == null && !_dinliyor
                      ? 'Kur’an modeli hazır · Başlamak için mikrofon düğmesine dokunun'
                      : 'Doğru: $dogruSayisi  ·  Kelime hatası: ${yanlisSayisi + atlananSayisi + fazlaSayisi}  ·  Hareke: $_harekeHatalari  ·  Tecvid: $_tecvidHatalari',
                    textAlign: TextAlign.end,
                  ),
                ),
              ],
            ),
          ),
        ),
        if (_sonuc != null && _kelimeler.isNotEmpty)
          Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              LinearProgressIndicator(value: dogruSayisi / _kelimeler.length,
                minHeight: 6, borderRadius: BorderRadius.circular(10)),
              const SizedBox(height: 5),
              Text('Algılanan ve eşleşen kelime: $dogruSayisi / ${_kelimeler.length} · '
                  'Hareke notu için bir kelimeye dokunun; otomatik hareke tespiti yapılmaz.',
                style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.onSurfaceVariant)),
            ])),
        if (_hata != null)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Text(_hata!, style: const TextStyle(color: Colors.red)),
          ),
        if (_dinliyor)
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            child: Text('Ezberden okuyun. Sayfa gizlidir; bitirdiğinizde sonuçlar açılacak.',
                style: TextStyle(color: Colors.black87)),
          ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 6),
          child: Wrap(spacing: 12, runSpacing: 4, children: const [
            _RenkAciklama(renk: Colors.green, yazi: 'Doğru'),
            _RenkAciklama(renk: Colors.red, yazi: 'Farklı algılandı'),
            _RenkAciklama(renk: Colors.orange, yazi: 'Atlandı'),
            _RenkAciklama(renk: Colors.black54, yazi: 'Henüz okunmadı'),
          ]),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(12, 0, 12, 4),
          child: Text(
            'Kelime kontrolü sayfanın başından sırasıyla ilerler. Sondaki tekrarlar baştaki okumayla eşleştirilmez. Hareke ve tecvid otomatik değerlendirilmez.',
            style: TextStyle(fontSize: 11, color: Colors.black54),
          ),
        ),
        Expanded(
          child: _dinliyor
              ? Center(
                  child: Card(
                    margin: const EdgeInsets.all(24),
                    child: Padding(
                      padding: const EdgeInsets.all(28),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Icon(Icons.visibility_off, size: 58),
                          SizedBox(height: 14),
                          Text('EZBER MODU', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                          SizedBox(height: 8),
                          Text('Sayfa gizlendi. Model Arapça okumanızı cihazda çözümlüyor. Sonuçlar bitince gösterilecek.', textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  ),
                )
              : SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 16),
            child: Container(
              decoration: BoxDecoration(
                color: kKagitRengi,
                border: Border.all(color: Colors.brown.shade300, width: 2),
                borderRadius: BorderRadius.circular(8),
              ),
              padding: const EdgeInsets.all(16),
              child: Text.rich(
                TextSpan(
                  children: [
                    for (var kelimeI = 0; kelimeI < durumlar.length; kelimeI++)
                      TextSpan(
                        text: '${durumlar[kelimeI].metin} ',
                        recognizer: TapGestureRecognizer()
                          ..onTap = () => _kelimeAciklamaGoster(durumlar[kelimeI], kelimeI),
                        style: TextStyle(
                          color: switch (durumlar[kelimeI].durum) {
                            KelimeDurumuTipi.dogru => Colors.green.shade800,
                            KelimeDurumuTipi.yanlis => Colors.red.shade700,
                            KelimeDurumuTipi.atlandi => Colors.orange.shade800,
                            KelimeDurumuTipi.bekliyor => Colors.black87,
                          },
                          fontWeight: durumlar[kelimeI].durum == KelimeDurumuTipi.bekliyor
                              ? FontWeight.normal : FontWeight.bold,
                          backgroundColor: _harekeNotlu.contains(kelimeI)
                              ? Colors.amber.withOpacity(.35)
                              : durumlar[kelimeI].durum == KelimeDurumuTipi.dogru
                                  ? Colors.green.withOpacity(0.08) : null,
                          decoration: _harekeNotlu.contains(kelimeI)
                              ? TextDecoration.underline : TextDecoration.none,
                          decorationColor: const Color(0xFFB86E24),
                          decorationThickness: 2.0,
                        ),
                      ),
                  ],
                ),
                textAlign: TextAlign.justify,
                textDirection: TextDirection.rtl,
                style: const TextStyle(
                  fontFamily: kMushafFontu,
                  fontSize: 24,
                  height: 2.1,
                ),
              ),
            ),
          ),
        ),
        if (!_dinliyor && !_analizSuruyor && _sonuc != null && _kesin.trim().isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
            child: SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => AiHocaEkrani(
                      sayfa: _sayfa,
                      beklenenMetin: _kelimeler.join(' '),
                      taninanMetin: _kesin,
                    ),
                  ),
                ),
                icon: const Icon(Icons.auto_awesome),
                label: const Text('Yapay zekâ hafızlık hocasına danış'),
              ),
            ),
          ),
        if (!_dinliyor) Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Elle işaretlenen hata · Hareke: $_harekeHatalari · Tecvid: $_tecvidHatalari',
                textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 6),
              Row(children: [
                Expanded(child: OutlinedButton.icon(
                  onPressed: _sonuc == null ? null : () => _hataEkle('hareke'),
                  icon: const Icon(Icons.spellcheck), label: const Text('Hareke notu +1')),
                ),
                const SizedBox(width: 8),
                Expanded(child: OutlinedButton.icon(
                  onPressed: _sonuc == null ? null : () => _hataEkle('tecvid'),
                  icon: const Icon(Icons.record_voice_over), label: const Text('Tecvid hatası +1')),
                ),
              ]),
              const SizedBox(height: 3),
              const Text('Hareke veya şedde kontrolü için kelimeye dokunun. Bu notlar el ile işaretlenir; ses modeli telaffuz doğruluğunu kanıtlamaz.',
                style: TextStyle(fontSize: 10, color: Colors.black54), textAlign: TextAlign.center),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          child: Row(children: [
            const Icon(Icons.offline_bolt_rounded, size: 18, color: Colors.green),
            const SizedBox(width: 8),
            const Expanded(child: Text(
              'Kur’an ses modeli cihazda çalışır · İnternet ve harici sunucu gerekmez',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
            )),
            if (_analizSuruyor) const SizedBox(
              width: 16, height: 16,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
          ]),
        ),
        if (_analizSuruyor) const Padding(
          padding: EdgeInsets.symmetric(horizontal: 14),
          child: Text('Son ses parçaları cihazda çözümleniyor...',
            style: TextStyle(fontSize: 11)),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: (!_sesHazir || _analizSuruyor)
                        ? null
                        : (_dinliyor ? _dinlemeyiDurdur : _dinlemeyiBaslat),
                    style: FilledButton.styleFrom(
                      minimumSize: const Size.fromHeight(52),
                      backgroundColor: _dinliyor ? Colors.red.shade700 : null,
                    ),
                    icon: Icon(_dinliyor ? Icons.stop : Icons.mic),
                    label: Text(_dinliyor ? 'Dinlemeyi bitir' : 'Okumayı dinle'),
                  ),
                ),
                if (_sonuc != null || _kesin.isNotEmpty || _anlik.isNotEmpty) ...[
                  const SizedBox(width: 12),
                  OutlinedButton(
                    onPressed: (_dinliyor || _analizSuruyor) ? null : _sifirla,
                    child: const Text('Sıfırla'),
                  ),
                ],
              ],
            ),
          ),
        ),
      ],
    );
  }
}
