/// Ders Dinlet: kelime konumunu koruyan, sayfa başına sabitlenmiş hizalama.
/// Bu sınıflandırma sadece modelin ürettiği metni değerlendirir; mahreç,
/// hareke ve tecvidin doğruluğunu saptamaz.
enum KelimeDurumuTipi { bekliyor, dogru, yanlis, atlandi }

class KelimeDurumu {
  final String metin;
  final KelimeDurumuTipi durum;
  const KelimeDurumu(this.metin, this.durum);
  bool get hatali => durum == KelimeDurumuTipi.yanlis || durum == KelimeDurumuTipi.atlandi;
}

final RegExp _harekeRegex = RegExp('[\u064B-\u065F\u0670\u06D6-\u06ED\u0640]');
final RegExp _harfDisindakiler = RegExp('[^\u0621-\u063A\u0641-\u064A' + r'\s' + ']');

String normalize(String s) => s
    .replaceAll('▁', ' ')
    .replaceAll(_harekeRegex, '')
    .replaceAll(RegExp('[أإآٱ]'), 'ا')
    .replaceAll('ؤ', 'و')
    .replaceAll('ئ', 'ي')
    .replaceAll('ى', 'ي')
    .replaceAll('ة', 'ه')
    .replaceAll(_harfDisindakiler, ' ')
    .trim();

class _Hizalama {
  final List<KelimeDurumuTipi> durumlar;
  final int fazla;
  const _Hizalama(this.durumlar, this.fazla);
}

/// Sayfanın SONUNDAN başlamak serbest değildir: tanınan kelimeler daima
/// sayfanın BAŞINDAN itibaren ilerleyen bir ÖNEK ile hizalanır.
///
/// En düşük maliyetli öneki arayan dinamik programlama kullanılır. Sırayı
/// bozan eşleşmeler ve uzak bir tekrarın sırf aynı olduğu için seçilmesi
/// engellenir. Aynı maliyette daha çok TAM eşleşme, sonra daha kısa önek
/// tercih edilir. Okunmayan son kısım asla hata/atlama sayılmaz.
_Hizalama _hizala(List<String> sayfaKelimeleri, String okunan) {
  final yerler = <int>[];
  final beklenen = <String>[];
  for (var k = 0; k < sayfaKelimeleri.length; k++) {
    final w = normalize(sayfaKelimeleri[k]);
    if (w.isNotEmpty) { yerler.add(k); beklenen.add(w); }
  }
  final algilanan = normalize(okunan).split(RegExp(r'\s+')).where((e) => e.isNotEmpty).toList();
  final durum = List<KelimeDurumuTipi>.filled(sayfaKelimeleri.length, KelimeDurumuTipi.bekliyor);
  if (algilanan.isEmpty) return _Hizalama(durum, 0);
  final n = beklenen.length, m = algilanan.length;
  // 0: tam eşleşme, 2: değişim / beklenen kelime atlandı,
  // 3: beklenmeyen fazladan konuşma. Böylece bir harf hatası kırmızı
  // gösterilirken bir sonraki doğru sözcük atlananı açığa çıkarabilir.
  final maliyet = List.generate(n + 1, (_) => List<int>.filled(m + 1, 0));
  final dogru = List.generate(n + 1, (_) => List<int>.filled(m + 1, 0));
  final hareket = List.generate(n + 1, (_) => List<int>.filled(m + 1, 0));
  for (var i = 1; i <= n; i++) { maliyet[i][0] = 2 * i; hareket[i][0] = 2; }
  for (var j = 1; j <= m; j++) { maliyet[0][j] = 3 * j; hareket[0][j] = 3; }
  for (var i = 1; i <= n; i++) {
    for (var j = 1; j <= m; j++) {
      final esit = beklenen[i - 1] == algilanan[j - 1];
      var enIyiMaliyet = maliyet[i - 1][j - 1] + (esit ? 0 : 2);
      var enIyiDogru = dogru[i - 1][j - 1] + (esit ? 1 : 0);
      var enIyiHareket = 1; // eşleşme veya farklı kelime
      final atlamaMaliyet = maliyet[i - 1][j] + 2;
      final atlamaDogru = dogru[i - 1][j];
      if (atlamaMaliyet < enIyiMaliyet ||
          (atlamaMaliyet == enIyiMaliyet && atlamaDogru > enIyiDogru)) {
        enIyiMaliyet = atlamaMaliyet;
        enIyiDogru = atlamaDogru;
        enIyiHareket = 2;
      }
      final fazlaMaliyet = maliyet[i][j - 1] + 3;
      final fazlaDogru = dogru[i][j - 1];
      if (fazlaMaliyet < enIyiMaliyet ||
          (fazlaMaliyet == enIyiMaliyet && fazlaDogru > enIyiDogru)) {
        enIyiMaliyet = fazlaMaliyet;
        enIyiDogru = fazlaDogru;
        enIyiHareket = 3;
      }
      maliyet[i][j] = enIyiMaliyet;
      dogru[i][j] = enIyiDogru;
      hareket[i][j] = enIyiHareket;
    }
  }
  // Tam sayfayı bitirmeye zorlamak yerine en iyi OKUNMUŞ öneki seç.
  // Bu, bir kelime sayfanın sonunda tekrar etse de geriye kalan sözcükleri
  // yeşile/kırmızıya boyamayı önler.
  var son = 0;
  for (var i = 1; i <= n; i++) {
    if (maliyet[i][m] < maliyet[son][m] ||
        (maliyet[i][m] == maliyet[son][m] && dogru[i][m] > dogru[son][m])) {
      son = i;
    }
  }
  var i = son, j = m, fazla = 0;
  while (i > 0 || j > 0) {
    final h = hareket[i][j];
    if (h == 1 && i > 0 && j > 0) {
      durum[yerler[i - 1]] = beklenen[i - 1] == algilanan[j - 1]
          ? KelimeDurumuTipi.dogru : KelimeDurumuTipi.yanlis;
      i--; j--;
    } else if (h == 2 && i > 0) {
      durum[yerler[i - 1]] = KelimeDurumuTipi.atlandi;
      i--;
    } else if (j > 0) {
      fazla++;
      j--;
    } else if (i > 0) { i--; }
  }
  return _Hizalama(durum, fazla);
}

List<KelimeDurumu> karsilastir(List<String> sayfaKelimeleri, String okunan, {bool tamamlandi = false}) {
  final sonuc = _hizala(sayfaKelimeleri, okunan);
  return [for (var k = 0; k < sayfaKelimeleri.length; k++)
    KelimeDurumu(sayfaKelimeleri[k], sonuc.durumlar[k])];
}

int fazlaKelimeSayisi(List<String> sayfaKelimeleri, String okunan) => _hizala(sayfaKelimeleri, okunan).fazla;

String kelimeAciklamasi(KelimeDurumu k) {
  switch (k.durum) {
    case KelimeDurumuTipi.dogru:
      return 'Bu konumdaki harfler modelin metniyle eşleşti; hareke doğruluğu ölçülmedi.';
    case KelimeDurumuTipi.yanlis:
      return 'Bu konumdaki harfler farklı algılandı. Ses tanıma hatalı olabilir.';
    case KelimeDurumuTipi.atlandi:
      return 'Bu kelime atlandı ya da model tarafından algılanamadı.';
    case KelimeDurumuTipi.bekliyor:
      return 'Bu konuma henüz ulaşılmadı. Sondaki benzer kelimelerle eşleştirilmez.';
  }
}

/// Mushaf'ın yazılı hareke işaretlerinin açıklamaları: bunlar okuma analizi
/// DEĞİL, kullanıcının kendisi/öğretmeniyle kontrol etmesi için görsel ipuçları.
List<String> harekeIsaretleri(String kelime) {
  final sonuc = <String>[];
  if (kelime.contains('َ')) sonuc.add('Üstün');
  if (kelime.contains('ِ')) sonuc.add('Esre');
  if (kelime.contains('ُ')) sonuc.add('Ötre');
  if (kelime.contains('ْ')) sonuc.add('Cezim');
  if (kelime.contains('ّ')) sonuc.add('Şedde');
  if (kelime.contains(RegExp('[ًٌٍ]'))) sonuc.add('Tenvin');
  if (kelime.contains('ٰ')) sonuc.add('Hançer elif');
  return sonuc;
}

String tecvidNotu(String metin) => 'Hareke, şedde ve tecvidin sesli doğruluğu bu modelle otomatik ölçülemez. Bu kelimenin yazılı işaretlerini kontrol edip gerektiğinde hata notu bırakın.';
