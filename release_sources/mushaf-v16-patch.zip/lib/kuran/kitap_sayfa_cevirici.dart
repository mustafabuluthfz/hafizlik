import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Gerçek kitap hissi veren perspektifli 3B yaprak dönüşümü.
/// Sayfa içerikleri canlı Flutter widget'larıdır; görüntü dosyası kullanılmaz.
/// İki parmakla Mushaf yakınlaştırma hareketi korunur.
class KitapSayfaCevirici extends StatefulWidget {
  final int sayfa;
  final int toplam;
  final Widget Function(int sayfa) sayfaOlustur;
  final ValueChanged<int> onSayfaIste;
  const KitapSayfaCevirici({
    super.key,
    required this.sayfa,
    required this.toplam,
    required this.sayfaOlustur,
    required this.onSayfaIste,
  });

  @override
  State<KitapSayfaCevirici> createState() => _KitapSayfaCeviriciState();
}

class _KitapSayfaCeviriciState extends State<KitapSayfaCevirici>
    with SingleTickerProviderStateMixin {
  late final AnimationController _cevirme;
  int? _eski;
  late int _hedef;
  int _yon = 1;
  final Set<int> _dokunanlar = {};
  Offset? _baslangic;
  Offset? _son;

  @override
  void initState() {
    super.initState();
    _hedef = widget.sayfa;
    _cevirme = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 610));
    _cevirme.addStatusListener((durum) {
      if (durum == AnimationStatus.completed && mounted) {
        setState(() => _eski = null);
      }
    });
  }

  @override
  void didUpdateWidget(covariant KitapSayfaCevirici oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.sayfa != oldWidget.sayfa) {
      // Aynı anda yeni bir seçim gelirse önceki dönüşümü kesip yeni hedefe geç.
      _eski = oldWidget.sayfa;
      _hedef = widget.sayfa;
      _yon = widget.sayfa > oldWidget.sayfa ? 1 : -1;
      _cevirme.forward(from: 0);
    }
  }

  @override
  void dispose() {
    _cevirme.dispose();
    super.dispose();
  }

  void _bitir(PointerUpEvent e) {
    _dokunanlar.remove(e.pointer);
    if (_baslangic != null && _son != null &&
        _dokunanlar.isEmpty && !_cevirme.isAnimating) {
      final fark = _son! - _baslangic!;
      if (fark.dx.abs() > 70 && fark.dx.abs() > fark.dy.abs() * 1.3) {
        // Mushaf sağdan sola okunur: sağa kaydırma bir sonraki sayfadır.
        final yeni = widget.sayfa + (fark.dx > 0 ? 1 : -1);
        if (yeni >= 1 && yeni <= widget.toplam) widget.onSayfaIste(yeni);
      }
    }
    _baslangic = null;
    _son = null;
  }

  Widget _yaprak(Widget icerik, {bool koyuKenar = false}) => Stack(
    fit: StackFit.expand,
    children: [
      DecoratedBox(
        decoration: BoxDecoration(
          color: const Color(0xFFF9F3E7),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(.17),
              blurRadius: 12, offset: const Offset(2, 3))],
          border: Border.symmetric(vertical: BorderSide(
              color: const Color(0xFFC4A77B).withOpacity(.55), width: 1)),
        ),
        child: icerik,
      ),
      if (koyuKenar)
        IgnorePointer(child: DecoratedBox(decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: _yon > 0 ? Alignment.centerRight : Alignment.centerLeft,
            end: _yon > 0 ? Alignment.centerLeft : Alignment.centerRight,
            colors: [Colors.black.withOpacity(.18), Colors.transparent],
            stops: const [.0, .48],
          ),
        ))),
    ],
  );

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: (e) {
        _dokunanlar.add(e.pointer);
        if (_dokunanlar.length == 1) { _baslangic = e.localPosition; _son = e.localPosition; }
        else { _baslangic = null; _son = null; }
      },
      onPointerMove: (e) { if (_dokunanlar.length == 1) _son = e.localPosition; },
      onPointerUp: _bitir,
      onPointerCancel: (e) {
        _dokunanlar.remove(e.pointer); _baslangic = null; _son = null;
      },
      child: ClipRect(child: AnimatedBuilder(
        animation: _cevirme,
        builder: (context, _) {
          if (_eski == null || !_cevirme.isAnimating) {
            return widget.sayfaOlustur(widget.sayfa);
          }
          final ilerleme = Curves.easeInOutCubic.transform(_cevirme.value);
          final ilkYari = ilerleme < .5;
          final t = ilkYari ? ilerleme * 2 : (ilerleme - .5) * 2;
          final sayfa = ilkYari ? _eski! : _hedef;
          final aci = (_yon == 1 ? 1.0 : -1.0) *
              (ilkYari ? -math.pi / 2 * t : math.pi / 2 * (1 - t));
          final donusum = Matrix4.identity()
            ..setEntry(3, 2, .0011)
            ..rotateY(aci);
          return Stack(fit: StackFit.expand, children: [
            widget.sayfaOlustur(_hedef),
            IgnorePointer(child: Transform(
              alignment: _yon > 0 ? Alignment.centerLeft : Alignment.centerRight,
              transform: donusum,
              child: _yaprak(widget.sayfaOlustur(sayfa), koyuKenar: true),
            )),
          ]);
        },
      )),
    );
  }
}
