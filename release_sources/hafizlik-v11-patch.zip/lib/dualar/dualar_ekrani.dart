import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../hafizlik/quran_veri.dart';
import '../ortak/tema.dart';
import 'ek_dualar.dart';

/// Ayet metinleri uygulamadaki Mushaf'tan okunur. Türkçe karşılıklar,
/// ayetlerin tam meali değil, açıkça işaretlenmiş kısa anlam özetleridir.
class Dua {
  final String ad;
  final int sure;
  final int baslangic;
  final int bitis;
  final String anlam;
  const Dua(this.ad, this.sure, this.baslangic, this.bitis, this.anlam);
}

const List<Dua> dualar = [
  Dua('Âyetü’l-Kürsî', 2, 255, 255,
      'Allah’tan başka ilah yoktur. O diridir, bütün varlığı ayakta tutandır. O’nun ilmi, kudreti ve hükümranlığı her şeyi kuşatır.'),
  Dua('Âmenerresûlü', 2, 285, 286,
      'Peygamber ve müminler Allah’a ve O’ndan gelen vahye iman eder. Allah hiç kimseye gücünün yettiğinden fazlasını yüklemez. Bağışlanma ve yardım dilerler.'),
  Dua('Dünya ve ahiret iyiliği', 2, 201, 201,
      'Rabbimiz, bize dünyada da ahirette de iyilik ver; bizi ateş azabından koru.'),
  Dua('İlim duası', 20, 114, 114,
      'Rabbim, ilmimi artır.'),
  Dua('Bağışlanma duası', 14, 41, 41,
      'Rabbimiz, beni, ana babamı ve müminleri hesap günü bağışla.'),
];

class _DuaKartVerisi {
  final String id;
  final String ad;
  final String kategori;
  final String kaynak;
  final String arapca;
  final String anlam;
  final bool ozettir;
  const _DuaKartVerisi({required this.id, required this.ad,
    required this.kategori, required this.kaynak, required this.arapca,
    required this.anlam, this.ozettir = false});
}

class DualarEkrani extends StatefulWidget {
  const DualarEkrani({super.key});
  @override
  State<DualarEkrani> createState() => _DualarEkraniState();
}

class _DualarEkraniState extends State<DualarEkrani> {
  late final Future<Map<String, String>> _ayetler = _ayetleriYukle();
  final TextEditingController _arama = TextEditingController();
  String _kategori = 'Tümü';
  Set<String> _favoriler = {};
  static const _kategoriListesi = ['Tümü', 'Kur’an duaları', 'Günlük dualar', 'Ayetler ve zikirler', 'Favorilerim'];

  @override
  void initState() { super.initState(); _favoriYukle(); }
  @override
  void dispose() { _arama.dispose(); super.dispose(); }

  Future<void> _favoriYukle() async {
    final p = await SharedPreferences.getInstance();
    if (mounted) setState(() => _favoriler = (p.getStringList('dua_favorileri') ?? []).toSet());
  }
  Future<void> _favoriDegistir(String id) async {
    final yenisi = {..._favoriler};
    if (!yenisi.add(id)) yenisi.remove(id);
    final p = await SharedPreferences.getInstance();
    await p.setStringList('dua_favorileri', yenisi.toList());
    if (mounted) setState(() => _favoriler = yenisi);
  }

  static Future<Map<String, String>> _ayetleriYukle() async {
    final ayetler = await QuranVeri.tumAyetler();
    return {for (final a in ayetler) '${a.sure}:${a.numara}': a.metin};
  }

  List<_DuaKartVerisi> _icerikler(Map<String, String> harita) {
    final ayetler = <_DuaKartVerisi>[
      for (final d in dualar)
        _DuaKartVerisi(
          id: 'ayet-${d.sure}-${d.baslangic}-${d.bitis}',
          ad: d.ad,
          kategori: d.sure == 2 && (d.baslangic == 255 || d.baslangic == 285)
              ? 'Ayetler ve zikirler' : 'Kur’an duaları',
          kaynak: '${d.sure}:${d.baslangic}${d.bitis == d.baslangic ? '' : '–${d.bitis}'}',
          arapca: [for (var i=d.baslangic; i<=d.bitis; i++)
              if ((harita['${d.sure}:$i'] ?? '').isNotEmpty) harita['${d.sure}:$i']!].join(' '),
          anlam: d.anlam,
          ozettir: true,
        ),
    ];
    final ekler = <_DuaKartVerisi>[
      for (var i = 0; i < ekDualar.length; i++)
        _DuaKartVerisi(
          id: 'ek-$i', ad: ekDualar[i].ad,
          kategori: ekDualar[i].kaynak.contains(':')
            ? 'Kur’an duaları' : 'Günlük dualar',
          kaynak: ekDualar[i].kaynak,
          arapca: ekDualar[i].arapca,
          anlam: ekDualar[i].turkce,
        ),
    ];
    return [...ayetler, ...ekler];
  }

  void _ayrintiGoster(_DuaKartVerisi d) {
    showModalBottomSheet<void>(context: context, isScrollControlled: true,
      showDragHandle: true, builder: (c) {
        final cs = Theme.of(c).colorScheme;
        return SafeArea(child: FractionallySizedBox(heightFactor: .83,
          child: Padding(padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text(d.kategori, style: TextStyle(color: cs.primary, fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              Text(d.ad, style: Theme.of(c).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text(d.kaynak, style: TextStyle(color: cs.onSurfaceVariant)),
              const SizedBox(height: 16),
              Expanded(child: SingleChildScrollView(child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  Container(padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(color: cs.primaryContainer.withOpacity(.38),
                      borderRadius: BorderRadius.circular(20)),
                    child: SelectableText(d.arapca.isEmpty
                      ? 'Arapça metin yüklenemedi. İnternetsiz Mushaf verisini kontrol edin.' : d.arapca,
                      textDirection: TextDirection.rtl, textAlign: TextAlign.center,
                      style: TextStyle(fontFamily: kMushafFontu, fontSize: 28, height: 2.0, color: cs.onSurface))),
                  const SizedBox(height: 18),
                  Text(d.ozettir ? 'Kısa anlam özeti' : 'Türkçe anlamı',
                    style: Theme.of(c).textTheme.titleSmall?.copyWith(color: cs.primary, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  SelectableText(d.anlam, style: Theme.of(c).textTheme.bodyLarge?.copyWith(height: 1.6)),
                  if (d.ozettir) ...[
                    const SizedBox(height: 12),
                    Text('Bu metin ayetin tam meali değil, anlam özetidir.',
                      style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
                  ],
                ]))),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: OutlinedButton.icon(onPressed: () {
                  Clipboard.setData(ClipboardData(text: '${d.ad}\n${d.arapca}\n${d.anlam}\nKaynak: ${d.kaynak}'));
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Dua kopyalandı.')));
                }, icon: const Icon(Icons.copy_rounded), label: const Text('Kopyala'))),
                const SizedBox(width: 10),
                Expanded(child: FilledButton.icon(onPressed: () async {
                  await _favoriDegistir(d.id);
                  if (c.mounted) Navigator.pop(c);
                }, icon: Icon(_favoriler.contains(d.id) ? Icons.bookmark_rounded : Icons.bookmark_add_outlined),
                  label: Text(_favoriler.contains(d.id) ? 'Kaydı kaldır' : 'Kaydet'))),
              ]),
            ]))));
      });
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Dua Kütüphanesi')),
      body: FutureBuilder<Map<String, String>>(
        future: _ayetler,
        builder: (context, snap) {
          final tumu = _icerikler(snap.data ?? {});
          final q = _arama.text.trim().toLowerCase();
          final secilen = tumu.where((d) =>
              (_kategori == 'Tümü' || (_kategori == 'Favorilerim'
                ? _favoriler.contains(d.id) : d.kategori == _kategori)) &&
              (q.isEmpty || '${d.ad} ${d.kaynak} ${d.anlam}'.toLowerCase().contains(q))).toList();
          return CustomScrollView(slivers: [
            SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(16, 16, 16, 6),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Container(padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(gradient: LinearGradient(colors: [cs.primary,
                    const Color(0xFF276E60)]), borderRadius: BorderRadius.circular(24)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Icon(Icons.auto_stories_rounded, color: Color(0xFFF5DC9B), size: 30),
                    const SizedBox(height: 12),
                    const Text('Her gün bir dua', style: TextStyle(color: Colors.white,
                      fontSize: 23, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    Text('${tumu.length} dua ve ayet • ${_favoriler.length} kayıtlı içerik',
                      style: const TextStyle(color: Colors.white70)),
                  ])),
                const SizedBox(height: 16),
                TextField(controller: _arama, onChanged: (_) => setState(() {}),
                  decoration: const InputDecoration(prefixIcon: Icon(Icons.search_rounded),
                    hintText: 'Dua veya kaynak ara', suffixIcon: Icon(Icons.tune_rounded))),
                const SizedBox(height: 12),
                SizedBox(height: 44, child: ListView(scrollDirection: Axis.horizontal,
                  children: [for (final k in _kategoriListesi)
                    Padding(padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(label: Text(k), selected: _kategori == k,
                        onSelected: (_) => setState(() => _kategori = k))),
                  ])),
                const SizedBox(height: 10),
                if (snap.connectionState != ConnectionState.done)
                  const LinearProgressIndicator(minHeight: 2),
                if (snap.hasError)
                  const Padding(padding: EdgeInsets.all(8),
                    child: Text('Mushaf ayetleri yüklenemedi; diğer duaları görüntüleyebilirsiniz.')),
              ]))),
            if (secilen.isEmpty)
              const SliverFillRemaining(hasScrollBody: false,
                child: Center(child: Text('Bu bölümde eşleşen dua bulunamadı.')))
            else
              SliverPadding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 30),
                sliver: SliverList.builder(itemCount: secilen.length,
                  itemBuilder: (context, i) {
                    final d = secilen[i];
                    final fav = _favoriler.contains(d.id);
                    return Padding(padding: const EdgeInsets.only(bottom: 10),
                      child: Card(clipBehavior: Clip.antiAlias, child: InkWell(
                        onTap: () => _ayrintiGoster(d),
                        child: Padding(padding: const EdgeInsets.all(16), child:
                          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Container(padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(color: cs.primaryContainer,
                                borderRadius: BorderRadius.circular(14)),
                              child: Icon(Icons.menu_book_rounded, color: cs.primary)),
                            const SizedBox(width: 12),
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(d.ad, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                              const SizedBox(height: 5),
                              Text(d.kategori, style: TextStyle(color: cs.primary, fontSize: 12)),
                              const SizedBox(height: 5),
                              Text(d.kaynak, style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
                              const SizedBox(height: 8),
                              Text(d.anlam, maxLines: 2, overflow: TextOverflow.ellipsis,
                                style: TextStyle(color: cs.onSurfaceVariant)),
                            ])),
                            IconButton(tooltip: fav ? 'Favoriden çıkar' : 'Favoriye ekle',
                              icon: Icon(fav ? Icons.bookmark_rounded : Icons.bookmark_outline_rounded,
                                color: fav ? cs.primary : cs.onSurfaceVariant),
                              onPressed: () => _favoriDegistir(d.id)),
                          ]))),
                      ));
                  })),
          ]);
        },
      ),
    );
  }
}
