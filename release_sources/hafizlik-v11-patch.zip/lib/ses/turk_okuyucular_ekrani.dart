import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../ortak/tema.dart';

/// Diyanet'in duyurduğu hafızlara erişim. Kayıtlar bu uygulamada yeniden
/// barındırılmaz; kişisel/üçüncü taraf kaydının izni varmış gibi sunulmaz.
const List<String> turkHafizlar = [
  'Hafız Osman Şahin',
  'Dr. Tayyar Altıkulaç',
  'İshak Danış',
  'Davut Kaya',
  'Bünyamin Topçuoğlu',
  'Erhan Mete',
];

class TurkOkuyucularEkrani extends StatelessWidget {
  const TurkOkuyucularEkrani({super.key});
  static final Uri _resmiKaynak = Uri.parse('https://kuran.diyanet.gov.tr/mushaf_v2');

  Future<void> _ac(BuildContext context) async {
    try {
      // Android Custom Tab ile uygulamanın içinde resmî kaynak açılır.
      final sonuc = await launchUrl(_resmiKaynak, mode: LaunchMode.inAppBrowserView);
      if (!sonuc && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Diyanet dinleme sayfası açılamadı. İnternet bağlantısını kontrol edin.')));
      }
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Diyanet sayfasına erişilemedi.')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Türk Hafızlar')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [cs.primary, const Color(0xFF276F62)]),
            borderRadius: BorderRadius.circular(24)),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.record_voice_over_rounded, color: Color(0xFFF4D797), size: 32),
            SizedBox(height: 12),
            Text('Türkiye’den hafızlar', style: TextStyle(color: Colors.white,
              fontWeight: FontWeight.w800, fontSize: 24)),
            SizedBox(height: 6),
            Text('Diyanet Kur’an Portalı üzerinden dinleyin.',
              style: TextStyle(color: Colors.white70)),
          ])),
        const SizedBox(height: 18),
        for (var i = 0; i < turkHafizlar.length; i++)
          Padding(padding: const EdgeInsets.only(bottom: 8),
            child: Card(child: ListTile(
              leading: CircleAvatar(backgroundColor: cs.primaryContainer,
                child: Icon(Icons.headphones_rounded, color: cs.primary)),
              title: Text(turkHafizlar[i], style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text('Diyanet dinleme kaynağı'),
              trailing: const Icon(Icons.open_in_new_rounded),
              onTap: () => _ac(context),
            ))),
        const SizedBox(height: 10),
        Card(child: Padding(padding: const EdgeInsets.all(16),
          child: Text('Bu isimler Diyanet’in okuyucu kataloğunda duyurulan hafızlardır. '
            'Tek tek kayıt bağlantıları ve kayıtların uygulamaya yeniden dağıtım izni '
            'doğrulanmadığı için sesleri APK’ya kopyalamıyoruz. '
            'Dinleme resmî portalda yapılır; uygun okuyucuyu portalın seslendirme menüsünden seçin.',
            style: TextStyle(color: cs.onSurfaceVariant, height: 1.45)))),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: () => _ac(context),
          icon: const Icon(Icons.open_in_browser_rounded),
          label: const Text('Diyanet dinleme ekranını aç')),
      ]),
    );
  }
}
