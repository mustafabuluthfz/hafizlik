import 'dart:async';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import '../bulmaca/sureler.dart';
import '../ortak/tema.dart';

/// Türkçe sesli meal, Kur'an tilaveti değil; ayrı bir oynatıcıdır.
/// Kaynak: Al Quran Cloud / Turkish Vakfi Audio (streaming).
/// Bir surenin ilk ayetinin Mushaf genelindeki sıra numarası (1 tabanlı).
int globalAyetBaslangici(int sure) {
  assert(sure >= 1 && sure <= 114);
  var toplam = 1;
  for (var i = 0; i < sure - 1; i++) toplam += sureler[i].ayetSayisi;
  return toplam;
}

class TurkceSesliMealEkrani extends StatefulWidget {
  const TurkceSesliMealEkrani({super.key});
  @override
  State<TurkceSesliMealEkrani> createState() => _TurkceSesliMealEkraniState();
}

class _TurkceSesliMealEkraniState extends State<TurkceSesliMealEkrani> {
  final AudioPlayer _player = AudioPlayer();
  int _sure = 1;
  bool _yukleniyor = false;
  String? _hata;

  @override
  void dispose() { _player.dispose(); super.dispose(); }

  Future<void> _cal() async {
    if (_yukleniyor) return;
    setState(() { _yukleniyor = true; _hata = null; });
    try {
      final start = globalAyetBaslangici(_sure);
      final sayi = sureler[_sure - 1].ayetSayisi;
      final kaynaklar = [for (var i = 0; i < sayi; i++)
        AudioSource.uri(Uri.parse('https://cdn.islamic.network/quran/audio/128/tr.vakfi-audio/${start + i}.mp3'))];
      await _player.setAudioSource(ConcatenatingAudioSource(children: kaynaklar));
      unawaited(_player.play().catchError((Object _) {
        if (mounted) setState(() => _hata = 'Ses oynatılırken hata oluştu.');
      }));
    } catch (_) {
      if (mounted) setState(() => _hata = 'Ses dosyası açılamadı. İnternet bağlantısını veya kaynağın erişilebilirliğini kontrol edin.');
    } finally {
      if (mounted) setState(() => _yukleniyor = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(appBar: AppBar(title: const Text('Türkçe Sesli Meal')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(
          gradient: LinearGradient(colors: [cs.primary, const Color(0xFF2B7667)]),
          borderRadius: BorderRadius.circular(24)),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.spatial_audio_rounded, color: Color(0xFFF4D797), size: 34),
            SizedBox(height: 14),
            Text('Kur’an’ı anlamak için dinleyin',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 23)),
            SizedBox(height: 8),
            Text('Türkçe meal seslendirmesi • Tilavet değildir',
              style: TextStyle(color: Colors.white70)),
          ])),
        const SizedBox(height: 20),
        DropdownButtonFormField<int>(value: _sure, isExpanded: true,
          decoration: const InputDecoration(labelText: 'Sure seçin', prefixIcon: Icon(Icons.menu_book_rounded)),
          items: [for (var i=0; i<sureler.length; i++)
            DropdownMenuItem(value: i+1, child: Text('${i+1}. ${sureler[i].trAd}', overflow: TextOverflow.ellipsis))],
          onChanged: (v) async {
            await _player.stop();
            if (mounted) setState(() => _sure = v ?? 1);
          }),
        const SizedBox(height: 18),
        Card(child: Padding(padding: const EdgeInsets.all(18),
          child: Column(children: [
            StreamBuilder<PlayerState>(stream: _player.playerStateStream,
              builder: (context, snap) => Icon(
                snap.data?.playing == true ? Icons.graphic_eq_rounded : Icons.headphones_rounded,
                color: cs.primary, size: 48)),
            const SizedBox(height: 10),
            Text(sureler[_sure - 1].trAd,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            StreamBuilder<int?>(stream: _player.currentIndexStream,
              builder: (context, snap) => Text('Ayet: ${(snap.data ?? 0) + 1} / ${sureler[_sure - 1].ayetSayisi}',
                style: TextStyle(color: cs.onSurfaceVariant))),
            const SizedBox(height: 16),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              IconButton(tooltip: 'Önceki ayet', onPressed: _player.seekToPrevious,
                icon: const Icon(Icons.skip_previous_rounded, size: 36)),
              const SizedBox(width: 12),
              StreamBuilder<PlayerState>(stream: _player.playerStateStream, builder: (context, snap) {
                final playing = snap.data?.playing ?? false;
                return FilledButton.icon(
                  onPressed: _yukleniyor ? null : playing ? _player.pause : () async {
                    if (_player.audioSource == null) { await _cal(); }
                    else { await _player.play(); }
                  },
                  icon: _yukleniyor
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
                  label: Text(_yukleniyor ? 'Yükleniyor' : playing ? 'Duraklat' : 'Dinle'),
                );
              }),
              const SizedBox(width: 12),
              IconButton(tooltip: 'Sonraki ayet', onPressed: _player.seekToNext,
                icon: const Icon(Icons.skip_next_rounded, size: 36)),
            ]),
          ]))),
        if (_hata != null) Padding(padding: const EdgeInsets.all(12),
          child: Text(_hata!, style: TextStyle(color: cs.error))),
        const SizedBox(height: 12),
        Text('Ses kaynağı: Al Quran Cloud · Turkish Vakfi Audio. '
          'Dinlemek için internet bağlantısı gerekir. Sesler APK’ya paketlenmez. '
          'Kayıtların hakları ilgili eser sahiplerinde kalır.',
          style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12, height: 1.5)),
      ]),
    );
  }
}
