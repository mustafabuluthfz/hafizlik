# Hafızlık V11 — Tasarım, Dua Kütüphanesi ve Türk Hafızlar

- Ana ekran hızlı işlemleri modern, erişilebilir, 2/3 sütuna uyumlu kartlar halinde yeniden düzenlendi.
- Kur’an / Hafızlık / Araçlar bölümlerine yerel arama ve sade katalog tasarımı eklendi.
- Açık / koyu tema renkleri, tipografi, düğmeler ve kartlar tutarlı hale getirildi.
- Dua Kütüphanesi: kategori, arama, favori, ayrıntı, Arapça metin, kaynak ve kopyalama.
- Âl-i İmrân 3:8 meali içindeki el-Vehhâb anlamı düzeltildi.
- Âyetü’l-Kürsî ve Âmenerresûlü için tam meal yerine "kısa anlam özeti" uyarısı getirildi.
- Türk hafızlar: Diyanet resmî dinleme portalına uygulama içinden erişim; ses kopyalanmıyor.
- Türkçe sesli meal: Al Quran Cloud Turkish Vakfi Audio ayet akışı ile ayrı oynatıcı.
- Mevcut ayet okuyucuları ve seçili ayet dinletme işlevi bozulmadı.
- Çevrimdışı Kur'an ASR modeli korunuyor.
- Android APK sürümü 2.2.0+15.

**Lisans notu:** Türk hafızların ses kayıtları yeniden barındırılmıyor;
ses haklarının ticari kullanım izni doğrulanmadan native ayet-ayrıntılı kayıtlar
uygulamaya dahil edilmemeli. Türkçe sesli meal başka bir özellik olup internet ister.
