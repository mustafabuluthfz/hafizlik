import 'package:flutter_test/flutter_test.dart';
import 'package:hafizlik_app/dualar/dualar_ekrani.dart';
import 'package:hafizlik_app/dualar/ek_dualar.dart';
import 'package:hafizlik_app/ses/turk_okuyucular_ekrani.dart';
import 'package:hafizlik_app/ses/turkce_sesli_meal_ekrani.dart';
import 'package:hafizlik_app/bulmaca/sureler.dart';

void main() {
  test('Dua kaynakları ve özet metinleri eksiksiz', () {
    expect(dualar.length, greaterThan(3));
    for (final d in dualar) {
      expect(d.ad.trim(), isNotEmpty);
      expect(d.anlam.trim(), isNotEmpty);
      expect(d.sure, inInclusiveRange(1, 114));
      expect(d.baslangic, lessThanOrEqualTo(d.bitis));
    }
    expect(ekDualar.first.turkce, contains('bağışta bulunansın'));
  });

  test('Türk hafızlar kayıtların isimleriyle listelenir', () {
    expect(turkHafizlar, contains('İshak Danış'));
    expect(turkHafizlar, contains('Hafız Osman Şahin'));
    expect(turkHafizlar.length, greaterThanOrEqualTo(5));
  });

  test('Türkçe sesli meal global ayet sırası doğru hesaplanır', () {
    expect(globalAyetBaslangici(1), 1);
    expect(globalAyetBaslangici(2), sureler[0].ayetSayisi + 1);
    expect(globalAyetBaslangici(114) + sureler[113].ayetSayisi - 1, 6236);
  });
}
