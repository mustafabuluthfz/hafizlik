# Mushaf Yoldaşım V12 Tasarım Paketi

- Uygulama adı Mushaf Yoldaşım olarak yenilendi.
- İkonlar, tema renkleri ve kart boyutları modernleştirildi.
- Türk okuyucular okuyucu listesine eklendi.
- Doğrulanmış ayet bazlı açık akış bulunmayan Türk okuyucular uygulama içi web görünümünde resmî/harici dinleme kaynağını açar.
