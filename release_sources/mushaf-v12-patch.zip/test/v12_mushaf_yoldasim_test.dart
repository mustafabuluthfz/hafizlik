import 'package:flutter_test/flutter_test.dart';
import 'package:hafizlik_app/ses/okuyucu.dart';

void main() {
  test('Önceki okuyucu tercih dizinleri korunur', () {
    expect(okuyucular.first.klasor, 'Alafasy_128kbps');
    expect(okuyucular[1].klasor, 'Husary_128kbps');
  });
  test('Türk hafızlar aynı okuyucu kataloğunda', () {
    expect(okuyucular.any((o) => o.ad == 'İshak Danış' && o.turkOkuyucu), isTrue);
    expect(okuyucular.any((o) => o.ad == 'Hafız Osman Şahin' && o.turkOkuyucu), isTrue);
    expect(okuyucular.where((o) => o.turkOkuyucu).every((o) => !o.ayetBazliAkis && !o.indirmeIzniVar && o.hariciDinlemeUrl != null), isTrue);
  });
}
