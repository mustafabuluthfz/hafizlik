# Mushaf Yoldaşım V14 – Çalışma ve görsel iyileştirmeler

- Mat kâğıt zeminli açık tema, kontrastı korunmuş kartlar
- İlk açılışta kullanım ve gizlilik koşullarını kabul ekranı (cihaz içi kabul kaydı)
- Mushaf okurken tüm sayfayı veya dokunulan tek ayeti dinleme
- Kur’an okuma bölümünde meal veya Diyanet bağlantısı bulunmuyor (kullanıcı tercihi)
- Hatim planında hedef, tamamlanan günler ve okuma kısayolları
- İlerleme ekranında haftalık okuma özeti
- Sesli Ayet Bul bölümünde Arapça metinle arama, sonuç sayısı ve eşleşme eşiği
- Esmaül Hüsna bölümünde favoriler, arama, detay ve kopyalama
- Ders Dinlet bölümünde kelime ilerlemesi ve öğretmen/kullanıcı tarafından elle kaydedilen hareke/tecvid notlarının açık ayrımı
- Android paket kimliği sabit; yeni sürüm 2.5.0+18

**İmza notu:** Önceki sürümler farklı geçici sertifikalarla imzalanmıştır. Bu sürüm için yeni bir kalıcı imza anahtarı oluşturulmuştur; gelecekteki sürümlerde aynı anahtar kullanılmalıdır. Anahtar depoya konmamalıdır.
