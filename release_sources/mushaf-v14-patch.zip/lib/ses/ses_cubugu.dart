import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../hafizlik/quran_veri.dart';
import '../ortak/ikonlar.dart';
import '../ortak/tema.dart';
import 'okuyucu.dart';
import 'sayfa_oynatici.dart';
import 'turk_ses_arsivi.dart';

/// Bir sayfanın ayetlerini sesli okutan çubuk.
/// Sayfa değiştiğinde yeni bir örnek oluşturulmalıdır (ValueKey ile).
class SesCubugu extends StatefulWidget {
  final int sayfaNo;
  final Ayet? seciliAyet;
  final int secimKimligi;

  const SesCubugu({super.key, required this.sayfaNo, this.seciliAyet, this.secimKimligi = 0});

  @override
  State<SesCubugu> createState() => _SesCubuguState();
}

class _SesCubuguState extends State<SesCubugu> {
  final SayfaOynatici _oynatici = SayfaOynatici();
  final AudioPlayer _turkOynatici = AudioPlayer();
  Okuyucu _okuyucu = okuyucular.first;
  List<Ayet> _ayetler = [];
  Ayet? _tekAyetModu;
  bool _yuklendi = false;
  String? _hata;
  bool _tekrarAcik = false;
  double _hiz = 1.0;

  @override
  void initState() {
    super.initState();
    _hazirla();
  }

  @override
  void didUpdateWidget(covariant SesCubugu oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.seciliAyet != null && oldWidget.secimKimligi != widget.secimKimligi) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _tekAyetCal(widget.seciliAyet!);
      });
    }
  }

  @override
  void dispose() {
    _oynatici.kapat();
    _turkOynatici.dispose();
    super.dispose();
  }

  Future<void> _hazirla() async {
    final prefs = await SharedPreferences.getInstance();
    final dizin = prefs.getInt('okuyucu_dizin') ?? 0;
    final ayetler = await QuranVeri.sayfa(widget.sayfaNo);
    if (!mounted) return;
    setState(() {
      _okuyucu = okuyucular[dizin.clamp(0, okuyucular.length - 1).toInt()];
      _ayetler = ayetler;
    });
    if (widget.seciliAyet != null) {
      await _tekAyetCal(widget.seciliAyet!);
    }
  }

  Future<void> _tekAyetCal(Ayet ayet) async {
    if (_okuyucu.turkOkuyucu) {
      setState(() => _hata = 'Türk okuyucunun sûre MP3 kaydı ayetlere ayrılmadığı için tek ayet oynatılamıyor.');
      return;
    }
    try {
      await _turkOynatici.stop();
      await _oynatici.durdur();
      await _oynatici.cal([ayet], _okuyucu);
      await _oynatici.hizAyarlama(_hiz);
      await _oynatici.tekrarModu(_tekrarAcik);
      if (mounted) setState(() { _tekAyetModu = ayet; _yuklendi = true; _hata = null; });
    } catch (_) {
      if (mounted) setState(() => _hata = 'Seçilen ayet çalınamadı. Bağlantıyı kontrol edin.');
    }
  }

  Future<void> _tamSayfaCal() async {
    if (_okuyucu.turkOkuyucu) { await _calVeyaDevamEt(); return; }
    try {
      await _oynatici.durdur();
      await _oynatici.cal(_ayetler, _okuyucu);
      await _oynatici.hizAyarlama(_hiz);
      await _oynatici.tekrarModu(_tekrarAcik);
      if (mounted) setState(() { _tekAyetModu = null; _yuklendi = true; _hata = null; });
    } catch (_) {
      if (mounted) setState(() => _hata = 'Tam sayfa dinletilemedi.');
    }
  }

  int get _aktifSure => _ayetler.isEmpty ? 1 : _ayetler.first.sure;

  Future<void> _turkKaydiEkle() async {
    final sure = _aktifSure;
    try {
      final yol = await TurkSesArsivi.kayitEkle(_okuyucu, sure);
      if (yol == null || !mounted) return;
      await _turkOynatici.stop();
      setState(() { _yuklendi = false; _hata = null; });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$sure. sûre kaydı eklendi. Dinletmek için oynatın.')),
      );
    } catch (e) {
      if (mounted) setState(() => _hata = 'MP3 eklenemedi. Dosyayı ve boş alanı kontrol edin.');
    }
  }

  Future<void> _calVeyaDevamEt() async {
    if (!mounted) return;
    setState(() => _hata = null);
    if (_okuyucu.turkOkuyucu) {
      try {
        if (_yuklendi) {
          if (_turkOynatici.playing) { await _turkOynatici.pause(); }
          else { _turkOynatici.play(); }
          return;
        }
        var yol = await TurkSesArsivi.mevcutKayit(_okuyucu, _aktifSure);
        if (yol == null) {
          await _turkKaydiEkle();
          yol = await TurkSesArsivi.mevcutKayit(_okuyucu, _aktifSure);
          if (yol == null) return;
        }
        await _turkOynatici.setFilePath(yol);
        await _turkOynatici.setSpeed(_hiz);
        await _turkOynatici.setLoopMode(_tekrarAcik ? LoopMode.one : LoopMode.off);
        if (!mounted) return;
        setState(() => _yuklendi = true);
        _turkOynatici.play();
      } catch (_) {
        if (mounted) setState(() => _hata = 'Türk okuyucunun MP3 kaydı çalınamadı. Yeni bir kayıt seçin.');
      }
      return;
    }
    try {
      if (!_yuklendi) {
        _tekAyetModu = null;
        await _oynatici.cal(_ayetler, _okuyucu);
        if (mounted) setState(() => _yuklendi = true);
      } else {
        await _oynatici.oynatDurdur();
      }
    } catch (_) {
      if (mounted) setState(() => _hata = 'Ses çalınamadı. Bağlantıyı ve okuyucuyu kontrol edin.');
    }
  }

  Future<void> _okuyucuSec() async {
    final secilen = await showModalBottomSheet<int>(
      context: context,
      showDragHandle: true,
      builder: (c) => ListView(
        shrinkWrap: true,
        padding: const EdgeInsets.only(bottom: kBosluk24),
        children: [
          for (var i = 0; i < okuyucular.length; i++)
            ListTile(
              title: Text(okuyucular[i].ad),
              subtitle: okuyucular[i].turkOkuyucu ? const Text('Türk okuyucu · Uygulama içi MP3') : null,
              trailing: okuyucular[i] == _okuyucu
                  ? const Icon(AppIkonlari.tamam, color: kYesil)
                  : null,
              onTap: () => Navigator.pop(c, i),
            ),
        ],
      ),
    );
    if (secilen == null) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('okuyucu_dizin', secilen);
    await _oynatici.durdur();
    await _turkOynatici.stop();
    _yuklendi = false;
    _tekAyetModu = null;
    setState(() => _okuyucu = okuyucular[secilen]);
  }

  @override
  Widget build(BuildContext context) {
    final renk = Theme.of(context).colorScheme;
    return Material(
      color: Theme.of(context).cardColor,
      elevation: 6,
      shadowColor: Colors.black26,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(kBosluk12, kBosluk8, kBosluk12, kBosluk4),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (_hata != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: kBosluk4),
                  child: Text(_hata!, style: const TextStyle(color: Colors.red, fontSize: 12)),
                ),
              if (_okuyucu.turkOkuyucu)
                Padding(padding: const EdgeInsets.fromLTRB(6, 0, 6, 5),
                  child: Row(children: [
                    const Icon(Icons.library_music_rounded, size: 16, color: kYesil),
                    const SizedBox(width: 7),
                    const Expanded(child: Text('Türk hafızın sûre MP3 dosyası cihazda çalınır; ayet takibi yoktur.',
                      style: TextStyle(fontSize: 11))),
                    TextButton.icon(onPressed: _turkKaydiEkle,
                      icon: const Icon(Icons.add_rounded, size: 17), label: const Text('MP3 ekle')),
                  ])),
              if (_ayetler.isNotEmpty) Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: _tamSayfaCal,
                  icon: const Icon(Icons.playlist_play_rounded, size: 19),
                  label: const Text('Sayfanın tamamını dinle'),
                ),
              ),
              StreamBuilder<PlayerState>(
                stream: _okuyucu.turkOkuyucu ? _turkOynatici.playerStateStream : _oynatici.durum,
                builder: (context, durumSnap) {
                  final calisiyor = durumSnap.data?.playing ?? false;
                  return StreamBuilder<int?>(
                    stream: _okuyucu.turkOkuyucu ? const Stream<int?>.empty() : _oynatici.siraIndeksi,
                    builder: (context, siraSnap) {
                      final sira = siraSnap.data;
                      final etiket = _tekAyetModu != null
                          ? 'Yalnızca ${_tekAyetModu!.numara}. ayet'
                          : (sira == null || sira >= _ayetler.length)
                              ? (_okuyucu.turkOkuyucu ? '$_aktifSure. sûre · Tam kayıt' : (_yuklendi ? 'Hazır' : 'Sayfayı sesli dinleyin'))
                              : 'Ayet ${_ayetler[sira].numara} çalıyor';
                      return Row(
                        children: [
                          IconButton(
                            tooltip: 'Önceki ayet',
                            onPressed: _yuklendi && !_okuyucu.turkOkuyucu ? _oynatici.onceki : null,
                            icon: const Icon(Icons.skip_previous_rounded),
                          ),
                          FilledButton(
                            onPressed: _ayetler.isEmpty ? null : _calVeyaDevamEt,
                            style: FilledButton.styleFrom(
                              minimumSize: const Size(48, 48),
                              shape: const CircleBorder(),
                              padding: EdgeInsets.zero,
                            ),
                            child: Icon(calisiyor ? Icons.pause_rounded : Icons.play_arrow_rounded),
                          ),
                          IconButton(
                            tooltip: 'Sonraki ayet',
                            onPressed: _yuklendi && !_okuyucu.turkOkuyucu ? _oynatici.sonraki : null,
                            icon: const Icon(Icons.skip_next_rounded),
                          ),
                          const SizedBox(width: kBosluk8),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(etiket, style: const TextStyle(fontWeight: FontWeight.w600)),
                                Text(_okuyucu.tamEtiket,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(fontSize: 12, color: renk.onSurface.withOpacity(0.6))),
                              ],
                            ),
                          ),
                          PopupMenuButton<String>(
                            tooltip: 'Dinleme ayarları',
                            icon: Icon(Icons.tune_rounded, color: _tekrarAcik ? kYesil : null),
                            onSelected: (secim) async {
                              if (secim == 'tekrar') {
                                final yeni = !_tekrarAcik;
                                if (_okuyucu.turkOkuyucu) { await _turkOynatici.setLoopMode(yeni ? LoopMode.one : LoopMode.off); }
                                else { await _oynatici.tekrarModu(yeni); }
                                if (mounted) setState(() => _tekrarAcik = yeni);
                              } else if (secim.startsWith('hiz:')) {
                                final hiz = double.tryParse(secim.substring(4));
                                if (hiz != null) {
                                  if (_okuyucu.turkOkuyucu) { await _turkOynatici.setSpeed(hiz); }
                                  else { await _oynatici.hizAyarlama(hiz); }
                                  if (mounted) setState(() => _hiz = hiz);
                                }
                              }
                            },
                            itemBuilder: (context) => [
                              PopupMenuItem(value: 'tekrar', child: Text(_tekrarAcik ? '✓ Tekrarı kapat' : 'Dinletiyi tekrarla')),
                              PopupMenuItem(value: 'hiz:0.75', child: Text(_hiz == 0.75 ? '✓ 0,75× yavaş' : '0,75× yavaş')),
                              PopupMenuItem(value: 'hiz:1.0', child: Text(_hiz == 1.0 ? '✓ 1,00× normal' : '1,00× normal')),
                              PopupMenuItem(value: 'hiz:1.25', child: Text(_hiz == 1.25 ? '✓ 1,25×' : '1,25×')),
                              PopupMenuItem(value: 'hiz:1.5', child: Text(_hiz == 1.5 ? '✓ 1,50× hızlı' : '1,50× hızlı')),
                            ],
                          ),
                          IconButton(
                            tooltip: 'Okuyucu seç',
                            onPressed: _okuyucuSec,
                            icon: const Icon(Icons.record_voice_over_rounded, size: 19),
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
