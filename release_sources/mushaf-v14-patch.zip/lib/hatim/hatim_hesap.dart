/// Günlük hatim sayfalarını dengeli paylaştırır.
/// Sayfaların tümü tam bir kez verilir; son günlerde boş aralık oluşmaz.
class HatimHesap {
  static (int, int) aralik(int gunIndeksi, int toplamGun, int toplamSayfa) {
    if (toplamGun < 1 || toplamSayfa < 1 || gunIndeksi < 0 || gunIndeksi >= toplamGun) {
      throw ArgumentError('Geçersiz hatim aralığı');
    }
    final taban = toplamSayfa ~/ toplamGun;
    final fazla = toplamSayfa % toplamGun;
    final bas = gunIndeksi * taban + (gunIndeksi < fazla ? gunIndeksi : fazla) + 1;
    final adet = taban + (gunIndeksi < fazla ? 1 : 0);
    return (bas, bas + adet - 1);
  }

  static int sayfaSayisi(int gunIndeksi, int toplamGun, int toplamSayfa) {
    final (a, b) = aralik(gunIndeksi, toplamGun, toplamSayfa);
    return b - a + 1;
  }

  static double ilerleme(Iterable<int> gunler, int toplamGun) {
    final tamam = gunler.where((g) => g >= 0 && g < toplamGun).toSet().length;
    return toplamGun <= 0 ? 0 : tamam / toplamGun;
  }
}
