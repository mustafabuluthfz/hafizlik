import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../hafizlik/hafizlik_sira.dart';
import '../kuran/kuran_okuma_ekrani.dart';
import '../ortak/tema.dart';
import 'hatim_hesap.dart';

class HatimEkrani extends StatefulWidget {
  const HatimEkrani({super.key});
  @override
  State<HatimEkrani> createState() => _HatimEkraniState();
}

class _HatimEkraniState extends State<HatimEkrani> {
  static const _secenekler = [15, 20, 30, 40, 60];
  bool _yukleniyor = true;
  DateTime? _baslangic;
  int _gun = 30;
  int _tamamlananHatim = 0;
  Set<int> _tamamlananGunler = {};
  int get _sayfaSayisi => HafizlikSira.toplamSayfa;

  @override
  void initState() { super.initState(); _yukle(); }

  Future<void> _yukle() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('hatim_tamam') ?? '[]';
    List<dynamic> liste = [];
    try { liste = jsonDecode(raw) as List<dynamic>; } catch (_) { /* Eski kayıt bozuk olabilir. */ }
    if (!mounted) return;
    setState(() {
      _baslangic = DateTime.tryParse(p.getString('hatim_bas') ?? '');
      _gun = _secenekler.contains(p.getInt('hatim_gun')) ? p.getInt('hatim_gun')! : 30;
      _tamamlananHatim = p.getInt('hatim_sayi') ?? 0;
      _tamamlananGunler = liste.whereType<int>().where((v) => v >= 0 && v < _gun).toSet();
      _yukleniyor = false;
    });
  }

  int get _bugunIndeks {
    if (_baslangic == null) return 0;
    final b = _baslangic!, n = DateTime.now();
    return DateTime.utc(n.year, n.month, n.day)
      .difference(DateTime.utc(b.year, b.month, b.day)).inDays;
  }

  (int, int) _aralik(int i) => HatimHesap.aralik(i, _gun, _sayfaSayisi);
  double get _ilerleme => HatimHesap.ilerleme(_tamamlananGunler, _gun);
  int get _okunanSayfa => [for (final i in _tamamlananGunler) HatimHesap.sayfaSayisi(i, _gun, _sayfaSayisi)]
    .fold<int>(0, (a,b) => a+b);

  Future<void> _baslat({bool yeniHatim = false}) async {
    final p = await SharedPreferences.getInstance();
    final n = DateTime.now();
    if (yeniHatim) await p.setInt('hatim_sayi', _tamamlananHatim + 1);
    await p.setString('hatim_bas', DateTime(n.year, n.month, n.day).toIso8601String());
    await p.setString('hatim_tamam', '[]');
    await _yukle();
  }

  Future<void> _gunSec(int gun) async {
    if (_baslangic != null) return; // Devam eden planın dağılımını değiştirme.
    final p = await SharedPreferences.getInstance();
    await p.setInt('hatim_gun', gun);
    if (mounted) setState(() => _gun = gun);
  }

  Future<void> _gunDurumunuDegistir(int i) async {
    final yeni = {..._tamamlananGunler};
    if (!yeni.add(i)) yeni.remove(i);
    final p = await SharedPreferences.getInstance();
    await p.setString('hatim_tamam', jsonEncode(yeni.toList()..sort()));
    if (mounted) setState(() => _tamamlananGunler = yeni);
  }

  Future<void> _yeniHatimOnayi() async {
    final onay = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: Text(_ilerleme >= 1 ? 'Yeni hatim başlatılsın mı?' : 'Plan sıfırlansın mı?'),
      content: Text(_ilerleme >= 1
          ? 'Tamamlanan hatim sayınız bir artacak ve yeni plan bugün başlayacak.'
          : 'Mevcut planınızın işaretlenmiş günleri silinecek. Tamamlanmamış hatim sayılmaz.'),
      actions: [TextButton(onPressed: ()=>Navigator.pop(ctx,false),child:const Text('Vazgeç')),
        FilledButton(onPressed: ()=>Navigator.pop(ctx,true),child:const Text('Onayla'))],
    ));
    if (onay == true) await _baslat(yeniHatim: _ilerleme >= 1);
  }

  void _okumayaGit(int i) {
    final (ilk, _) = _aralik(i);
    Navigator.push(context, MaterialPageRoute(builder: (_) => KuranOkumaEkrani(baslangicSayfa: ilk)));
  }

  @override
  Widget build(BuildContext context) {
    final renk = Theme.of(context).colorScheme;
    final aktif = _baslangic != null;
    final bugun = _bugunIndeks;
    final tamam = aktif && _ilerleme >= 1;
    return Scaffold(
      appBar: AppBar(title: const Text('Hatim Planım')),
      body: _yukleniyor ? const Center(child: CircularProgressIndicator()) :
      ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(18),child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(Icons.auto_stories_rounded, size: 24, color: renk.primary),
              const SizedBox(width: 9),
              Expanded(child: Text(aktif ? 'Hatim yolculuğum' : 'Hedefini belirle',
                style: Theme.of(context).textTheme.titleLarge)),
            ]),
            const SizedBox(height: 14),
            Wrap(spacing: 7, runSpacing: 7, children: [
              for (final g in _secenekler) ChoiceChip(label: Text('$g gün'), selected: _gun == g,
                onSelected: aktif ? null : (_) => _gunSec(g)),
            ]),
            if (aktif) const Padding(padding: EdgeInsets.only(top: 8),
              child: Text('Plan başladıktan sonra gün sayısı değiştirilemez.',style: TextStyle(fontSize: 12))),
            const SizedBox(height: 14),
            LinearProgressIndicator(value: _ilerleme, minHeight: 9, borderRadius: BorderRadius.circular(10)),
            const SizedBox(height: 9),
            Text('${(_ilerleme * 100).round()}% tamamlandı  ·  $_okunanSayfa / $_sayfaSayisi sayfa'),
            const SizedBox(height: 5),
            Text('$_tamamlananHatim tamamlanan hatim  ·  ${_tamamlananGunler.length} / $_gun gün',
              style: TextStyle(color: renk.onSurfaceVariant, fontSize: 12)),
          ]))),
        const SizedBox(height: 12),
        if (!aktif) FilledButton.icon(onPressed: () => _baslat(),
          icon: const Icon(Icons.play_circle_outline_rounded), label: const Text('Hatmi başlat'))
        else ...[
          if (tamam) Card(child: Padding(padding: const EdgeInsets.all(18),
            child: Column(children: [const Icon(Icons.verified_rounded, size: 38, color: kAltin),
              const SizedBox(height: 9), const Text('Tüm günler tamamlandı!',
                style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8), FilledButton(onPressed: _yeniHatimOnayi,
                child: const Text('Yeni hatime başla'))]))
          else if (bugun >= 0 && bugun < _gun) ...[
            Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Bugünün hedefi · ${bugun+1}. gün',style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 6),
                Text('Sayfa ${_aralik(bugun).$1}–${_aralik(bugun).$2}',
                  style: const TextStyle(fontSize: 24,fontWeight: FontWeight.w800,color: kYesil)),
                const SizedBox(height: 12),
                Row(children: [Expanded(child: FilledButton.icon(
                  onPressed: () => _okumayaGit(bugun),icon: const Icon(Icons.menu_book_rounded),
                  label: const Text('Okumaya git'))), const SizedBox(width: 8),
                  Expanded(child: OutlinedButton.icon(onPressed: ()=>_gunDurumunuDegistir(bugun),
                    icon: Icon(_tamamlananGunler.contains(bugun)
                      ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded),
                    label: Text(_tamamlananGunler.contains(bugun) ? 'Tamamlandı' : 'Tamamla')))]),
              ]))),
          ] else const Padding(padding: EdgeInsets.all(12), child: Text(
            'Planın takvim süresi doldu. Eksik günleri aşağıdan tamamlayabilir veya yeni plan oluşturabilirsiniz.')),
          const SizedBox(height: 10),
          OutlinedButton.icon(onPressed: _yeniHatimOnayi,
            icon: const Icon(Icons.restart_alt_rounded),label: const Text('Yeni plan oluştur')),
        ],
        const SizedBox(height: 20),
        Text('Hatim takvimi',style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 8),
        if (aktif) for (var i=0;i<_gun;i++)
          Card(child: ListTile(
            dense: true,
            leading: Icon(_tamamlananGunler.contains(i)
              ? Icons.check_circle_rounded : Icons.circle_outlined,
              size: 22, color: _tamamlananGunler.contains(i) ? kYesil : kAltin),
            title: Text('${i+1}. gün  ·  Sayfa ${_aralik(i).$1}–${_aralik(i).$2}'),
            subtitle: i == bugun ? const Text('Bugün') :
              (i < bugun && !_tamamlananGunler.contains(i) ? const Text('Tamamlanmayı bekliyor') : null),
            trailing: IconButton(tooltip: 'Tamamlandı durumunu değiştir',
              onPressed: () => _gunDurumunuDegistir(i),
              icon: Icon(_tamamlananGunler.contains(i) ? Icons.check_box_rounded : Icons.check_box_outline_blank_rounded)),
            onTap: () => _okumayaGit(i),
          )),
      ]),
    );
  }
}
