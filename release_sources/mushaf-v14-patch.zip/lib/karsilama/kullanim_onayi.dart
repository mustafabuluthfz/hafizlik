import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Metin anlamlı ölçüde değiştiğinde sürümü artırın.
const int kKullanimMetniSurumu = 1;
const String kKullanimMetni = '''
MUSHAF YOLDAŞIM – KULLANIM KOŞULLARI VE GİZLİLİK BİLGİSİ

1. Mushaf Yoldaşım; Kur’an okuma, dinleme, ezber çalışma ve kişisel takip için yardımcı bir araçtır. Dinî eğitimde öğretmenin yerini almaz.

2. Ders Dinlet mikrofon sesini cihazdaki yerel tanıma modeliyle değerlendirir. Otomatik sonuçlar hatalı olabilir; hareke, mahreç ve tecvid değerlendirmesi için uzman görüşü gerekir.

3. Okuma geçmişi, tercih ve hatim bilgileri, ders gözlem notları ile bu onayın tarihi cihazda saklanır. Verileri sıfırladığınızda silinebilir.

4. Çevrimiçi kıraat kaynaklarını kullanırken üçüncü taraf sitelere bağlantı kurulabilir. Bu sitelerde kendi kullanım ve gizlilik koşulları geçerlidir.

5. Namaz vakitleri hesaplama yoluyla sunulabilir. Önemli vakitleri resmî takvimle karşılaştırın.

6. Üçüncü kişilerin ses kayıtları ve diğer içeriklerinin hakları ilgili hak sahiplerinde kalır.

18 yaşından küçükseniz bu metni ebeveyniniz veya yasal temsilcinizle birlikte değerlendirin.

Bu onay, metni okuduğunuzu uygulama üzerinde kaydeder. Kimlik doğrulaması veya nitelikli elektronik imza değildir.
''';

class KullanimOnayiEkrani extends StatefulWidget {
  final Widget sonraki;
  const KullanimOnayiEkrani({super.key, required this.sonraki});

  static Future<bool> onaylandiMi() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt('kullanim_metni_surum') == kKullanimMetniSurumu;
  }

  @override
  State<KullanimOnayiEkrani> createState() => _KullanimOnayiEkraniState();
}

class _KullanimOnayiEkraniState extends State<KullanimOnayiEkrani> {
  bool _okudum = false;
  bool _kaydediyor = false;

  Future<void> _kabulEt() async {
    if (!_okudum || _kaydediyor) return;
    setState(() => _kaydediyor = true);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('kullanim_metni_surum', kKullanimMetniSurumu);
    await prefs.setString('kullanim_onay_tarihi', DateTime.now().toIso8601String());
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute<void>(builder: (_) => widget.sonraki),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Kullanım koşulları')),
    body: SafeArea(child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        Expanded(child: Card(child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Icon(Icons.menu_book_rounded, size: 34, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 12),
            Text('Mushaf Yoldaşım', textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 18),
            const SelectableText(kKullanimMetni, style: TextStyle(height: 1.6)),
          ],
        ))),
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          value: _okudum,
          onChanged: _kaydediyor ? null : (v) => setState(() => _okudum = v ?? false),
          title: const Text('Metni okudum ve kabul ediyorum'),
          subtitle: const Text('Onay yalnızca bu cihazda saklanır.'),
        ),
        SizedBox(width: double.infinity, child: FilledButton.icon(
          onPressed: _okudum && !_kaydediyor ? _kabulEt : null,
          icon: const Icon(Icons.check_circle_outline_rounded),
          label: Text(_kaydediyor ? 'Kaydediliyor…' : 'Kabul et ve devam et'),
        )),
      ]),
    )),
  );
}
