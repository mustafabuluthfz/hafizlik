import 'package:flutter_test/flutter_test.dart';
import 'package:hafizlik_app/esma/esmaul_husna_ekrani.dart';
import 'package:hafizlik_app/karsilama/kullanim_onayi.dart';
import 'package:hafizlik_app/hatim/hatim_hesap.dart';
import 'package:hafizlik_app/kuran/kuran_okuma_ekrani.dart';
import 'package:hafizlik_app/kuran/sesli_ayet_bul_ekrani.dart';
import 'package:hafizlik_app/ilerleme/ilerleme_ekrani.dart';
import 'package:hafizlik_app/ders/ders_ekrani.dart';

void main() {
  test('Esmaül Hüsna 99 adı içerir', () {
    expect(esmaulHusna.length, 99);
    expect(esmaulHusna.map((e) => e.no).toSet().length, 99);
  });
  test('Kullanım koşulları meal veya Diyanet vaadi içermez', () {
    expect(kKullanimMetni.contains('Diyanet meali'), isFalse);
    expect(kKullanimMetni.contains('cihaz'), isTrue);
  });
  test('Hatim planı sayfa aralığı toplamı eşit dağıtır', () {
    final dagilim = [for (var i = 0; i < 30; i++) HatimHesap.aralik(i, 30, 604)];
    expect(dagilim.first.$1, 1);
    expect(dagilim.last.$2, 604);
  });
  test('Yeni ekranlar oluşturulabilir', () {
    expect(const EsmaulHusnaEkrani(), isNotNull);
    expect(const KuranOkumaEkrani(), isNotNull);
    expect(const SesliAyetBulEkrani(), isNotNull);
    expect(const IlerlemeEkrani(), isNotNull);
    expect(const DersEkrani(), isNotNull);
  });
}
