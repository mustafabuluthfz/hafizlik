import 'package:flutter_test/flutter_test.dart';
import 'package:hafizlik_app/ses/okuyucu.dart';
import 'package:hafizlik_app/ses/turk_ses_arsivi.dart';
import 'package:hafizlik_app/ortak/tema.dart';

void main() {
  test('Önceki okuyucu tercihleri korunur', () {
    expect(okuyucular.first.klasor, 'Alafasy_128kbps');
    expect(okuyucular[1].klasor, 'Husary_128kbps');
  });
  test('Türk okuyucular aynı seçicide ve MP3 aktarım modunda', () {
    expect(okuyucular.any((o) => o.ad == 'İshak Danış' && o.turkOkuyucu), isTrue);
    expect(okuyucular.any((o) => o.ad == 'Hafız Osman Şahin' && o.turkOkuyucu), isTrue);
    for (final o in okuyucular.where((o) => o.turkOkuyucu)) {
      expect(o.ayetBazliAkis, isFalse);
      expect(o.indirmeIzniVar, isFalse);
    }
  });
  test('Sûre MP3 dosyası doğru adlandırılır', () {
    expect(TurkSesArsivi.dosyaAdi(1), '001.mp3');
    expect(TurkSesArsivi.dosyaAdi(114), '114.mp3');
  });
  test('Modern tema renkleri tanımlı', () {
    expect(kYesil.value, isNot(0));
    expect(kAltin.value, isNot(0));
  });
}
