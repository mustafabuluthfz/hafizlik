# Mushaf Yoldaşım V13 — Tasarım ve Türk okuyucu oynatımı

- Türk okuyucular aynı ayet okuyucusu listesinde. V12’deki web sayfasına yönlendirme kaldırıldı.
- Okuyucu seçildiğinde telefondan MP3 dosyası seçilip doğrudan **uygulamanın kendi oynatıcısında** açılır.
- Sûre MP3’leri uygulamanın kalıcı veri alanında, okuyucu + sûre numarasıyla saklanır. Bir sonraki dinlemede yeniden seçmek gerekmez.
- Telif nedeniyle Türk okuyucuların kayıtları APK’ya eklenmez. Kendi kullanma hakkınız olan MP3 dosyalarını seçin.
- Türk okuyucu ile tüm sûre baştan çalınır; ayet bazında takip, otomatik sıradaki ayet ve ayet tekrarı henüz mümkün değildir. Bu işlev, ayet bazında kayıt/zamanlama verisi gerektirir.
- Ana ekran ve bölümler: daha küçük simgeler, renkli dokunuşlar, kompakt kartlar, açık/koyu tema ve daha temiz boşluklar.
- Uygulama adı Mushaf Yoldaşım; mevcut Android paket kimliği korunmuştur.
