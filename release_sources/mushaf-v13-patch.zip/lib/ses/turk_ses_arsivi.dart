import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'okuyucu.dart';

/// Türk okuyucular için kullanıcı tarafından seçilen, cihazda saklanan sûre MP3'leri.
/// Harici oynatıcı, sunucu veya başka bir uygulama gerektirmez.
class TurkSesArsivi {
  static String dosyaAdi(int sure) => '${sure.toString().padLeft(3, '0')}.mp3';

  static Future<File> _hedef(Okuyucu okuyucu, int sure) async {
    if (!okuyucu.turkOkuyucu) {
      throw ArgumentError('Bu arşiv yalnızca Türk okuyucu kayıtları içindir.');
    }
    if (sure < 1 || sure > 114) throw RangeError.range(sure, 1, 114);
    final root = await getApplicationSupportDirectory();
    final klasor = Directory('${root.path}/turk_okuyucular/${okuyucu.klasor}');
    if (!await klasor.exists()) await klasor.create(recursive: true);
    return File('${klasor.path}/${dosyaAdi(sure)}');
  }

  static Future<String?> mevcutKayit(Okuyucu okuyucu, int sure) async {
    final file = await _hedef(okuyucu, sure);
    return await file.exists() && await file.length() > 0 ? file.path : null;
  }

  /// Android'in dosya seçicisinden tek bir MP3 alır, kalıcı uygulama alanına kopyalar.
  /// Dosya seçimi iptal edilirse null döner.
  static Future<String?> kayitEkle(Okuyucu okuyucu, int sure) async {
    final secim = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['mp3'],
      allowMultiple: false,
      withData: false,
    );
    if (secim == null || secim.files.isEmpty) return null;
    final kaynak = secim.files.single.path;
    if (kaynak == null) throw const FileSystemException('Seçilen dosya okunamadı.');
    final dosya = File(kaynak);
    if (!await dosya.exists() || await dosya.length() == 0) {
      throw const FileSystemException('Seçilen MP3 dosyası boş veya kullanılamıyor.');
    }
    final hedef = await _hedef(okuyucu, sure);
    if (dosya.absolute.path != hedef.absolute.path) await dosya.copy(hedef.path);
    return hedef.path;
  }
}
