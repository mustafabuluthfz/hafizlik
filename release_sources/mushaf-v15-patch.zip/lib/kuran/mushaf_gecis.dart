import '../hafizlik/quran_veri.dart';

/// Bulunan ayetin gerçek Mushaf sayfası, mevcut yerel veriyle belirlenir.
/// Sûre ve ayet numarası yalnızca o sûrenin ayetleri arasında aranır.
Ayet? mushafAyetiBul(Iterable<Ayet> ayetler, int sureNo, int ayetNo) {
  if (sureNo < 1 || sureNo > 114 || ayetNo < 1) return null;
  for (final ayet in ayetler) {
    if (ayet.sure == sureNo && ayet.numara == ayetNo) return ayet;
  }
  return null;
}
