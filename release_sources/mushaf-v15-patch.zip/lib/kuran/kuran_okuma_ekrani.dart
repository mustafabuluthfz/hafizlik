import 'dart:async';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../bulmaca/sureler.dart';
import 'mushaf_gecis.dart';
import '../hafizlik/hafizlik_sira.dart';
import '../hafizlik/quran_veri.dart';
import '../ortak/ilerleme_depo.dart';
import '../ortak/mushaf.dart';
import '../ses/ses_cubugu.dart';
import '../ortak/tema.dart';
import '../ortak/ikonlar.dart';

/// Tüm Kur'an'ı mushaf sayfa sayfa okutur.
/// - İki parmakla sayfayı büyütüp küçültebilir, büyütünce kaydırabilirsiniz.
/// - Sayfalar "Sonraki" ve "Önceki" düğmeleriyle çevrilir.
/// - Üstteki simgeden cüz, sure veya sayfa seçilebilir.
class KuranOkumaEkrani extends StatefulWidget {
  final int? baslangicSayfa;

  const KuranOkumaEkrani({super.key, this.baslangicSayfa});

  @override
  State<KuranOkumaEkrani> createState() => _KuranOkumaEkraniState();
}

class _KuranOkumaEkraniState extends State<KuranOkumaEkrani> {
  late int _sayfa;
  late final PageController _kontrol;
  Ayet? _seciliAyet;
  int _secimKimligi = 0;

  final AudioPlayer _cevirmeSesi = AudioPlayer(handleInterruptions: false);
  bool _cevirmeSesiAcik = true;
  bool _cevirmeSesiHazir = false;

  static int _sinirla(int v) {
    if (v < 1) return 1;
    if (v > HafizlikSira.toplamSayfa) return HafizlikSira.toplamSayfa;
    return v;
  }

  @override
  void initState() {
    super.initState();
    _sayfa = _sinirla(widget.baslangicSayfa ?? 1);
    _kontrol = PageController(initialPage: _sayfa - 1);
    IlerlemeDepo.kuranAcildi();
    _sesTercihiniYukle();
    _sayfaSesiniHazirla();
    if (widget.baslangicSayfa == null) _sonKalinanaGit();
  }

  Future<void> _sesTercihiniYukle() async {
    final p = await SharedPreferences.getInstance();
    if (mounted) setState(() {
      _cevirmeSesiAcik = p.getBool('kuran_sayfa_sesi') ?? true;
    });
  }

  Future<void> _sayfaSesiniHazirla() async {
    try {
      await _cevirmeSesi.setAsset('assets/audio/page_turn.wav');
      await _cevirmeSesi.setVolume(0.25);
      _cevirmeSesiHazir = true;
    } catch (_) { /* Ses yüklenemezse sayfa çevirme devam eder. */ }
  }

  void _sayfaSesiniCal() {
    if (!_cevirmeSesiAcik || !_cevirmeSesiHazir) return;
    unawaited(() async {
      try {
        await _cevirmeSesi.seek(Duration.zero);
        await _cevirmeSesi.play();
      } catch (_) { /* İsteğe bağlı ses, okumayı engellemez. */ }
    }());
  }

  Future<void> _cevirmeSesiniDegistir() async {
    final yeni = !_cevirmeSesiAcik;
    setState(() => _cevirmeSesiAcik = yeni);
    final p = await SharedPreferences.getInstance();
    await p.setBool('kuran_sayfa_sesi', yeni);
  }

  /// Açılışta son kalınan sayfaya git.
  Future<void> _sonKalinanaGit() async {
    final son = await OkumaKaydi.sonSayfa();
    if (son == null || son == _sayfa || !mounted) return;
    _git(son, sesli: false);
  }

  Future<void> _yerImiDegistir() async {
    final eklendi = await OkumaKaydi.yerImiDegistir(_sayfa);
    if (!mounted) return;
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(eklendi
          ? 'Sayfa $_sayfa yer imlerine eklendi'
          : 'Yer imi kaldırıldı'),
      behavior: SnackBarBehavior.floating,
    ));
  }

  Future<void> _yerImleriniAc() async {
    final liste = await OkumaKaydi.yerImleri();
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) {
        if (liste.isEmpty) {
          return const Padding(
            padding: EdgeInsets.all(24),
            child: Text('Henüz yer imi yok. Üstteki yer imi simgesiyle ekleyebilirsiniz.'),
          );
        }
        return ListView(
          shrinkWrap: true,
          children: [
            for (final p in liste)
              ListTile(
                leading: const Icon(AppIkonlari.yerImi, color: kAltin),
                title: Text('Sayfa $p'),
                subtitle: Text('${HafizlikSira.cuzOf(p)}. Cüz'),
                onTap: () {
                  Navigator.of(sheetContext).pop();
                  _git(p);
                },
              ),
          ],
        );
      },
    );
  }

  @override
  void dispose() {
    _kontrol.dispose();
    _cevirmeSesi.dispose();
    super.dispose();
  }

  void _git(int sayfa, {bool sesli = true}) {
    final hedef = _sinirla(sayfa);
    if (hedef == _sayfa) return;
    final fark = (hedef - _sayfa).abs();
    if (sesli) _sayfaSesiniCal();
    setState(() { _sayfa = hedef; _seciliAyet = null; });
    if (_kontrol.hasClients) {
      if (fark <= 1) {
        unawaited(_kontrol.animateToPage(hedef - 1,
          duration: const Duration(milliseconds: 340),
          curve: Curves.easeInOutCubic));
      } else {
        // Çok uzak sayfalarda uzun kaydırma animasyonuyla kullanıcıyı bekletme.
        _kontrol.jumpToPage(hedef - 1);
      }
    }
    OkumaKaydi.sonSayfaKaydet(hedef);
  }

  Future<void> _seciciyiAc() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => _GitPaneli(
        mevcutSayfa: _sayfa,
        onGit: (sayfa) {
          Navigator.of(sheetContext).pop();
          _git(sayfa);
        },
        onAyetGit: (ayet) {
          Navigator.of(sheetContext).pop();
          _git(ayet.sayfa);
          setState(() {
            _seciliAyet = ayet;
            _secimKimligi++;
          });
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sayfa $_sayfa / ${HafizlikSira.toplamSayfa}'),
        actions: [
          IconButton(
            tooltip: _cevirmeSesiAcik ? 'Sayfa çevirme sesini kapat' : 'Sayfa çevirme sesini aç',
            icon: Icon(_cevirmeSesiAcik ? Icons.volume_up_rounded : Icons.volume_off_rounded,
              size: 19, color: _cevirmeSesiAcik ? kYesil : null),
            onPressed: _cevirmeSesiniDegistir,
          ),
          IconButton(
            tooltip: 'Yer imlerim',
            icon: const Icon(Icons.bookmarks_rounded),
            onPressed: _yerImleriniAc,
          ),
          IconButton(
            tooltip: 'Bu sayfaya yer imi ekle',
            icon: const Icon(Icons.bookmark_add_rounded),
            onPressed: _yerImiDegistir,
          ),
          IconButton(
            tooltip: 'Sayfa, cüz, sûre veya ayet seç',
            icon: const Icon(Icons.search),
            onPressed: _seciciyiAc,
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            color: kKagitRengi,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('${HafizlikSira.cuzOf(_sayfa)}. Cüz',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                const Text('İki parmakla büyütüp küçültebilirsiniz',
                    style: TextStyle(fontSize: 11)),
              ],
            ),
          ),
          Expanded(
            child: PageView.builder(
              controller: _kontrol,
              reverse: true,
              // Parmağı sağa/sola kaydırarak veya düğmelerle sayfa çevirme.
              physics: const PageScrollPhysics(),
              itemCount: HafizlikSira.toplamSayfa,
              onPageChanged: (i) {
                if (i + 1 != _sayfa) {
                  _sayfaSesiniCal();
                  setState(() { _sayfa = i + 1; _seciliAyet = null; });
                  OkumaKaydi.sonSayfaKaydet(i + 1);
                }
              },
              itemBuilder: (context, i) => _SayfaIcerigi(
                sayfa: i + 1, seciliAyet: i + 1 == _sayfa ? _seciliAyet : null,
                onAyetSecildi: (ayet) => setState(() { _seciliAyet = ayet; _secimKimligi++; }),
              ),
            ),
          ),
          SesCubugu(key: ValueKey('ses-$_sayfa'), sayfaNo: _sayfa,
            seciliAyet: _seciliAyet, secimKimligi: _secimKimligi),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _sayfa < HafizlikSira.toplamSayfa
                          ? () => _git(_sayfa + 1)
                          : null,
                      icon: const Icon(Icons.chevron_left),
                      label: const Text('Sonraki'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _sayfa > 1 ? () => _git(_sayfa - 1) : null,
                      icon: const Icon(Icons.chevron_right),
                      label: const Text('Önceki'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SayfaIcerigi extends StatefulWidget {
  final int sayfa;
  final Ayet? seciliAyet;
  final ValueChanged<Ayet> onAyetSecildi;

  const _SayfaIcerigi({required this.sayfa, required this.onAyetSecildi, this.seciliAyet});

  @override
  State<_SayfaIcerigi> createState() => _SayfaIcerigiState();
}

class _SayfaIcerigiState extends State<_SayfaIcerigi> {
  late final Future<List<Ayet>> _veri;

  @override
  void initState() {
    super.initState();
    _veri = QuranVeri.sayfa(widget.sayfa);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Ayet>>(
      future: _veri,
      builder: (context, snap) {
        if (snap.hasError) {
          return const Center(child: Text('Sayfa yüklenemedi.'));
        }
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        return LayoutBuilder(
          builder: (context, kisit) => InteractiveViewer(
            // Sayfa genişliği ekran kadar; yükseklik içeriğe göre.
            constrained: false,
            minScale: 1,
            maxScale: 4,
            child: SizedBox(
              width: kisit.maxWidth,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
                child: MushafSayfaGorunumu(ayetler: snap.data!,
                  onAyetSecildi: widget.onAyetSecildi, vurgulananAyet: widget.seciliAyet),
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Sayfa, cüz, sûre ve tek ayete doğrudan geçiş sağlayan okunaklı seçim paneli.
/// Ayet seçimi Mushaf verisindeki gerçek sayfaya gider ve ayeti vurgular.
enum _GitTuru { sayfa, cuz, sure, ayet }

class _GitPaneli extends StatefulWidget {
  final int mevcutSayfa;
  final ValueChanged<int> onGit;
  final ValueChanged<Ayet> onAyetGit;

  const _GitPaneli({
    required this.mevcutSayfa,
    required this.onGit,
    required this.onAyetGit,
  });

  @override
  State<_GitPaneli> createState() => _GitPaneliState();
}

class _GitPaneliState extends State<_GitPaneli> {
  late final TextEditingController _sayfaKontrol;
  _GitTuru _tur = _GitTuru.sayfa;
  late int _cuz;
  int _sure = 1;
  int _ayetSure = 1;
  int _ayetNo = 1;
  bool _ayetYukleniyor = false;

  @override
  void initState() {
    super.initState();
    _sayfaKontrol = TextEditingController(text: '${widget.mevcutSayfa}');
    _cuz = HafizlikSira.cuzOf(widget.mevcutSayfa);
  }

  @override
  void dispose() {
    _sayfaKontrol.dispose();
    super.dispose();
  }

  Future<void> _sureyeGit() async {
    final sayfa = await QuranVeri.sureninIlkSayfasi(_sure);
    if (!mounted) return;
    if (sayfa >= 1 && sayfa <= HafizlikSira.toplamSayfa) {
      widget.onGit(sayfa);
    }
  }

  Future<void> _ayeteGit() async {
    if (_ayetYukleniyor) return;
    setState(() => _ayetYukleniyor = true);
    try {
      final ayetler = await QuranVeri.tumAyetler();
      if (!mounted) return;
      final secilen = mushafAyetiBul(ayetler, _ayetSure, _ayetNo);
      if (secilen != null) {
        widget.onAyetGit(secilen);
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Seçilen ayet Mushaf verisinde bulunamadı.'),
      ));
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Ayet bilgileri yüklenemedi.'),
        ));
      }
    } finally {
      if (mounted) setState(() => _ayetYukleniyor = false);
    }
  }

  Widget _icerik() {
    switch (_tur) {
      case _GitTuru.sayfa:
        return Row(children: [
          Expanded(child: TextField(
            controller: _sayfaKontrol,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Mushaf sayfası (1–604)'),
            onSubmitted: (_) => _sayfayaGit(),
          )),
          const SizedBox(width: 12),
          FilledButton(onPressed: _sayfayaGit, child: const Text('Git')),
        ]);
      case _GitTuru.cuz:
        return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          DropdownButtonFormField<int>(
            key: const ValueKey('mushaf-cuz-secimi'),
            value: _cuz, isExpanded: true,
            decoration: const InputDecoration(labelText: 'Cüz seçin'),
            items: [for (var c = 1; c <= 30; c++)
              DropdownMenuItem(value: c,
                child: Text('$c. Cüz · ${HafizlikSira.cuzBaslangici(c)}. sayfa'))],
            onChanged: (v) { if (v != null) setState(() => _cuz = v); },
          ),
          const SizedBox(height: 14),
          FilledButton(onPressed: () => widget.onGit(HafizlikSira.cuzBaslangici(_cuz)),
            child: const Text('Cüzün başlangıcına git')),
        ]);
      case _GitTuru.sure:
        return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          DropdownButtonFormField<int>(
            key: const ValueKey('mushaf-sure-secimi'),
            value: _sure, isExpanded: true,
            decoration: const InputDecoration(labelText: 'Sûre seçin'),
            items: [for (final s in sureler) DropdownMenuItem(value: s.no,
              child: Text('${s.no}. ${s.trAd} · ${s.ayetSayisi} ayet',
                overflow: TextOverflow.ellipsis))],
            onChanged: (v) { if (v != null) setState(() => _sure = v); },
          ),
          const SizedBox(height: 14),
          FilledButton(onPressed: _sureyeGit,
            child: const Text('Sûrenin başlangıcına git')),
        ]);
      case _GitTuru.ayet:
        return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          DropdownButtonFormField<int>(
            key: const ValueKey('mushaf-ayet-suresi'),
            value: _ayetSure, isExpanded: true,
            decoration: const InputDecoration(labelText: 'Ayetin sûresi'),
            items: [for (final s in sureler) DropdownMenuItem(value: s.no,
              child: Text('${s.no}. ${s.trAd}', overflow: TextOverflow.ellipsis))],
            onChanged: (v) {
              if (v != null) setState(() { _ayetSure = v; _ayetNo = 1; });
            },
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<int>(
            key: ValueKey('mushaf-ayet-$_ayetSure'),
            value: _ayetNo, isExpanded: true,
            decoration: const InputDecoration(labelText: 'Ayet numarası'),
            items: [for (var n = 1; n <= sureler[_ayetSure - 1].ayetSayisi; n++)
              DropdownMenuItem(value: n, child: Text('$n. ayet'))],
            onChanged: (v) { if (v != null) setState(() => _ayetNo = v); },
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: _ayetYukleniyor ? null : _ayeteGit,
            icon: const Icon(Icons.play_arrow_rounded, size: 18),
            label: Text(_ayetYukleniyor ? 'Ayet bulunuyor…' : 'Ayete git ve dinle'),
          ),
          const SizedBox(height: 8),
          Text('Seçilen ayet bulunduğu sayfada vurgulanır.',
            style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
        ]);
    }
  }

  void _sayfayaGit() {
    final s = int.tryParse(_sayfaKontrol.text.trim());
    if (s != null && s >= 1 && s <= HafizlikSira.toplamSayfa) {
      widget.onGit(s);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Lütfen 1 ile 604 arasında bir sayfa girin.'),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: EdgeInsets.fromLTRB(16, 8, 16,
          20 + MediaQuery.of(context).viewInsets.bottom),
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height * .7),
          child: SingleChildScrollView(child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Kur’an’da bir yere git', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 6),
              Text('Sayfa, cüz, sûre veya ayet seçin.',
                style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
              const SizedBox(height: 18),
              SingleChildScrollView(scrollDirection: Axis.horizontal,
                child: SegmentedButton<_GitTuru>(
                  showSelectedIcon: false,
                  segments: const [
                    ButtonSegment(value: _GitTuru.sayfa, label: Text('Sayfa'),
                      icon: Icon(Icons.menu_book_outlined, size: 16)),
                    ButtonSegment(value: _GitTuru.cuz, label: Text('Cüz'),
                      icon: Icon(Icons.layers_outlined, size: 16)),
                    ButtonSegment(value: _GitTuru.sure, label: Text('Sûre'),
                      icon: Icon(Icons.auto_stories_outlined, size: 16)),
                    ButtonSegment(value: _GitTuru.ayet, label: Text('Ayet'),
                      icon: Icon(Icons.format_list_numbered_rounded, size: 16)),
                  ],
                  selected: {_tur},
                  onSelectionChanged: (v) => setState(() => _tur = v.first),
                )),
              const SizedBox(height: 18),
              _icerik(),
            ],
          )),
        ),
      ),
    );
  }
}
