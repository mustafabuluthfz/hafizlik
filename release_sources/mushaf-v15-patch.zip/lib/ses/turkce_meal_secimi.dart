import '../hafizlik/hafizlik_sira.dart';
import '../hafizlik/quran_veri.dart';

/// Sesli meal için kullanıcıya sunulan dört ayrı dinleme aralığı.
enum MealDinlemeTuru { sure, cuz, sayfa, ayet }

/// Bir ayetin tüm Mushaf'taki sıra numarası (1 tabanlı).
/// CDN'nin /audio/{edition}/{index}.mp3 düzeni için gerekir.
int mealGenelAyetNo(Ayet ayet, List<int> sureAyetSayilari) {
  var sonuc = ayet.numara;
  for (var i = 0; i < ayet.sure - 1; i++) {
    sonuc += sureAyetSayilari[i];
  }
  return sonuc;
}

/// Seçilen süre, cüz, sayfa veya tek ayeti sıra sırasına göre döndürür.
/// Bu fonksiyon internet gerektirmez; seçim yalnızca yerel Mushaf verisindendir.
List<Ayet> mealDinlemeAyetleri({
  required List<Ayet> tumAyetler,
  required MealDinlemeTuru tur,
  required int sure,
  required int cuz,
  required int sayfa,
  required int ayet,
}) {
  return tumAyetler.where((a) {
    switch (tur) {
      case MealDinlemeTuru.sure:
        return a.sure == sure;
      case MealDinlemeTuru.cuz:
        return HafizlikSira.cuzOf(a.sayfa) == cuz;
      case MealDinlemeTuru.sayfa:
        return a.sayfa == sayfa;
      case MealDinlemeTuru.ayet:
        return a.sure == sure && a.numara == ayet;
    }
  }).toList(growable: false);
}
