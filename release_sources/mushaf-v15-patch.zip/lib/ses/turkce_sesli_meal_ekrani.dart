import 'dart:async';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

import '../bulmaca/sureler.dart';
import '../hafizlik/hafizlik_sira.dart';
import '../hafizlik/quran_veri.dart';
import 'turkce_meal_secimi.dart';

/// Eski kodun kullandığı bir surenin ilk küresel ayet numarası.
int globalAyetBaslangici(int sure) {
  assert(sure >= 1 && sure <= 114);
  var toplam = 1;
  for (var i = 0; i < sure - 1; i++) toplam += sureler[i].ayetSayisi;
  return toplam;
}

class TurkceSesliMealEkrani extends StatefulWidget {
  const TurkceSesliMealEkrani({super.key});
  @override
  State<TurkceSesliMealEkrani> createState() => _TurkceSesliMealEkraniState();
}

class _TurkceSesliMealEkraniState extends State<TurkceSesliMealEkrani> {
  final AudioPlayer _oynatici = AudioPlayer();
  MealDinlemeTuru _tur = MealDinlemeTuru.sure;
  int _sure = 1;
  int _cuz = 1;
  int _sayfa = 1;
  int _ayet = 1;
  bool _yukleniyor = false;
  bool _hazir = false;
  String? _hata;
  List<Ayet> _calmaListesi = [];

  @override
  void dispose() {
    _oynatici.dispose();
    super.dispose();
  }

  /// Kullanıcı seçimleri değiştirince eski sırayı tutma; oynatıcıyı sıfırla.
  Future<void> _secimiDegistir(VoidCallback degistir) async {
    await _oynatici.stop();
    if (!mounted) return;
    setState(() {
      degistir();
      _hazir = false;
      _calmaListesi = [];
      _hata = null;
    });
  }

  Future<void> _cal() async {
    if (_yukleniyor) return;
    if (_hazir) {
      await _oynatici.play();
      return;
    }
    setState(() { _yukleniyor = true; _hata = null; });
    try {
      final tum = await QuranVeri.tumAyetler();
      final secim = mealDinlemeAyetleri(
        tumAyetler: tum,
        tur: _tur,
        sure: _sure,
        cuz: _cuz,
        sayfa: _sayfa,
        ayet: _ayet,
      );
      if (secim.isEmpty) throw StateError('Bu seçimde ayet bulunamadı.');
      final sayilar = sureler.map((s) => s.ayetSayisi).toList();
      final kaynaklar = [
        for (final a in secim)
          AudioSource.uri(Uri.parse(
            'https://cdn.islamic.network/quran/audio/128/tr.vakfi-audio/'
            '${mealGenelAyetNo(a, sayilar)}.mp3')),
      ];
      // Ağdan alınan kayıtlar bağımsız, sıralı ayetler halinde çalınır.
      await _oynatici.setAudioSource(ConcatenatingAudioSource(children: kaynaklar));
      if (!mounted) return;
      setState(() { _calmaListesi = secim; _hazir = true; });
      unawaited(_oynatici.play().catchError((Object _) {
        if (mounted) setState(() => _hata = 'Ses oynatılırken bir sorun oluştu.');
      }));
    } catch (_) {
      if (mounted) setState(() {
        _hazir = false;
        _hata = 'Sesli meal yüklenemedi. İnternet bağlantınızı ve ses kaynağını kontrol edin.';
      });
    } finally {
      if (mounted) setState(() => _yukleniyor = false);
    }
  }

  Widget _sureSecici({required bool tekAyet}) => DropdownButtonFormField<int>(
    key: ValueKey('sure-${_tur.name}'),
    value: _sure,
    isExpanded: true,
    decoration: InputDecoration(
      labelText: tekAyet ? 'Ayetin suresi' : 'Sûre seçin',
      prefixIcon: const Icon(Icons.auto_stories_rounded, size: 19),
    ),
    items: [for (var i = 0; i < sureler.length; i++)
      DropdownMenuItem(value: i + 1,
        child: Text('${i + 1}. ${sureler[i].trAd}', overflow: TextOverflow.ellipsis))],
    onChanged: (v) {
      if (v != null) _secimiDegistir(() { _sure = v; _ayet = 1; });
    },
  );

  Widget _secimKontrolleri() {
    switch (_tur) {
      case MealDinlemeTuru.sure:
        return _sureSecici(tekAyet: false);
      case MealDinlemeTuru.cuz:
        return DropdownButtonFormField<int>(
          key: const ValueKey('cuz-sec'),
          value: _cuz,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Cüz seçin',
            prefixIcon: Icon(Icons.layers_rounded, size: 19)),
          items: [for (var i = 1; i <= 30; i++)
            DropdownMenuItem(value: i, child: Text('$i. Cüz  •  ${HafizlikSira.cuzBaslangici(i)}. sayfadan'))],
          onChanged: (v) { if (v != null) _secimiDegistir(() => _cuz = v); },
        );
      case MealDinlemeTuru.sayfa:
        return DropdownButtonFormField<int>(
          key: const ValueKey('sayfa-sec'),
          value: _sayfa,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Mushaf sayfası (1–604)',
            prefixIcon: Icon(Icons.menu_book_rounded, size: 19)),
          items: [for (var i = 1; i <= HafizlikSira.toplamSayfa; i++)
            DropdownMenuItem(value: i, child: Text('$i. Sayfa · ${HafizlikSira.cuzOf(i)}. Cüz'))],
          onChanged: (v) { if (v != null) _secimiDegistir(() => _sayfa = v); },
        );
      case MealDinlemeTuru.ayet:
        return Column(children: [
          _sureSecici(tekAyet: true),
          const SizedBox(height: 12),
          DropdownButtonFormField<int>(
            key: ValueKey('ayet-$_sure'),
            value: _ayet,
            isExpanded: true,
            decoration: const InputDecoration(labelText: 'Dinlenecek ayet',
              prefixIcon: Icon(Icons.format_list_numbered_rounded, size: 19)),
            items: [for (var i = 1; i <= sureler[_sure - 1].ayetSayisi; i++)
              DropdownMenuItem(value: i, child: Text('$i. Ayet'))],
            onChanged: (v) { if (v != null) _secimiDegistir(() => _ayet = v); },
          ),
        ]);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Türkçe Sesli Meal')),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 26), children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [cs.primary, const Color(0xFF159078)]),
            borderRadius: BorderRadius.circular(20)),
          child: const Row(children: [
            Icon(Icons.headphones_rounded, size: 28, color: Color(0xFFFFD89B)),
            SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Meal dinleme', style: TextStyle(color: Colors.white,
                fontWeight: FontWeight.w800, fontSize: 20)),
              SizedBox(height: 3),
              Text('Sûre · Cüz · Sayfa · Ayet',
                style: TextStyle(color: Color(0xFFEAF7F1), fontSize: 12)),
            ])),
          ]),
        ),
        const SizedBox(height: 16),
        Text('Ne dinlemek istersiniz?', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 10),
        // Mobil ekranda dört seçenek ayrı satıra sığar; seçim saklanır.
        SingleChildScrollView(scrollDirection: Axis.horizontal,
          child: SegmentedButton<MealDinlemeTuru>(
            segments: const [
              ButtonSegment(value: MealDinlemeTuru.sure, label: Text('Sûre'), icon: Icon(Icons.library_books_outlined, size: 16)),
              ButtonSegment(value: MealDinlemeTuru.cuz, label: Text('Cüz'), icon: Icon(Icons.layers_outlined, size: 16)),
              ButtonSegment(value: MealDinlemeTuru.sayfa, label: Text('Sayfa'), icon: Icon(Icons.menu_book_outlined, size: 16)),
              ButtonSegment(value: MealDinlemeTuru.ayet, label: Text('Ayet'), icon: Icon(Icons.format_list_numbered_rounded, size: 16)),
            ],
            selected: {_tur},
            showSelectedIcon: false,
            onSelectionChanged: (s) => _secimiDegistir(() => _tur = s.first),
          )),
        const SizedBox(height: 14),
        Card(child: Padding(padding: const EdgeInsets.all(14), child: _secimKontrolleri())),
        const SizedBox(height: 14),
        Card(child: Padding(padding: const EdgeInsets.fromLTRB(16, 15, 16, 18),
          child: Column(children: [
            StreamBuilder<int?>(stream: _oynatici.currentIndexStream,
              builder: (context, snap) {
                final index = snap.data ?? 0;
                final aktif = _calmaListesi.isNotEmpty && index >= 0 && index < _calmaListesi.length
                  ? _calmaListesi[index] : null;
                final sayac = _calmaListesi.isEmpty ? 'Seçiminizi yapıp Dinle’ye basın' :
                    '${index + 1} / ${_calmaListesi.length} ayet';
                return Column(children: [
                  Icon(Icons.graphic_eq_rounded, color: cs.primary, size: 30),
                  const SizedBox(height: 6),
                  Text(aktif == null ? 'Dinlemeye hazır' :
                    '${sureler[aktif.sure - 1].trAd} · ${aktif.numara}. ayet',
                    style: Theme.of(context).textTheme.titleMedium,
                    textAlign: TextAlign.center),
                  const SizedBox(height: 5),
                  Text(sayac, style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
                ]);
              }),
            const SizedBox(height: 10),
            StreamBuilder<Duration>(stream: _oynatici.positionStream,
              builder: (context, snap) => LinearProgressIndicator(
                value: _oynatici.duration == null || _oynatici.duration!.inMilliseconds == 0
                  ? 0 : ((snap.data ?? Duration.zero).inMilliseconds / _oynatici.duration!.inMilliseconds).clamp(0.0, 1.0),
                borderRadius: BorderRadius.circular(4), minHeight: 4)),
            const SizedBox(height: 14),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              IconButton.filledTonal(tooltip: 'Önceki ayet',
                onPressed: _hazir ? _oynatici.seekToPrevious : null,
                icon: const Icon(Icons.skip_previous_rounded, size: 20)),
              const SizedBox(width: 16),
              StreamBuilder<PlayerState>(stream: _oynatici.playerStateStream,
                builder: (context, snap) {
                  final oynuyor = snap.data?.playing == true;
                  return FilledButton.icon(
                    onPressed: _yukleniyor ? null : oynuyor ? _oynatici.pause : _cal,
                    icon: _yukleniyor
                      ? const SizedBox(width: 18, height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : Icon(oynuyor ? Icons.pause_rounded : Icons.play_arrow_rounded, size: 19),
                    label: Text(_yukleniyor ? 'Yükleniyor' : oynuyor ? 'Duraklat' : 'Dinle'),
                  );
                }),
              const SizedBox(width: 16),
              IconButton.filledTonal(tooltip: 'Sonraki ayet',
                onPressed: _hazir ? _oynatici.seekToNext : null,
                icon: const Icon(Icons.skip_next_rounded, size: 20)),
            ]),
          ]))),
        if (_hata != null) Padding(padding: const EdgeInsets.only(top: 12),
          child: Text(_hata!, style: TextStyle(color: cs.error, fontSize: 13))),
        const SizedBox(height: 16),
        Text('Türkçe sesli meal için internet gerekir. Ses kaynağı: '
          'Al Quran Cloud / Turkish Vakfi Audio. Uygulama ses kayıtlarını yeniden dağıtmaz.',
          style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant, height: 1.45)),
      ]),
    );
  }
}
