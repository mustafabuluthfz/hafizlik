import 'package:flutter_test/flutter_test.dart';
import 'package:hafizlik_app/hafizlik/hafizlik_sira.dart';
import 'package:hafizlik_app/hafizlik/quran_veri.dart';
import 'package:hafizlik_app/ses/turkce_meal_secimi.dart';

void main() {
  final mock = <Ayet>[
    const Ayet(sure: 1, numara: 1, metin: '', sayfa: 1),
    const Ayet(sure: 1, numara: 2, metin: '', sayfa: 1),
    const Ayet(sure: 2, numara: 1, metin: '', sayfa: 2),
    const Ayet(sure: 2, numara: 142, metin: '', sayfa: 22),
    const Ayet(sure: 3, numara: 1, metin: '', sayfa: 50),
  ];
  List<Ayet> select(MealDinlemeTuru tur, {int sure = 1, int cuz = 1, int sayfa = 1, int ayet = 1}) =>
    mealDinlemeAyetleri(tumAyetler: mock, tur: tur, sure: sure, cuz: cuz, sayfa: sayfa, ayet: ayet);

  test('Sûre seçimi yalnızca o sûrenin ayetlerini döndürür', () {
    expect(select(MealDinlemeTuru.sure, sure: 1).length, 2);
    expect(select(MealDinlemeTuru.sure, sure: 2).length, 2);
  });
  test('Cüz sınırında doğru ayetler seçilir', () {
    expect(HafizlikSira.cuzOf(22), 2);
    expect(select(MealDinlemeTuru.cuz, cuz: 2).map((a) => a.sayfa).toList(), [22]);
  });
  test('Mushaf sayfası yalnızca o sayfanın ayetlerini döndürür', () {
    expect(select(MealDinlemeTuru.sayfa, sayfa: 1).length, 2);
    expect(select(MealDinlemeTuru.sayfa, sayfa: 50).length, 1);
  });
  test('Tek ayet seçimi ve küresel ayet numarası', () {
    final a = select(MealDinlemeTuru.ayet, sure: 1, ayet: 2);
    expect(a.length, 1);
    expect(a.single.numara, 2);
    expect(mealGenelAyetNo(mock[2], [7, 286, 200]), 8);
  });
}
