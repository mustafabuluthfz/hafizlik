import 'package:flutter_test/flutter_test.dart';
import 'package:hafizlik_app/hafizlik/quran_veri.dart';
import 'package:hafizlik_app/kuran/mushaf_gecis.dart';

void main() {
  final ornek = <Ayet>[
    const Ayet(sure: 1, numara: 1, metin: 'a', sayfa: 1),
    const Ayet(sure: 1, numara: 7, metin: 'b', sayfa: 1),
    const Ayet(sure: 2, numara: 1, metin: 'c', sayfa: 2),
    const Ayet(sure: 2, numara: 255, metin: 'd', sayfa: 42),
  ];
  test('Sûre ve ayetle doğru Mushaf sayfası seçilir', () {
    expect(mushafAyetiBul(ornek, 2, 255)?.sayfa, 42);
    expect(mushafAyetiBul(ornek, 1, 7)?.sayfa, 1);
  });
  test('Yanlış veya olmayan ayet için sayfa uydurulmaz', () {
    expect(mushafAyetiBul(ornek, 1, 255), null);
    expect(mushafAyetiBul(ornek, 0, 1), null);
    expect(mushafAyetiBul(ornek, 2, -4), null);
  });
}
