# Mushaf Yoldaşım V15 — Sesli meal ve sayfa geçişleri

- Türkçe sesli meal ekranında sûrenin tamamı, seçilen cüz, 604 sayfadan bir sayfa veya tek ayet dinlenebilir.
- Sesli meal internet bağlantısı gerektirir; Diyanet meali veya metin meali eklenmedi.
- Kur'an sayfalarında sağa/sola kaydırma ve 340 ms yumuşak sayfa geçiş animasyonu eklendi.
- Kâğıt çevirme sesi uygulama içinde orijinal olarak sentezlendi; üstteki ses düğmesiyle kapatılabilir.
- Genel ikonlar, kartlar, renk vurguları ve gezinme alanı daha kompakt hâle getirildi.
- Android paket kimliği korunur; sürüm 2.6.0+19. V14 ile aynı özel anahtarla imzalama gereklidir.
- Kur’an okuma sayfasının git paneline Sayfa / Cüz / Sûre / Ayet sekmeleri eklendi. Ayet seçilince ilgili sayfa açılır, ayet vurgulanır ve tek ayet dinleme başlatılır.
